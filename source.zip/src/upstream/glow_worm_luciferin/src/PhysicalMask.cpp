// GPL-3.0-or-later
#include <Arduino.h>
#include <Preferences.h>
#include "PhysicalMask.h"

namespace PhysicalMask {
PhysicalMaskCore::State state;
Preferences storage;
bool storageReady = false;
char pending[PhysicalMaskCore::MaxLine] = {};
size_t used = 0;
bool receiving = false, overflow = false;
unsigned long lastByte = 0;

void acknowledge() {
  if (state.corrupt) Serial.println("mask:ERROR:STORAGE");
  else if (!state.count) Serial.println("mask:NONE");
  else Serial.printf("mask:GWPM1:%u:%08lX\n", state.count, static_cast<unsigned long>(state.crc));
}
void begin() {
  storageReady = storage.begin("portable-mask", false);
  if (!storageReady) { state.corrupt = true; return; }
  if (!storage.isKey("command")) return; // official firmware upgrade, no saved mask yet
  size_t length = storage.getBytesLength("command");
  char record[PhysicalMaskCore::MaxLine] = {};
  if (!length || length >= sizeof(record) || storage.getBytes("command", record, length) != length ||
      !PhysicalMaskCore::parse(record, length, state)) state.corrupt = true;
}
void apply(const char* line, size_t length) {
  if (length == 6 && memcmp(line, "GWPM1?", 6) == 0) { acknowledge(); return; }
  PhysicalMaskCore::State next;
  if (!PhysicalMaskCore::parse(line, length, next)) { Serial.println("mask:ERROR:INVALID"); return; }
  if (!storageReady) { Serial.println("mask:ERROR:STORAGE"); return; }
  if (!state.corrupt && state.count == next.count && state.crc == next.crc &&
      memcmp(state.bits, next.bits, sizeof(state.bits)) == 0) { acknowledge(); return; }
  // Preferences putBytes commits one NVS blob atomically. Read it back before enabling output.
  char verify[PhysicalMaskCore::MaxLine] = {};
  if (storage.putBytes("command", line, length) != length || storage.getBytesLength("command") != length ||
      storage.getBytes("command", verify, length) != length || memcmp(line, verify, length) != 0) {
    state.corrupt = true;
    Serial.println("mask:ERROR:STORAGE");
    return;
  }
  state = next;
  acknowledge();
}
bool readSerial() {
  // Invoked at frame boundaries only; RGB payloads remain owned by the DPsoft reader.
  if (!receiving && Serial.peek() != 'G') return false;
  if (!receiving) { receiving = true; used = 0; overflow = false; lastByte = millis(); }
  if (millis() - lastByte > 250) {
    receiving = false;
    Serial.println("mask:ERROR:TIMEOUT");
    return true;
  }
  while (Serial.available()) {
    char c = static_cast<char>(Serial.peek());
    // Resynchronize on a normal frame after a truncated or malformed mask line.
    if (c == 'D' && (overflow || used < 6 || memcmp(pending, "GWPM1:", 6) != 0)) {
      receiving = false;
      Serial.println("mask:ERROR:INVALID");
      return true;
    }
    Serial.read();
    lastByte = millis();
    if (c == '\n') {
      if (overflow) Serial.println("mask:ERROR:TOO_LONG");
      else apply(pending, used);
      receiving = false;
      return true;
    }
    if (used + 1 >= sizeof(pending)) overflow = true;
    else if (!overflow) pending[used++] = c;
  }
  return true;
}
}
