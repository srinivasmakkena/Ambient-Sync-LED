// GPL-3.0-or-later
#pragma once
#include "PhysicalMaskCore.h"
namespace PhysicalMask {
extern PhysicalMaskCore::State state;
void begin();
bool readSerial();
}
