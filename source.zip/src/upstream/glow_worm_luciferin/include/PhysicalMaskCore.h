// Portable physical-mask protocol; no Arduino dependencies so the exact parser is host-testable.
// GPL-3.0-or-later, matching Glow Worm Luciferin.
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

namespace PhysicalMaskCore {
constexpr uint16_t MaxLeds = 300;
constexpr size_t MaskBytes = (MaxLeds + 7) / 8;
constexpr size_t MaxLine = 96;
struct State {
  uint16_t count = 0;
  uint8_t bits[MaskBytes] = {};
  uint32_t crc = 0;
  bool corrupt = false;
  bool any() const {
    for (uint8_t b : bits) if (b) return true;
    return false;
  }
  bool blocked(uint16_t index, uint16_t actualCount) const {
#ifdef PORTABLE_PHYSICAL_MASK
    if (!count) return true; // portable firmware needs a saved layout before any lit output
#endif
    if (corrupt || actualCount > MaxLeds || (count && (actualCount != count || index >= count))) return true;
    if (!any()) return false;
    return (bits[index / 8] & (1u << (index % 8))) != 0;
  }
};
inline uint32_t crc32(const char* data, size_t length) {
  uint32_t crc = 0xffffffff;
  for (size_t i = 0; i < length; ++i) {
    crc ^= static_cast<uint8_t>(data[i]);
    for (uint8_t j = 0; j < 8; ++j) crc = (crc >> 1) ^ ((crc & 1) ? 0xedb88320u : 0);
  }
  return crc ^ 0xffffffff;
}
inline int hex(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}
inline bool parse(const char* line, size_t length, State& destination) {
  if (length < 19 || length >= MaxLine || memcmp(line, "GWPM1:", 6) != 0) return false;
  State next;
  size_t pos = 6;
  if (line[pos] < '1' || line[pos] > '9') return false;
  while (pos < length && line[pos] >= '0' && line[pos] <= '9') {
    next.count = next.count * 10 + line[pos++] - '0';
    if (next.count > MaxLeds) return false;
  }
  if (pos >= length || line[pos++] != ':') return false;
  const size_t bytes = (next.count + 7) / 8;
  if (length != pos + bytes * 2 + 9) return false;
  for (size_t i = 0; i < bytes; ++i) {
    int hi = hex(line[pos++]), lo = hex(line[pos++]);
    if (hi < 0 || lo < 0) return false;
    next.bits[i] = static_cast<uint8_t>((hi << 4) | lo);
  }
  if ((next.count % 8) && (next.bits[bytes - 1] >> (next.count % 8))) return false;
  const size_t canonicalLength = pos;
  if (line[pos++] != ':') return false;
  for (uint8_t i = 0; i < 8; ++i) {
    int digit = hex(line[pos++]);
    if (digit < 0) return false;
    next.crc = (next.crc << 4) | digit;
  }
  if (next.crc != crc32(line, canonicalLength)) return false;
  destination = next; // atomic update only after every validation succeeds
  return true;
}

// Show(true) preserves a separate editing buffer on ESP32 RMT; DotStarMethod sends synchronously.
// Restore logical pixels immediately without polling CanShow(): zero-timeout RMT polls flood serial errors.
template<class Bus, class Color, class Yield>
void show(Bus* bus, const State& state, Yield cooperate) {
  (void)cooperate;
  if (!bus) return;
  const uint16_t count = bus->PixelCount();
  if (count > MaxLeds) {
    // A layout/count mismatch is fail-closed; no bounded scratch array is indexed.
    bus->ClearTo(Color(0));
    bus->Show();
    return;
  }
  bool unsetPortableMask = false;
#ifdef PORTABLE_PHYSICAL_MASK
  unsetPortableMask = !state.count;
#endif
  if (!unsetPortableMask && !state.corrupt && !state.any() && (!state.count || count == state.count)) { bus->Show(true); return; }
  Color saved[MaxLeds];
  for (uint16_t i = 0; i < count; ++i) if (state.blocked(i, count)) {
    saved[i] = bus->GetPixelColor(i);
    bus->SetPixelColor(i, Color(0));
  }
  bus->Show(true);
  for (uint16_t i = 0; i < count; ++i) if (state.blocked(i, count)) bus->SetPixelColor(i, saved[i]);
}
}
