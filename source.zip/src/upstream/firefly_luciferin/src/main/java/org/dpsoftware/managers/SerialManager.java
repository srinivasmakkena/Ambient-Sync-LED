/*
  SerialManager.java

  Firefly Luciferin, very fast Java Screen Capture software designed
  for Glow Worm Luciferin firmware.

  Copyright © 2020 - 2026  Davide Perini  (https://github.com/sblantipodi)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
package org.dpsoftware.managers;

import com.fazecast.jSerialComm.SerialPort;
import com.fazecast.jSerialComm.SerialPortDataListener;
import com.fazecast.jSerialComm.SerialPortEvent;
import javafx.application.Platform;
import javafx.scene.control.Alert;
import lombok.extern.slf4j.Slf4j;
import org.dpsoftware.MainSingleton;
import org.dpsoftware.NativeExecutor;
import org.dpsoftware.audio.AudioSingleton;
import org.dpsoftware.config.Constants;
import org.dpsoftware.config.Enums;
import org.dpsoftware.gui.GuiManager;
import org.dpsoftware.gui.GuiSingleton;
import org.dpsoftware.gui.elements.GlowWormDevice;
import org.dpsoftware.utilities.CommonUtility;

import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;

/**
 * Serial port utility
 */
@Slf4j
public class SerialManager {

    private static final ScheduledExecutorService serialAttachScheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "serial-connection"); thread.setDaemon(true); return thread;
    });
    private static ScheduledFuture<?> scheduledFuture;
    private static ScheduledFuture<?> maskHandshakeFuture;
    private static long connectionGeneration;
    private static Boolean reportedBlackFrame;
    private static long frameStateLoggedAt;
    boolean alertSent = false;

    /**
     * Initialize Serial communication
     */
    public void initSerial() {
        initSerial("", "");
    }

    /**
     * Initialize Serial communication
     */
    public void initSerial(String portName, String baudrate) {
        if (!MainSingleton.getInstance().config.isWirelessStream() || !portName.isEmpty()) {
            serialAttachScheduler.execute(() -> {
                synchronized (org.dpsoftware.portable.PortableMask.class) {
                    connectSerial(portName, baudrate);
                }
            });
        }
    }

    private void connectSerial(String portName, String baudrate) {
        if (MainSingleton.getInstance().exitTriggered) return;
        try {
            closeSerial();
            SerialPort[] ports = SerialPort.getCommPorts();
            int readTimeout = MainSingleton.getInstance().config.getTimeout();
            int writeTimeout = readTimeout;
            String selected = portName.isEmpty() ? MainSingleton.getInstance().config.getOutputDevice() : portName;
            for (SerialPort port : ports) {
                if (selected.equals(port.getSystemPortName())) { MainSingleton.getInstance().serial = port; break; }
            }
            if (Constants.SERIAL_PORT_AUTO.equals(selected) && ports.length == 1) MainSingleton.getInstance().serial = ports[0];
            if (MainSingleton.getInstance().serial == null) {
                MainSingleton.getInstance().communicationError = true;
                log.debug("USB port {} unavailable; waiting for it or a new saved selection", selected);
            } else {
                MainSingleton.getInstance().serial.setDTRandRTS(false, false);
                openSerial(portName, baudrate, readTimeout, writeTimeout, ports.length);
            }
        } catch (Exception e) {
            log.error("USB connection failed: {}", e.getMessage());
            MainSingleton.getInstance().communicationError = true;
        }
        if (MainSingleton.getInstance().communicationError) scheduleReconnect();
        else if (scheduledFuture != null) { scheduledFuture.cancel(false); scheduledFuture = null; }
    }

    /**
     * Open serial
     *
     * @param portName              serial port
     * @param baudrate              baudrate
     * @param readTimeout           read timeout
     * @param writeTimeout          write timeout
     * @param numberOfSerialDevices number of serial devices
     */
    private void openSerial(String portName, String baudrate, int readTimeout, int writeTimeout, int numberOfSerialDevices) throws IOException {
        if (MainSingleton.getInstance().serial != null && MainSingleton.getInstance().serial.openPort()) {
            int baudrateToUse = baudrate.isEmpty() ? Integer.parseInt(MainSingleton.getInstance().config.getBaudRate()) : Integer.parseInt(baudrate);
            MainSingleton.getInstance().serial.setComPortParameters(baudrateToUse, 8, 1, SerialPort.NO_PARITY);
            MainSingleton.getInstance().serial.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, readTimeout, writeTimeout);
            log.info("{}{}", CommonUtility.getWord(Constants.SERIAL_PORT_IN_USE), MainSingleton.getInstance().serial.getSystemPortName());
            GlowWormDevice gwDevice = createDefaultDevice();
            GuiManager guiManager = new GuiManager();
            if (numberOfSerialDevices > 1 && MainSingleton.getInstance().config.getOutputDevice().equals(Constants.SERIAL_PORT_AUTO) && portName.isEmpty()) {
                MainSingleton.getInstance().communicationError = true;
                guiManager.showLocalizedNotification(Constants.SERIAL_PORT_AMBIGUOUS, Constants.SERIAL_PORT_AMBIGUOUS_CONTEXT, Constants.SERIAL_ERROR_TITLE, TrayIcon.MessageType.ERROR);
                log.error(Constants.SERIAL_ERROR_OPEN_HEADER);
            }
            log.info("Connected: Serial {}", MainSingleton.getInstance().serial.getDescriptivePortName());
            if (MainSingleton.getInstance().guiManager != null) {
                MainSingleton.getInstance().guiManager.trayIconManager.resetTray();
            }
            MainSingleton.getInstance().serialConnected = true;
            MainSingleton.getInstance().communicationError = false;
            MainSingleton.getInstance().output = MainSingleton.getInstance().serial.getOutputStream();
            listenSerialEvents();
            Platform.runLater(() -> GuiSingleton.getInstance().deviceTableData.add(gwDevice));
            if (System.getProperty("firefly.portable.root") != null) {
                synchronized (org.dpsoftware.portable.PortableMask.class) {
                    org.dpsoftware.portable.PortableMask.reset();
                    MainSingleton.getInstance().output.write(org.dpsoftware.portable.PositionTest.packet(MainSingleton.getInstance().ledNumber,-1,0));
                    org.dpsoftware.portable.PortableMask.ready();
                }
                startMaskHandshake();
            }
        } else {
            if (NativeExecutor.isLinux() && !alertSent) {
                alertSent = true;
                Platform.runLater(() -> {
                    String content = CommonUtility.getWord(Constants.USB_NOT_AVAILABLE_CONTENT);
                    if (NativeExecutor.isSnap()) {
                        content += CommonUtility.getWord(Constants.USB_NOT_AVAILABLE_CONTENT_SNAP);
                    }
                    MainSingleton.getInstance().guiManager.showAlert(CommonUtility.getWord(Constants.USB_NOT_AVAILABLE_TITLE),
                            CommonUtility.getWord(Constants.USB_NOT_AVAILABLE_HEADER), content, Alert.AlertType.WARNING);
                });
            }
            MainSingleton.getInstance().communicationError = true;
        }
    }

    /**
     * Create a default device
     *
     * @return default device
     */
    private GlowWormDevice createDefaultDevice() {
        GlowWormDevice gwDevice = new GlowWormDevice();
        gwDevice.setDeviceName(Constants.USB_DEVICE);
        gwDevice.setDeviceIP(MainSingleton.getInstance().serial.getSystemPortName());
        gwDevice.setDhcpInUse(false);
        gwDevice.setWifi(Constants.DASH);
        gwDevice.setDeviceVersion(Constants.DASH);
        gwDevice.setDeviceBoard(Constants.DASH);
        gwDevice.setMac(Constants.DASH);
        gwDevice.setGpio(Constants.DASH);
        gwDevice.setNumberOfLEDSconnected(Constants.DASH);
        gwDevice.setLastSeen(MainSingleton.getInstance().formatter.format(new Date()));
        gwDevice.setFirmwareType(Constants.DASH);
        gwDevice.setBaudRate(Constants.DASH);
        gwDevice.setMqttTopic(Constants.DASH);
        gwDevice.setColorMode(Constants.DASH);
        gwDevice.setColorOrder(Enums.ColorOrder.GRB_GRBW.name());
        gwDevice.setLdrValue(Constants.DASH);
        gwDevice.setRelayPin(Constants.DASH);
        gwDevice.setRelayInvertedPin(false);
        gwDevice.setSbPin(Constants.DASH);
        gwDevice.setLdrPin(Constants.DASH);
        gwDevice.setGpioClock(Constants.DASH);
        gwDevice.setLedBuiltin(Constants.DASH);
        return gwDevice;
    }

    /**
     * Add a listener on USB ports
     */
    @SuppressWarnings("all")
    private void listenSerialEvents() {
        final SerialPort connectedPort = MainSingleton.getInstance().serial;
        final long connectedGeneration = connectionGeneration;
        connectedPort.addDataListener(new SerialPortDataListener() {
            private StringBuilder lineBuffer = new StringBuilder();

            @Override
            public int getListeningEvents() {
                return SerialPort.LISTENING_EVENT_DATA_AVAILABLE | SerialPort.LISTENING_EVENT_PORT_DISCONNECTED;
            }

            @Override
            public void serialEvent(SerialPortEvent event) {
                if (event.getEventType() == SerialPort.LISTENING_EVENT_DATA_AVAILABLE) {
                    SerialPort serial = connectedPort;
                    if (serial != MainSingleton.getInstance().serial) return;
                    int available = serial.bytesAvailable();
                    if (available <= 0) return;

                    byte[] buffer = new byte[available];
                    int numRead = serial.readBytes(buffer, buffer.length);
                    if (numRead > 0) {
                        String data = decodeSerialRead(buffer, numRead);
                        lineBuffer.append(data);

                        String line;
                        while ((line = extractLineFromBuffer(lineBuffer)) != null) {
                            synchronized (org.dpsoftware.portable.PortableMask.class) {
                                if (connectedPort != MainSingleton.getInstance().serial || connectedGeneration != connectionGeneration) return;
                                handleSerialEvent(line);
                            }
                        }
                    }
                } else if (event.getEventType() == SerialPort.LISTENING_EVENT_PORT_DISCONNECTED) {
                    log.info("USB device disconnected");
                    serialAttachScheduler.execute(() -> {
                        synchronized (org.dpsoftware.portable.PortableMask.class) {
                            if (connectedPort != MainSingleton.getInstance().serial) return;
                            if (System.getProperty("firefly.portable.root") != null) MainSingleton.getInstance().config.setToggleLed(false);
                            closeSerial();
                            MainSingleton.getInstance().communicationError = true;
                            scheduleReconnect();
                        }
                    });
                }
            }

            // Get a complete line from the buffer, if present
            private String extractLineFromBuffer(StringBuilder buffer) {
                int idx = buffer.indexOf("\n");
                if (idx == -1) return null;
                String line = buffer.substring(0, idx).replaceAll("\r$", "");
                buffer.delete(0, idx + 1);
                return line;
            }
        });
    }

    static String decodeSerialRead(byte[] buffer, int numRead) {
        return new String(buffer, 0, numRead, StandardCharsets.UTF_8);
    }

    private void startMaskHandshake() {
        if (maskHandshakeFuture != null && !maskHandshakeFuture.isDone()) return;
        maskHandshakeFuture = serialAttachScheduler.scheduleWithFixedDelay(() -> {
            synchronized (org.dpsoftware.portable.PortableMask.class) {
                if (MainSingleton.getInstance().exitTriggered || !MainSingleton.getInstance().serialConnected || MainSingleton.getInstance().output == null) return;
                try { org.dpsoftware.portable.PortableMask.ready(); }
                catch (IOException failure) {
                    log.warn("USB physical-layout handshake failed: {}",failure.getMessage());
                    MainSingleton.getInstance().config.setToggleLed(false);
                    closeSerial();
                    MainSingleton.getInstance().communicationError=true;
                    scheduleReconnect();
                }
            }
        },250,250,TimeUnit.MILLISECONDS);
    }

    /**
     * Reconnect USB if disconnected (example a device reboot)
     */
    private void scheduleReconnect() {
        if (scheduledFuture == null || scheduledFuture.isDone()) {
            scheduledFuture = serialAttachScheduler.scheduleWithFixedDelay(() -> {
                synchronized (org.dpsoftware.portable.PortableMask.class) {
                    if (MainSingleton.getInstance().exitTriggered) {
                        scheduledFuture.cancel(false); scheduledFuture = null; return;
                    }
                    connectSerial("", "");
                }
            }, 5, 5, TimeUnit.SECONDS);
        }
    }

    /**
     * Send color info via USB Serial
     *
     * @param leds array with colors
     * @throws IOException can't write to serial
     */
    public void sendColorsViaUSB(Color[] leds) throws IOException {
        synchronized (org.dpsoftware.portable.PortableMask.class) {
            sendColorsViaUSBLocked(leds);
        }
    }

    private void sendColorsViaUSBLocked(Color[] leds) throws IOException {
        if(org.dpsoftware.portable.PositionTest.running) return;
        if (System.getProperty("firefly.portable.root") != null && MainSingleton.getInstance().RUNNING && MainSingleton.getInstance().config.isToggleLed()) {
            boolean black=true;
            for (Color color:leds) if (color!=null && (color.getRed()|color.getGreen()|color.getBlue())!=0) {black=false;break;}
            long now=System.currentTimeMillis();
            if ((reportedBlackFrame==null || reportedBlackFrame!=black) && now-frameStateLoggedAt>=2000) {
                reportedBlackFrame=black;frameStateLoggedAt=now;
                log.info("Captured frame colors: {} (requested brightness {})",black?"all black":"nonblack",CommonUtility.getNightBrightness());
            }
        }
        boolean portableReady = org.dpsoftware.portable.PortableMask.ready();
        if (System.getProperty("firefly.portable.root") != null && !MainSingleton.getInstance().config.isToggleLed()) portableReady = false;
        if (leds.length == 1) MainSingleton.getInstance().colorInUse = leds[0];
        leds = org.dpsoftware.portable.PortableMask.mask(leds);
        if (!portableReady) java.util.Arrays.fill(leds, Color.BLACK);
        // Effect is set via MQTT when using Full Firmware
        if (MainSingleton.getInstance().config.isFullFirmware()) {
            MainSingleton.getInstance().fireflyEffect = 100;
        } else {
            for (Enums.Effect ef : Enums.Effect.values()) {
                if (ef.getBaseI18n().equals(MainSingleton.getInstance().config.getEffect())) {
                    MainSingleton.getInstance().fireflyEffect = ef.ordinal() + 1;
                }
            }
        }
        if (!ManagerSingleton.getInstance().serialVersionOk) {
            UpgradeManager upgradeManager = new UpgradeManager();
            // Check if the connected device match the minimum firmware version requirements for this Firefly Luciferin version
            Boolean firmwareMatchMinRequirements = upgradeManager.firmwareMatchMinimumRequirements();
            if (firmwareMatchMinRequirements != null) {
                if (firmwareMatchMinRequirements) {
                    ManagerSingleton.getInstance().serialVersionOk = true;
                }
            }
        } else {
            int i = 0, j = -1;
            byte[] ledsArray = new byte[(MainSingleton.getInstance().ledNumber * 3) + Constants.SERIAL_PARAMS];
            // DPsoftware checksum
            int ledsCountHi = ((MainSingleton.getInstance().ledNumHighLowCount) >> 8) & 0xff;
            int ledsCountLo = (MainSingleton.getInstance().ledNumHighLowCount) & 0xff;
            int loSecondPart = (MainSingleton.getInstance().ledNumHighLowCountSecondPart) & 0xff;
            int brightnessToSend = (AudioSingleton.getInstance().AUDIO_BRIGHTNESS == 255 ? CommonUtility.getNightBrightness() : AudioSingleton.getInstance().AUDIO_BRIGHTNESS) & 0xff;
            int gpioToSend = (MainSingleton.getInstance().gpio) & 0xff;
            int baudRateToSend = (MainSingleton.getInstance().baudRate) & 0xff;
            int whiteTempToSend = (MainSingleton.getInstance().config.getWhiteTemperature()) & 0xff;
            int fireflyEffectToSend = (MainSingleton.getInstance().fireflyEffect) & 0xff;
            if (!portableReady) { brightnessToSend = 0; fireflyEffectToSend = 1; }
            int enableLdr = (MainSingleton.getInstance().config.isEnableLDR() ? 1 : 2) & 0xff;
            int ldrTurnOff = (MainSingleton.getInstance().config.isLdrTurnOff() ? 1 : 2) & 0xff;
            int ldrInterval = (MainSingleton.getInstance().config.getLdrInterval()) & 0xff;
            int ldrMin = (MainSingleton.getInstance().config.getLdrMin()) & 0xff;
            int ldrActionToUse = (MainSingleton.getInstance().ldrAction) & 0xff;
            int colorModeToSend = (MainSingleton.getInstance().config.getColorMode()) & 0xff;
            int colorOrderToSend = (MainSingleton.getInstance().colorOrder) & 0xff;
            // Pins is set to +10 because null values are zero, so GPIO 0 is 10, GPIO 1 is 11.
            int relayPinToSend = (MainSingleton.getInstance().relayPin >= 0 ? MainSingleton.getInstance().relayPin + 10 : 0) & 0xff;
            int relayInvToSend = (MainSingleton.getInstance().relayInv ? 11 : 10) & 0xff;
            int sbPinToSend = (MainSingleton.getInstance().sbPin >= 0 ? MainSingleton.getInstance().sbPin + 10 : 0) & 0xff;
            int ldrPinToSend = (MainSingleton.getInstance().ldrPin >= 0 ? MainSingleton.getInstance().ldrPin + 10 : 0) & 0xff;
            int gpioClockToSend = (MainSingleton.getInstance().gpioClockPin) & 0xff;
            ledsArray[++j] = (byte) ('D');
            ledsArray[++j] = (byte) ('P');
            ledsArray[++j] = (byte) ('s');
            ledsArray[++j] = (byte) ('o');
            ledsArray[++j] = (byte) ('f');
            ledsArray[++j] = (byte) ('t');
            ledsArray[++j] = (byte) (ledsCountHi);
            ledsArray[++j] = (byte) (ledsCountLo);
            ledsArray[++j] = (byte) (loSecondPart);
            ledsArray[++j] = (byte) (brightnessToSend);
            ledsArray[++j] = (byte) (gpioToSend);
            ledsArray[++j] = (byte) (baudRateToSend);
            ledsArray[++j] = (byte) (whiteTempToSend);
            ledsArray[++j] = (byte) (fireflyEffectToSend);
            ledsArray[++j] = (byte) (enableLdr);
            ledsArray[++j] = (byte) (ldrTurnOff);
            ledsArray[++j] = (byte) (ldrInterval);
            ledsArray[++j] = (byte) (ldrMin);
            ledsArray[++j] = (byte) (ldrActionToUse);
            ledsArray[++j] = (byte) (colorModeToSend);
            ledsArray[++j] = (byte) (colorOrderToSend);
            ledsArray[++j] = (byte) (relayPinToSend);
            ledsArray[++j] = (byte) (relayInvToSend);
            ledsArray[++j] = (byte) (sbPinToSend);
            ledsArray[++j] = (byte) (ldrPinToSend);
            ledsArray[++j] = (byte) (gpioClockToSend);
            ledsArray[++j] = (byte) ((ledsCountHi ^ ledsCountLo ^ loSecondPart ^ brightnessToSend ^ gpioToSend ^ baudRateToSend ^ whiteTempToSend ^ fireflyEffectToSend
                    ^ enableLdr ^ ldrTurnOff ^ ldrInterval ^ ldrMin ^ ldrActionToUse ^ colorModeToSend ^ colorOrderToSend ^ relayPinToSend ^ relayInvToSend ^ sbPinToSend ^ ldrPinToSend ^ gpioClockToSend ^ 0x55));
            MainSingleton.getInstance().ldrAction = 1;
            if (leds.length == 1) {
                MainSingleton.getInstance().colorInUse = leds[0];
                while (i < MainSingleton.getInstance().ledNumber) {
                    ledsArray[++j] = (byte) leds[0].getRed();
                    ledsArray[++j] = (byte) leds[0].getGreen();
                    ledsArray[++j] = (byte) leds[0].getBlue();
                    i++;
                }
                boolean toggleLed = (leds[0].getRed() != 0 || leds[0].getGreen() != 0 || leds[0].getBlue() != 0);
                if (toggleLed != MainSingleton.getInstance().config.isToggleLed()) {
                    MainSingleton.getInstance().config.setToggleLed(toggleLed);
                }
            } else {
                while (i < MainSingleton.getInstance().ledNumber) {
                    ledsArray[++j] = (byte) leds[i].getRed();
                    ledsArray[++j] = (byte) leds[i].getGreen();
                    ledsArray[++j] = (byte) leds[i].getBlue();
                    i++;
                }
            }
            if (MainSingleton.getInstance().output != null) {
                MainSingleton.getInstance().output.write(ledsArray);
            }
        }
    }

    /**
     * Check SOLID LEDs config and refresh LED strip state accordingly
     * This function works with GlowWormLuciferin Light, MQTT version does not need it
     */
    public void manageSolidLed() {
        ScheduledExecutorService scheduledExecutorService = Executors.newScheduledThreadPool(2);
        scheduledExecutorService.scheduleAtFixedRate(() -> {
            if (!MainSingleton.getInstance().RUNNING) {
                if (MainSingleton.getInstance().config.isToggleLed() && !MainSingleton.getInstance().config.isFullFirmware()) {
                    Color[] colorToUse = new Color[1];
                    if (MainSingleton.getInstance().colorInUse == null) {
                        String[] color = MainSingleton.getInstance().config.getColorChooser().split(",");
                        colorToUse[0] = new Color(Integer.parseInt(color[0]), Integer.parseInt(color[1]), Integer.parseInt(color[2]));
                        MainSingleton.getInstance().config.setBrightness(Integer.parseInt(color[3]));
                    } else {
                        colorToUse[0] = MainSingleton.getInstance().colorInUse;
                    }
                    try {
                        if (MainSingleton.getInstance().serial != null && MainSingleton.getInstance().serial.isOpen()) {
                            sendColorsViaUSB(colorToUse);
                        }
                    } catch (IOException e) {
                        log.error(e.getMessage());
                    }
                }
            }
        }, 2, 100, TimeUnit.MILLISECONDS);
    }

    /**
     * Handle an event on the serial port. Read the data and print it.
     *
     * @param inputLine input string
     */
    public void handleSerialEvent(String inputLine) {
        org.dpsoftware.portable.PortableMask.received(inputLine);
        try {
            log.debug(inputLine);
            GuiSingleton.getInstance().deviceTableData.forEach(glowWormDevice -> {
                if (glowWormDevice.getDeviceName().equals(Constants.USB_DEVICE)) {
                    if (!MainSingleton.getInstance().config.isMqttEnable() && MainSingleton.getInstance().config.isFullFirmware()) {
                        GuiSingleton.getInstance().deviceTableData.forEach(gwDevice -> {
                            if (glowWormDevice.getMac().equals(gwDevice.getMac())) {
                                gwDevice.setLastSeen(MainSingleton.getInstance().formatter.format(new Date()));
                            }
                        });
                    }
                    glowWormDevice.setLastSeen(MainSingleton.getInstance().formatter.format(new Date()));
                    // Skipping the Setting LED loop from Glow Worm Luciferin Serial communication
                    if (!inputLine.contains(Constants.SETTING_LED_SERIAL)) {
                        if (inputLine.contains(Constants.SERIAL_VERSION)) {
                            String deviceVer = inputLine.replace(Constants.SERIAL_VERSION, "");
                            if (MainSingleton.getInstance().config.isCheckForUpdates() && Enums.SupportedDevice.ESP32_S3_CDC.name().equals(glowWormDevice.getDeviceBoard())) {
                                deviceVer = Constants.FORCE_FIRMWARE_AUTO_UPGRADE;
                            }
                            glowWormDevice.setDeviceVersion(deviceVer);
                        } else if (inputLine.contains(Constants.SERIAL_LED_NUM)) {
                            glowWormDevice.setNumberOfLEDSconnected(inputLine.replace(Constants.SERIAL_LED_NUM, ""));
                        } else if (inputLine.contains(Constants.SERIAL_BOARD)) {
                            glowWormDevice.setDeviceBoard(inputLine.replace(Constants.SERIAL_BOARD, ""));
                        } else if (inputLine.contains(Constants.SERIAL_MAC)) {
                            glowWormDevice.setMac(inputLine.replace(Constants.SERIAL_MAC, ""));
                        } else if (inputLine.contains(Constants.SERIAL_GPIO)) {
                            glowWormDevice.setGpio(inputLine.replace(Constants.SERIAL_GPIO, ""));
                        } else if (inputLine.contains(Constants.SERIAL_FIRMWARE)) {
                            glowWormDevice.setFirmwareType(inputLine.replace(Constants.SERIAL_FIRMWARE, ""));
                        } else if (inputLine.contains(Constants.SERIAL_MQTTTOPIC)) {
                            glowWormDevice.setMqttTopic(inputLine.replace(Constants.SERIAL_MQTTTOPIC, ""));
                        } else if (inputLine.contains(Constants.SERIAL_COLOR_MODE)) {
                            glowWormDevice.setColorMode(Enums.ColorMode.values()[Integer.parseInt(inputLine.replace(Constants.SERIAL_COLOR_MODE, "")) - 1].getI18n());
                        } else if (inputLine.contains(Constants.SERIAL_COLOR_ORDER)) {
                            glowWormDevice.setColorOrder(Enums.ColorOrder.findByValue(Integer.parseInt(inputLine.replace(Constants.SERIAL_COLOR_ORDER, ""))).name());
                        } else if (inputLine.contains(Constants.SERIAL_BAUDRATE)) {
                            boolean validBaudrate = true;
                            int receivedBaudrate = Integer.parseInt(inputLine.replace(Constants.SERIAL_BAUDRATE, ""));
                            if (!(receivedBaudrate >= 1 && receivedBaudrate <= Constants.MAX_BAUDRATE)) {
                                validBaudrate = false;
                            }
                            glowWormDevice.setBaudRate(validBaudrate ? Enums.BaudRate.findByValue(receivedBaudrate).getBaudRate() : Constants.DASH);
                        } else if ((!MainSingleton.getInstance().config.isFullFirmware() || !MainSingleton.getInstance().config.isMqttEnable()) && inputLine.contains(Constants.SERIAL_FRAMERATE)) {
                            MainSingleton.getInstance().FPS_GW_CONSUMER = Float.parseFloat(inputLine.replace(Constants.SERIAL_FRAMERATE, ""));
                        } else if (inputLine.contains(Constants.SERIAL_LDR)) {
                            MainSingleton.getInstance().ldrStrength = Integer.parseInt(inputLine.replace(Constants.SERIAL_LDR, ""));
                            glowWormDevice.setLdrValue(inputLine.replace(Constants.SERIAL_LDR, "") + Constants.PERCENT);
                        } else if (inputLine.contains(Constants.SERIAL_LDR_LDRPIN)) {
                            glowWormDevice.setLdrPin(inputLine.replace(Constants.SERIAL_LDR_LDRPIN, ""));
                        } else if (inputLine.contains(Constants.SERIAL_LDR_RELAYPIN)) {
                            glowWormDevice.setRelayPin(inputLine.replace(Constants.SERIAL_LDR_RELAYPIN, ""));
                        } else if (inputLine.contains(Constants.SERIAL_LDR_RELAYINV)) {
                            glowWormDevice.setRelayInvertedPin(inputLine.replace(Constants.SERIAL_LDR_RELAYINV, "").equals("1"));
                        } else if (inputLine.contains(Constants.SERIAL_LDR_SBPIN)) {
                            glowWormDevice.setSbPin(inputLine.replace(Constants.SERIAL_LDR_SBPIN, ""));
                        } else if (inputLine.contains(Constants.SERIAL_GPIO_CLOCK)) {
                            glowWormDevice.setGpioClock(inputLine.replace(Constants.SERIAL_GPIO_CLOCK, ""));
                        } else if (!MainSingleton.getInstance().getImprovActive().isEmpty() && inputLine.contains(Constants.SERIAL_IMPROV) || inputLine.contains(Constants.SERIAL_IMPROV_ETH)) {
                            MainSingleton.getInstance().improvActive = "";
                            MainSingleton.getInstance().guiManager.pipelineManager.startCapturePipeline();
                            log.info(CommonUtility.getWord(Constants.FIRMWARE_PROGRAM_NOTIFY_HEADER));
                            MainSingleton.getInstance().guiManager.showLocalizedNotification(CommonUtility.getWord(Constants.FIRMWARE_PROGRAM_NOTIFY),
                                    CommonUtility.getWord(Constants.FIRMWARE_PROGRAM_NOTIFY_HEADER), Constants.FIREFLY_LUCIFERIN, TrayIcon.MessageType.INFO);
                        }
                    }
                }
            });
        } catch (Exception e) {
            // We don't care about this exception, it's caused by unknown serial messages
        }
    }

    /**
     * Return the list of connected serial devices, available or not
     *
     * @return available devices
     */
    public Map<String, Boolean> getAvailableDevices() {
        Map<String, Boolean> availableDevice = new HashMap<>();
        SerialPort[] ports = SerialPort.getCommPorts();
        for (SerialPort port : ports) {
            availableDevice.put(port.getSystemPortName(), true);
        }
        return availableDevice;
    }

    /**
     * Send serialParams, this will cause a reboot on the microcontroller
     */
    public void sendSerialParams(int r, int g, int b) {
        java.awt.Color[] leds = new java.awt.Color[1];
        try {
            leds[0] = new java.awt.Color(r, g, b);
            sendColorsViaUSB(leds);
        } catch (IOException e) {
            log.error(e.getMessage());
        }
    }

    /**
     * Close serial communication and remove all attached listeners
     */
    public void closeSerial() {
        synchronized (org.dpsoftware.portable.PortableMask.class) { closeSerialLocked(); }
    }

    private void closeSerialLocked() {
        connectionGeneration++;
        if (maskHandshakeFuture != null) {maskHandshakeFuture.cancel(false);maskHandshakeFuture=null;}
        org.dpsoftware.portable.PortableMask.reset();
        log.debug("Closing serial connection");
        if (MainSingleton.getInstance().output != null) {
            try {
                MainSingleton.getInstance().output.flush();
                MainSingleton.getInstance().output.close();
            } catch (IOException e) {
                log.error(e.getMessage());
            }
        }
        if (MainSingleton.getInstance().serial != null) {
            MainSingleton.getInstance().serial.removeDataListener();
            MainSingleton.getInstance().serial.setDTRandRTS(false, false);
            MainSingleton.getInstance().serial.closePort();
        }
        MainSingleton.getInstance().output = null;
        MainSingleton.getInstance().serial = null;
        MainSingleton.getInstance().serialConnected = false;
        ManagerSingleton.getInstance().serialVersionOk = false;
    }

}
