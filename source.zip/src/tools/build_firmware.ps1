param([switch]$InstallTools)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$env:TEMP = Join-Path $projectRoot '.tmp'
$env:TMP = $env:TEMP
$env:PLATFORMIO_CORE_DIR = Join-Path $projectRoot '.cache/platformio'
$env:PIP_CACHE_DIR = Join-Path $projectRoot '.cache/pip'
$env:UV_CACHE_DIR = Join-Path $projectRoot '.cache/uv'
$env:PYTHONPYCACHEPREFIX = Join-Path $projectRoot '.cache/pycache'
$env:PYTHONUTF8 = '1'
New-Item -ItemType Directory -Force -Path $env:TEMP,$env:PIP_CACHE_DIR,$env:UV_CACHE_DIR,(Join-Path $projectRoot 'docs'),(Join-Path $projectRoot 'firmware') | Out-Null
$python = Join-Path $projectRoot '.venv/Scripts/python.exe'
if ($InstallTools) {
    if (!(Test-Path -LiteralPath $python)) {
        & python -m venv (Join-Path $projectRoot '.venv')
        if ($LASTEXITCODE) { throw 'Could not create project-local developer Python environment.' }
    }
    & $python -m pip install -r (Join-Path $PSScriptRoot 'firmware-build-requirements.lock')
    if ($LASTEXITCODE) { throw 'Firmware developer dependency installation failed.' }
}
if (!(Test-Path -LiteralPath $python)) { throw 'Developer build needs Python 3.12+ and -InstallTools once. The desktop application needs neither.' }
Push-Location (Join-Path $projectRoot 'upstream/glow_worm_luciferin')
try {
    if (Test-Path -LiteralPath '.git') {
        & git submodule update --init arduino_bootstrapper
        if ($LASTEXITCODE) { throw 'Pinned bootstrap source retrieval failed.' }
    } elseif (!(Test-Path -LiteralPath 'arduino_bootstrapper/src/BootstrapManager.h')) {
        throw 'Retained source archive is missing the pinned Arduino bootstrap source.'
    }
    & $python -m platformio run -c platformio-portable.ini 2>&1 | Tee-Object -FilePath (Join-Path $projectRoot 'docs/firmware-build.txt')
    if ($LASTEXITCODE) { throw 'Firmware compilation failed.' }
} finally { Pop-Location }
$binaryRoot = Join-Path $projectRoot 'build/firmware/portable_esp32'
Copy-Item -LiteralPath (Join-Path $binaryRoot 'firmware.bin') -Destination (Join-Path $projectRoot 'firmware/ESP32SyncLights-5.25.3-portable.2-app.bin')
Copy-Item -LiteralPath (Join-Path $binaryRoot 'firmware.factory.bin') -Destination (Join-Path $projectRoot 'firmware/ESP32SyncLights-5.25.3-portable.2-factory.bin')
& $python (Join-Path $PSScriptRoot 'firmware_manifest.py')
if ($LASTEXITCODE) { throw 'Firmware manifest export failed.' }

