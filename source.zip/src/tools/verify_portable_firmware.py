"""Board-only integration checks. Close desktop first; strip must be disconnected.
Only black DPsoft pixel frames are sent. Internal effects are tested with every LED masked.
Leaves 72 pixels, GPIO13, no skips, black/off after reset. No optical claims are made.
"""
from pathlib import Path
import json
import time
import zlib
import serial

root = Path(__file__).resolve().parents[1]
log = bytearray()
results = []
port = serial.Serial()
port.port, port.baudrate = "COM8", 500000
port.timeout, port.write_timeout = 0.1, 2
port.dtr = port.rts = False

def packet(count=72, effect=1):
    params = [0, (count-1)%250, (count-1)//250, 0, 13, 3, 65, effect,
              2, 2, 0, 0, 1, 1, 1, 0, 10, 0, 0, 255]
    checksum = 0x55
    for byte in params: checksum ^= byte
    return b"DPsoft" + bytes(params) + bytes([checksum]) + bytes(count * 3)

def command(count, skipped):
    bits = bytearray((count+7)//8)
    for index in skipped: bits[index//8] |= 1 << (index%8)
    canonical = f"GWPM1:{count}:{bits.hex().upper()}"
    crc = f"{zlib.crc32(canonical.encode()):08X}"
    return f"{canonical}:{crc}\n".encode(), f"mask:GWPM1:{count}:{crc}"

def collect(seconds):
    until = time.monotonic()+seconds
    collected=bytearray()
    while time.monotonic()<until: collected.extend(port.read(4096))
    log.extend(collected)
    return collected.decode("utf-8", errors="replace")

def expect(data, line, attempts=4):
    for _ in range(attempts):
        port.write(data); port.flush()
        reply=collect(0.45)
        if line in reply.splitlines(): return
    raise RuntimeError(f"Missing expected response {line}")

def baseline():
    for _ in range(12):
        port.write(packet()); port.flush(); collect(0.12)

try:
    port.open()
    initial=collect(1)
    baseline()
    statuses=collect(11)
    # Telemetry is emitted periodically; query side channel verifies main loop connectivity too.
    if "ver:5.25.3-portable.1" not in initial+statuses:
        statuses += collect(3)
    assert "ver:5.25.3-portable.1" in initial+statuses, "Wrong firmware telemetry version"
    results.append("Firmware version 5.25.3-portable.1 verified over live serial")
    mask,ack=command(72,[0,7,71])
    expect(mask,ack); expect(b"GWPM1?\n",ack)
    # Confirm NVS persistence through a hardware EN reset, not simply an in-memory query.
    port.rts=True; time.sleep(0.15); port.rts=False
    collect(3)
    expect(b"GWPM1?\n",ack)
    results.append("Physical mask survives hardware EN reset / NVS reload")
    bad=mask[:-3]+b"ZZ\n"
    expect(bad,"mask:ERROR:INVALID"); expect(b"GWPM1?\n",ack)
    expect(b"GWPM1:301:00:00000000\n","mask:ERROR:INVALID"); expect(b"GWPM1?\n",ack)
    expect(b"GWPM1:0:00:00000000\n","mask:ERROR:INVALID"); expect(b"GWPM1?\n",ack)
    expect(b"G"*120+b"\n","mask:ERROR:TOO_LONG"); expect(b"GWPM1?\n",ack)
    port.write(mask[:9]); collect(0.35)
    expect(b"GWPM1?\n",ack)
    results.append("Malformed CRC/count/overflow/truncation rejected; saved mask remains intact")
    # A mismatched DPsoft count must not alter the saved mask. Firmware output path is host tested.
    port.write(packet(73)); port.flush(); collect(0.4); expect(b"GWPM1?\n",ack)
    baseline()
    all_masked,all_ack=command(72,range(72)); expect(all_masked,all_ack)
    for effect in range(6,22):
        for _ in range(3): port.write(packet(effect=effect)); port.flush(); collect(0.1)
        expect(b"GWPM1?\n",all_ack)
    results.append("All 16 firmware effect IDs 6..21 remain responsive with every physical LED masked")
    baseline() # stop the internal animation while every pixel is still masked
    clear,clear_ack=command(72,[]); expect(clear,clear_ack)
    baseline()
    port.rts=True; time.sleep(0.15); port.rts=False; collect(3)
    expect(b"GWPM1?\n",clear_ack)
    baseline()
    final=collect(11)
    assert "gpio:13" in final and "lednum:72" in final and "effect:1" in final, final
    results.append("Final state after reboot: GPIO13, 72 pixels, persisted no-skip mask, black DPsoft stream; brightness0 commanded (upstream telemetry omits brightness)")
finally:
    if port.is_open:
        for _ in range(8): port.write(packet()); time.sleep(0.05)
        port.flush(); port.close()
    (root / "docs/firmware-hardware-telemetry.txt").write_bytes(log)
    (root / "docs/firmware-hardware-checks.json").write_text(json.dumps({"results":results,"strip_connected":False,"optical_validation":False},indent=2)+"\n")
print("PASS: "+"; ".join(results))
