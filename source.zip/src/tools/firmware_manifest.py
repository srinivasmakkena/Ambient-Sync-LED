"""Export hashes and pinned build provenance; never reads device backups/secrets."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
source = root / "upstream/glow_worm_luciferin"
output = root / "firmware"

def commit(path, pinned):
    if not (path / ".git").exists(): return pinned
    return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()

files = {}
for path in sorted(output.glob("ESP32SyncLights-*.bin")):
    files[path.name] = {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "flash_offset": "0x0" if "factory" in path.name else "0x10000"}
manifest = {
    "product": "ESP32 Sync Lights", "firmware_version": "5.25.3-portable.2",
    "board": "ESP32-D0WD-V3 / esp32dev, 4MB flash", "protocol": "GWPM1", "max_physical_leds": 300,
    "source_commit": commit(source, "4287d26a5595df33b105db937b5f165f7a51e519"),
    "bootstrap_commit": commit(source / "arduino_bootstrapper", "a73f4c67e4947717dd10f5ceb08bad5bf568d364"),
    "neopixelbus_commit": "e54c3231f8e730c921ed922f140481e9c65ca0ba",
    "platformio_core": "6.1.19", "platform": "55.03.38-1", "arduino_core": "3.3.8",
    "esp_idf": "5.5.4+sha.735507283d", "xtensa_compiler": "14.2.0+20260121",
    "arduinojson": "7.4.3", "pubsubclient": "2.8.0", "default_gpio": 13, "startup_brightness": 0,
    "default_physical_count": 72, "files": files,
    "rebuild": "tools/build_firmware.ps1 -InstallTools", "tests": "tools/test_firmware.ps1",
    "factory_flash_preserves_tail": "Factory binary covers boot/partition/app0; erase-all also removes prior saved settings."
}
(output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
(output / "SHA256SUMS.txt").write_text("".join(f"{v['sha256']}  {k}\n" for k,v in files.items()), encoding="utf-8")
if not (source / ".git").exists():
    print("Firmware app/factory hashes exported from retained pinned sources.")
    raise SystemExit(0)
patch = subprocess.check_output(["git", "-C", str(source), "diff", "--", "src/GlowWormLuciferin.cpp", "src/LedManager.cpp", "src/Globals.cpp"])
for relative in ("include/PhysicalMask.h", "include/PhysicalMaskCore.h", "src/PhysicalMask.cpp", "platformio-portable.ini"):
    diff = subprocess.run(["git", "-C", str(source), "diff", "--no-index", "--", "NUL", relative], capture_output=True)
    if diff.returncode not in (0,1): raise RuntimeError(diff.stderr.decode())
    patch += diff.stdout
(root / "docs/firmware-physical-mask.patch").write_bytes(patch)
print("Firmware app/factory hashes and retained-source patch exported.")

