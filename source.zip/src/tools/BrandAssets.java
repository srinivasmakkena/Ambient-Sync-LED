import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.nio.*;
import java.nio.file.*;
import java.io.*;

/** Deterministic neutral LED-strip/chip icon; no original brand art. */
public class BrandAssets {
    static BufferedImage draw(int width,int height,String name) {
        BufferedImage img=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);Graphics2D g=img.createGraphics();g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        int size=Math.min(width,height),x=(width-size)/2,y=(height-size)/2;g.translate(x,y);g.scale(size/128.,size/128.);
        g.setColor(new Color(20,35,50));g.fillRoundRect(5,5,118,118,26,26);g.setColor(name.contains("off")||name.contains("grey")?new Color(125,145,160):new Color(30,210,225));g.setStroke(new BasicStroke(6));g.drawRoundRect(27,27,74,74,14,14);
        for(int i=0;i<4;i++){g.fillRoundRect(37+i*15,12,8,16,3,3);g.fillRoundRect(37+i*15,100,8,16,3,3);}g.setColor(new Color(255,210,70));for(int i=0;i<3;i++)g.fillOval(40+i*18,53,12,12);
        g.dispose();return img;
    }
    public static void main(String[] args)throws Exception {
        Path resources=Path.of(args[0]),output=Path.of(args[1]);Files.createDirectories(output);
        try(var files=Files.walk(resources)){for(Path p:files.filter(f->f.getFileName().toString().matches(".*luciferin.*\\.png")).toList()){
            BufferedImage original=ImageIO.read(p.toFile());Path target=output.resolve(resources.relativize(p));Files.createDirectories(target.getParent());ImageIO.write(draw(original.getWidth(),original.getHeight(),p.getFileName().toString()),"png",target.toFile());
        }}
        BufferedImage icon=draw(128,128,"active");ByteArrayOutputStream png=new ByteArrayOutputStream();ImageIO.write(icon,"png",png);byte[] bytes=png.toByteArray();
        ByteBuffer ico=ByteBuffer.allocate(22+bytes.length).order(ByteOrder.LITTLE_ENDIAN);ico.putShort((short)0).putShort((short)1).putShort((short)1);ico.put((byte)128).put((byte)128).put((byte)0).put((byte)0).putShort((short)1).putShort((short)32).putInt(bytes.length).putInt(22).put(bytes);Files.write(output.resolve("ESP32-Sync-Lights.ico"),ico.array());
        System.out.println("Neutral icon assets generated");
    }
}
