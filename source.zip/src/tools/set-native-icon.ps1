param([string]$Executable,[string]$Icon)
$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
public static class PortableIcon {
 [DllImport("kernel32",CharSet=CharSet.Unicode,SetLastError=true)] static extern IntPtr BeginUpdateResource(string file,bool delete);
 [DllImport("kernel32",SetLastError=true)] static extern bool UpdateResource(IntPtr update,IntPtr type,IntPtr name,ushort lang,byte[] data,uint size);
 [DllImport("kernel32",SetLastError=true)] static extern bool EndUpdateResource(IntPtr update,bool discard);
 [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern IntPtr LoadLibraryEx(string path,IntPtr file,uint flags);
 [DllImport("kernel32")] static extern bool FreeLibrary(IntPtr lib);
 delegate bool EnumName(IntPtr lib,IntPtr type,IntPtr name,IntPtr param);
 delegate bool EnumLang(IntPtr lib,IntPtr type,IntPtr name,ushort lang,IntPtr param);
 [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern bool EnumResourceNames(IntPtr lib,IntPtr type,EnumName callback,IntPtr param);
 [DllImport("kernel32",CharSet=CharSet.Unicode)] static extern bool EnumResourceLanguages(IntPtr lib,IntPtr type,IntPtr name,EnumLang callback,IntPtr param);
 public static void Set(string exe,byte[] ico){
  var groups=new List<Tuple<IntPtr,ushort>>();var strings=new List<IntPtr>();IntPtr lib=LoadLibraryEx(exe,IntPtr.Zero,2);
  EnumResourceNames(lib,(IntPtr)14,(a,b,c,d)=>{IntPtr id=c;if(((long)c>>16)!=0){id=Marshal.StringToHGlobalUni(Marshal.PtrToStringUni(c));strings.Add(id);}EnumResourceLanguages(a,b,c,(e,f,h,l,j)=>{groups.Add(Tuple.Create(id,l));return true;},IntPtr.Zero);return true;},IntPtr.Zero);FreeLibrary(lib);
  if(groups.Count==0)groups.Add(Tuple.Create((IntPtr)1,(ushort)0));
  int size=BitConverter.ToInt32(ico,14),offset=BitConverter.ToInt32(ico,18);var png=new byte[size];Array.Copy(ico,offset,png,0,size);
  var group=new byte[20];Array.Copy(ico,0,group,0,6);Array.Copy(ico,6,group,6,12);group[18]=1;group[19]=0;
  IntPtr edit=BeginUpdateResource(exe,false);if(edit==IntPtr.Zero)throw new Exception("BeginUpdateResource: "+Marshal.GetLastWin32Error());bool okay=true;
  foreach(var id in groups){okay &= UpdateResource(edit,(IntPtr)3,(IntPtr)1,id.Item2,png,(uint)png.Length);okay &= UpdateResource(edit,(IntPtr)14,id.Item1,id.Item2,group,(uint)group.Length);}
  if(!EndUpdateResource(edit,!okay)||!okay)throw new Exception("Native icon update failed");foreach(var s in strings)Marshal.FreeHGlobal(s);
 }
}
'@
[PortableIcon]::Set($Executable,[IO.File]::ReadAllBytes($Icon))
