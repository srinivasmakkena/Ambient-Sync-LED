param([string]$Jdk = $env:JAVA_HOME, [string]$Output = '../rebuild', [string]$BaseRuntime = '../app', [string]$BuildRoot = 'build')
$ErrorActionPreference = 'Stop'
$project = Split-Path $PSScriptRoot -Parent
$buildDirectory=[IO.Path]::GetFullPath((Join-Path $project $BuildRoot))
if (-not $Jdk) { throw 'Pass -Jdk with a JDK26 directory or set JAVA_HOME (developer rebuild only).' }
$javac = Join-Path $Jdk 'bin/javac.exe'
$jar = Join-Path $Jdk 'bin/jar.exe'
if (-not (Test-Path $javac)) { throw 'A JDK 26 is required only for rebuilding. Set JAVA_HOME or pass -Jdk.' }
$env:TEMP = Join-Path $buildDirectory 'tmp'; $env:TMP = $env:TEMP
$destination = Join-Path $project $Output
New-Item -ItemType Directory -Force $destination,(Join-Path $destination 'app'),(Join-Path $destination 'config/layouts'),(Join-Path $buildDirectory 'desktop-classes'),$env:TEMP | Out-Null
$base = Join-Path $project $BaseRuntime
$baseExe=Join-Path $base 'Firefly Luciferin.exe'
if (-not (Test-Path $baseExe)) { $baseExe=Join-Path $base 'ESP32 Sync Lights.exe' }
Copy-Item -LiteralPath $baseExe -Destination (Join-Path $destination 'ESP32 Sync Lights.exe') -Force
(Get-Item -LiteralPath (Join-Path $destination 'ESP32 Sync Lights.exe')).IsReadOnly=$false
Copy-Item -LiteralPath (Join-Path $base 'runtime') -Destination $destination -Recurse -Force
Copy-Item -LiteralPath (Join-Path $base 'app/FireflyLuciferin-jar-with-dependencies.jar') -Destination (Join-Path $destination 'app') -Force
New-Item -ItemType Directory -Force (Join-Path $destination 'app/classes') | Out-Null
Copy-Item -LiteralPath (Join-Path $base 'app/classes/gstreamer') -Destination (Join-Path $destination 'app/classes') -Recurse -Force
$fatJar = Join-Path $destination 'app/FireflyLuciferin-jar-with-dependencies.jar'
$processor = Join-Path $project 'tools/dependencies/lombok-1.18.46.jar'
if (-not (Test-Path $processor)) { New-Item -ItemType Directory -Force (Split-Path $processor) | Out-Null; Invoke-WebRequest 'https://repo.maven.apache.org/maven2/org/projectlombok/lombok/1.18.46/lombok-1.18.46.jar' -OutFile $processor }
if ((Get-FileHash $processor).Hash -ne '01F7B1A015E33E2B62D5F5F37053306357AB1415FD181FCBA7794F5D198C1126') { throw 'Lombok dependency SHA256 mismatch' }
$sourceRoot = Join-Path $project 'upstream/firefly_luciferin/src/main/java'
$sources = (Get-ChildItem -LiteralPath $sourceRoot -Recurse -Filter '*.java' | Where-Object {$_.Name -ne 'module-info.java'}).FullName
$sources += (Get-ChildItem -LiteralPath (Join-Path $project 'portable-src') -Recurse -Filter '*.java').FullName
$classes = Join-Path $buildDirectory 'desktop-classes'
& $javac --release 25 --add-modules jdk.incubator.vector -cp "$fatJar;$processor" -processorpath $processor -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw 'Desktop Java compilation failed' }
& $jar uf $fatJar -C $classes org
if ($LASTEXITCODE -ne 0) { throw 'JAR update failed' }
@'
[Application]
app.classpath=$APPDIR\FireflyLuciferin-jar-with-dependencies.jar
app.mainclass=org.dpsoftware.portable.PortableStarter

[JavaOptions]
java-options=-Djpackage.app-version=2.28.4-portable.4
java-options=-XX:+UseZGC
java-options=-XX:+UseStringDeduplication
java-options=-Xms64m
java-options=-Xmx1024m
java-options=--add-modules=jdk.incubator.vector
java-options=--enable-native-access=ALL-UNNAMED
java-options=-Dfirefly.windows.captureApi=wgc
java-options=-XX:ErrorFile=$APPDIR\..\config\logs\hs_err_pid%p.log
'@ | Set-Content -LiteralPath (Join-Path $destination 'app/ESP32 Sync Lights.cfg') -Encoding utf8
$resources=Join-Path $project 'upstream/firefly_luciferin/src/main/resources'
& $javac --release 25 -d $classes (Join-Path $project 'tools/BrandAssets.java')
if ($LASTEXITCODE -ne 0) { throw 'Icon generator compilation failed' }
& (Join-Path $Jdk 'bin/java.exe') -cp $classes BrandAssets $resources (Join-Path $buildDirectory 'brand-resources')
if ($LASTEXITCODE -ne 0) { throw 'Icon generation failed' }
& $jar uf $fatJar -C $resources .
$filteredResources=Join-Path $buildDirectory 'filtered-resources'
New-Item -ItemType Directory -Force $filteredResources | Out-Null
$properties=(Get-Content -LiteralPath (Join-Path $resources 'project.properties') -Raw).Replace('${project.version}','2.28.4')
if($properties -match '\$\{'){throw 'Unresolved project.properties build metadata'}
$properties | Set-Content -LiteralPath (Join-Path $filteredResources 'project.properties') -Encoding ascii
& $jar uf $fatJar -C $filteredResources project.properties
if ($LASTEXITCODE -ne 0) { throw 'Filtered build metadata update failed' }
& $jar uf $fatJar -C (Join-Path $buildDirectory 'brand-resources') .
& (Join-Path $project 'tools/set-native-icon.ps1') -Executable (Join-Path $destination 'ESP32 Sync Lights.exe') -Icon (Join-Path $buildDirectory 'brand-resources/ESP32-Sync-Lights.ico')
Copy-Item -LiteralPath (Join-Path $project 'profiles/portable-default.yaml') -Destination (Join-Path $destination 'config/FireflyLuciferin.yaml') -Force
Copy-Item -LiteralPath (Join-Path $project 'PORTABLE-README.md') -Destination (Join-Path $destination 'README.md') -Force
Write-Output "Desktop built: $destination"



