import com.sun.tools.attach.VirtualMachine;
public class AttachCaptureProbe {
  public static void main(String[] args) throws Exception {
    var vm=VirtualMachine.attach(args[0]);
    try { vm.loadAgent(args[1],args[2]); } finally { vm.detach(); }
  }
}
