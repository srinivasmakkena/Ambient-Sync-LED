"""Deterministic source-level traces for the RX race and pinned NeoPixelBus buffer contract.

Uses Python models, not an executed ESP32/C++ binary. Reads the actual proposed firmware
and pinned driver sources to verify that the modeled branches/buffer operations exist.
No serial port is opened and no LEDs are touched.
"""
from pathlib import Path
from collections import deque
import unittest

root = Path(__file__).resolve().parents[1]
source = root / "upstream/glow_worm_luciferin"
CANONICAL_MASK = b"GWPM1:197:00000000000000000001000004000000000000000008000000:50CA6CC9\n"

class Uart:
    def __init__(self): self.rx = deque(); self.consumed = bytearray()
    def peek(self): return self.rx[0] if self.rx else -1
    def read(self):
        value=self.rx.popleft(); self.consumed.append(value); return value
    def feed(self, data): self.rx.extend(data)

class RmtBus:
    """Exact pinned Update operation order: send editing, copy into spare, swap pointers."""
    def __init__(self, pixels):
        self.editing = bytearray(pixels); self.spare = bytearray(len(pixels))
        self.sending = None; self.polls = 0; self.frames = []
    def show(self):
        if self.sending is not None: self.complete() # next Update waits for its previous TX
        self.sending = self.editing
        self.spare[:] = self.editing
        self.editing, self.spare = self.spare, self.editing
    def complete(self):
        self.frames.append(bytes(self.sending)); self.sending = None
    def can_show(self):
        self.polls += 1 # pinned zero-timeout query reports a timeout while sending
        return self.sending is None

class DotStarBus:
    def __init__(self, pixels): self.editing=bytearray(pixels); self.frames=[]; self.polls=0
    def show(self): self.frames.append(bytes(self.editing)) # synchronous transmitBytes/endTransaction

def masked_show(bus, channel_count, skipped):
    logical=bytes(bus.editing)
    for pixel in skipped: bus.editing[pixel*channel_count:(pixel+1)*channel_count]=bytes(channel_count)
    bus.show()
    for pixel in skipped: bus.editing[pixel*channel_count:(pixel+1)*channel_count]=logical[pixel*channel_count:(pixel+1)*channel_count]
    return logical

class FirmwareTraceTests(unittest.TestCase):
    def test_sources_match_model_contract(self):
        core=(source/"include/PhysicalMaskCore.h").read_text()
        self.assertIn("bus->Show(true);", core)
        self.assertNotIn("while (!bus->CanShow())", core)
        self.assertIn("if (!count) return true", core)
        loop=(source/"src/GlowWormLuciferin.cpp").read_text()
        self.assertIn("if (PhysicalMask::readSerial()) return;", loop)
        self.assertIn("const int serialPrefixByte = Serial.peek();", loop)
        self.assertIn("if (serialPrefixByte == 'D')", loop)
        self.assertIn("serialPrefixByte != 'D' && serialPrefixByte != 'G'", loop)
        driver=(root/"docs/NeoEsp32RmtXMethod.h").read_text()
        self.assertIn("rmt_tx_wait_all_done(_channel, 0)", driver)
        self.assertIn("rmt_transmit(_channel, _led_encoder, _dataEditing", driver)
        self.assertIn("memcpy(_dataSending, _dataEditing, _sizeData)", driver)
        self.assertIn("std::swap(_dataSending, _dataEditing)", driver)
        dotstar=(root/"docs/DotStarGenericMethod.h").read_text()
        self.assertIn("_wire.transmitBytes(_data, _sizeData)", dotstar)
        self.assertIn("_wire.endTransaction();", dotstar)

    def test_rx_arrival_between_peeks_reproduces_old_loss(self):
        uart=Uart()
        self.assertEqual(uart.peek(), -1) # first mask-parser peek: nothing available
        uart.feed(CANONICAL_MASK) # arrival in the exact race window
        self.assertNotEqual(uart.peek(), -1) # legacy binary branch is entered
        discarded=bytes(uart.read() for _ in range(6))
        self.assertEqual(discarded,b"GWPM1:")
        self.assertNotEqual(discarded,b"DPsoft") # failed prefix: command is now unrecoverable

    def test_rx_new_route_defers_new_mask_without_consuming(self):
        uart=Uart(); self.assertEqual(uart.peek(),-1)
        command=CANONICAL_MASK; uart.feed(command)
        front=uart.peek()
        if front>=0 and front not in (ord('D'),ord('G')): uart.read()
        self.assertNotEqual(front,ord('D')) # no binary read occurs
        self.assertEqual(bytes(uart.rx),command)
        self.assertEqual(uart.consumed,b"")
        self.assertEqual(uart.peek(),ord('G')) # next loop's mask parser receives intact command

    def test_rx_unknown_byte_resync_preserves_dp_prefix(self):
        uart=Uart(); uart.feed(b"\x00DPsoft")
        front=uart.peek()
        if front>=0 and front not in (ord('D'),ord('G')): uart.read()
        self.assertEqual(bytes(uart.rx),b"DPsoft")
        self.assertEqual(uart.peek(),ord('D'))

    def test_rgb_and_rgbw_restore_editing_leaves_sending_black(self):
        for channels in (3,4):
            pixels=bytes((i%254)+1 for i in range(198*channels))
            bus=RmtBus(pixels); skips=(0,72,98,171,197)
            logical=masked_show(bus,channels,skips)
            self.assertEqual(bytes(bus.editing),logical)
            self.assertIsNot(bus.editing,bus.sending)
            # Reading wire data later, after the restore, must still contain zeros at every gap.
            bus.complete()
            for i in range(198):
                expected=bytes(channels) if i in skips else pixels[i*channels:(i+1)*channels]
                self.assertEqual(bus.frames[-1][i*channels:(i+1)*channels],expected)
            self.assertEqual(bus.polls,0)
            # Repeated frames also maintain separation across alternating buffer swaps.
            for _ in range(20): masked_show(bus,channels,skips)
            bus.complete(); self.assertEqual(len(bus.frames),21)
            self.assertEqual(bus.polls,0)

    def test_dotstar_synchronous_restore(self):
        pixels=bytes((i%254)+1 for i in range(198*3))
        bus=DotStarBus(pixels); masked_show(bus,3,(0,72,197))
        self.assertEqual(bytes(bus.editing),pixels)
        for i in (0,72,197): self.assertEqual(bus.frames[0][i*3:(i+1)*3],bytes(3))
        self.assertEqual(bus.polls,0)

if __name__=="__main__": unittest.main(verbosity=2)
