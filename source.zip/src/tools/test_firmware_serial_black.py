"""Authorized board-only test: never sends nonzero brightness or RGB values.

Run only with external strip 5V disconnected and the desktop application closed.
The existing 197-position configuration is retained; no GPIO change or erase.
"""
import json
import time
from pathlib import Path
import serial

ROOT = Path(__file__).resolve().parents[1]
COMMAND = b"GWPM1:197:00000000000000000001000004000000000000000008000000:50CA6CC9\n"
ACK = "mask:GWPM1:197:50CA6CC9"
config = bytearray([0, 196, 0, 0, 255, 0, 0, 1, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255])
checksum = 0x55
for value in config:
    checksum ^= value
FRAME = b"DPsoft" + config + bytes([checksum]) + bytes(197 * 3)
lines, pending = [], bytearray()
start = time.monotonic()
first_version = None

def drain(port):
    global first_version
    data = port.read(port.in_waiting or 1)
    pending.extend(data)
    while b"\n" in pending:
        raw, _, rest = pending.partition(b"\n")
        pending[:] = rest
        line = raw.decode("utf-8", errors="replace").strip()
        stamp = round(time.monotonic() - start, 4)
        lines.append({"seconds": stamp, "line": line})
        if "ver:" in line and first_version is None:
            first_version = stamp

def wait_for(port, expected, timeout=3):
    mark = len(lines)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        drain(port)
        if any(item["line"] == expected for item in lines[mark:]):
            return True
    return False

result = {"port": "COM9", "baud": 500000, "physical_leds": 197,
          "brightness": 0, "rgb": "all zero", "external_strip_power": "OFF"}
port = serial.Serial()
port.port, port.baudrate, port.timeout = "COM9", 500000, 0.002
port.dtr, port.rts = False, False
try:
    port.open()
    port.write(FRAME)
    port.flush()
    port.write(COMMAND)
    result["initial_ack"] = wait_for(port, ACK)
    assert result["initial_ack"], "No exact layout ACK"
    warmup_end = time.monotonic() + 11
    while time.monotonic() < warmup_end:
        drain(port)
    result["open_to_first_version_seconds"] = first_version
    stress_start = time.monotonic()
    stress_mark = len(lines)
    next_frame, next_mask = stress_start, stress_start + 0.5
    frames, commands = 0, 0
    while time.monotonic() - stress_start < 60:
        now = time.monotonic()
        if now >= next_frame:
            port.write(FRAME)
            frames += 1
            next_frame += 1 / 30
        if now >= next_mask:
            port.write(COMMAND)
            commands += 1
            next_mask += 1
        drain(port)
    settle_end = time.monotonic() + 0.2
    while time.monotonic() < settle_end:
        drain(port)
    stress_lines = lines[stress_mark:]
    result.update(stress_seconds=round(time.monotonic() - stress_start, 3),
                  black_frames_sent=frames, mask_commands_sent=commands,
                  exact_stress_acks=sum(x["line"] == ACK for x in stress_lines),
                  rmt_errors=[x for x in stress_lines if "rmt:" in x["line"]],
                  mask_errors=[x for x in stress_lines if "mask:ERROR" in x["line"]],
                  version_seen=any("5.25.3-portable.2" in x["line"] for x in lines),
                  gpio13_seen=any(x["line"] == "gpio:13" for x in lines))
    assert result["exact_stress_acks"] >= commands, "Missing duplicate command ACK"
    assert not result["rmt_errors"], "Unexpected RMT errors"
    assert not result["mask_errors"], "Unexpected mask parser errors"
    assert result["version_seen"] and result["gpio13_seen"]
    port.write(FRAME)
    port.flush()
    port.rts = True
    time.sleep(0.15)
    port.rts = False
    reboot_end = time.monotonic() + 12
    while time.monotonic() < reboot_end:
        drain(port)
    port.write(b"GWPM1?\n")
    result["persisted_ack_after_reset"] = wait_for(port, ACK)
    assert result["persisted_ack_after_reset"], "Mask persistence not confirmed"
    port.write(FRAME)
    port.flush()
    result["passed"] = True
finally:
    if port.is_open:
        port.write(FRAME)
        port.flush()
        port.close()
    (ROOT / "docs/firmware-hardware-stress.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    (ROOT / "docs/firmware-hardware-serial.json").write_text(json.dumps(lines, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
