param([string]$Candidate='../app',[switch]$Zip,[string]$Version='1.0.4',[string]$OutputDirectory='..',[switch]$ReplaceGenerated)
$ErrorActionPreference='Stop'
$source=[IO.Path]::GetFullPath((Split-Path $PSScriptRoot -Parent))
$destination=[IO.Path]::GetFullPath((Join-Path $source $Candidate))
$output=[IO.Path]::GetFullPath((Join-Path $source $OutputDirectory))
if(-not(Test-Path (Join-Path $destination 'ESP32 Sync Lights.exe'))){throw 'Candidate must contain the root EXE'}
if(-not(Test-Path (Join-Path $destination 'app/ESP32 Sync Lights.cfg'))){throw 'Missing native application CFG'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
function Keep-Source([string]$relative){
 if($relative -match '(^|/)(\.git|\.venv|\.cache|\.tmp|\.home|__pycache__|build|rebuild|backups|\.pio)(/|$)' -or $relative -match '(^|/)\.env($|\.)'){return $false}
 if($relative -match '^(Start ESP32 Sync Lights\.cmd|Configure layout\.cmd|launch-portable\.ps1)$'){return $false}
 if($relative.StartsWith('upstream/glow_worm_luciferin/assets/CAD_schematics/') -or $relative -match 'ESP32SyncLights-5\.25\.3-portable\.1-(app|factory)\.bin$'){return $false}
 if($relative.StartsWith('upstream/glow_worm_luciferin/docs/static/firmware_build')){return $false}
 if($relative -match '^docs/(steps-1\.0\.4\.md|serial-ack-independent-review\.md|independent-serial-session-checks\.txt|independent-screen-test-checks\.txt|firmware-1\.0\.4[^/]*\.(md|txt|json))$'){return $true}
 if($relative -match '^docs/independent-(first-save|session|firmware-v2)[^/]*\.(txt|md|json)$'){return $true}
 if($relative -eq 'docs/independent-firmware-mask-checks.txt'){return $true}
 if($relative -match '^docs/(firmware-v1-to-v2\.patch|firmware-v2-driver-fix\.md|firmware-build(-driver)?\.txt|firmware-rmt-rx-tests\.txt|firmware-hardware-(stress|serial)\.(txt|json)|hardware-flash-verify\.txt|NeoPixelBus\.h|NeoEsp32RmtXMethod\.h|DotStarGenericMethod\.h)$'){return $true}
 if($relative.StartsWith('docs/')){return $relative -match '^docs/(steps-1\.0\.2\.md|independent-integrated-led-review\.md|independent-integrated-native-checks\.txt|independent-integrated-window-checks\.txt|stream-blink-repair\.md|independent-aspect-checks\.txt|independent-mask-pause-checks\.txt|independent-capture-lock-checks\.txt|integrated-settings\.png|PORTABLE-BUILD\.md|PORTABLE-NOTICE\.txt|windows-graphics-capture\.patch|portable-config\.patch|firmware-physical-mask\.patch|firmware-mask-tests\.txt|firmware-hardware-checks\.json|firmware-verify-flash\.txt|firmware-factory-defaults\.txt)$'}
 return $true
}
function Write-Package([string]$InputRoot,[string]$ZipPath,[string]$TopFolder,[bool]$SourceOnly){
 $stream=[IO.File]::Open($ZipPath,[IO.FileMode]::Create,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
 $archive=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
 try {
  Get-ChildItem -LiteralPath $InputRoot -File -Recurse -Force | ForEach-Object {
   $relative=$_.FullName.Substring($InputRoot.Length+1).Replace('\','/')
   if($SourceOnly){if(-not(Keep-Source $relative)){return}}
   else {
    if($relative -match '^(app/|runtime/|firmware/|legal/|README\.md$|ESP32 Sync Lights\.exe$)'){}
    else{return}
   }
   [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$_.FullName,"$TopFolder/$relative",[IO.Compression.CompressionLevel]::Optimal)|Out-Null
  }
  if(-not $SourceOnly){
   [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,(Join-Path $source 'profiles/portable-default.yaml'),"$TopFolder/config/FireflyLuciferin.yaml",[IO.Compression.CompressionLevel]::Optimal)|Out-Null
  }
 }finally{$archive.Dispose()}
}
Write-Output "Candidate: $destination"
if($Zip){
 New-Item -ItemType Directory -Force $output|Out-Null
 $runtimeZip=Join-Path $output 'lights.zip'
 $sourceZip=Join-Path $output 'src.zip'
 if(!$ReplaceGenerated -and ((Test-Path $runtimeZip) -or (Test-Path $sourceZip))){throw 'Generated ZIP exists; use ReplaceGenerated for unpublished output'}
 Write-Package $destination $runtimeZip 'app' $false
 Write-Package $source $sourceZip 'src' $true
 Get-FileHash -LiteralPath $runtimeZip,$sourceZip|ForEach-Object{"$($_.Hash.ToLower())  $([IO.Path]::GetFileName($_.Path))"}|Set-Content -LiteralPath (Join-Path $output 'checksums.txt') -Encoding ascii
 Get-Item -LiteralPath $runtimeZip,$sourceZip|Select-Object FullName,Length
}



