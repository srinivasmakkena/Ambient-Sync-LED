$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$env:TEMP = Join-Path $projectRoot '.tmp'
$env:TMP = $env:TEMP
$env:PLATFORMIO_CORE_DIR = Join-Path $projectRoot '.cache/platformio'
New-Item -ItemType Directory -Force -Path $env:TEMP,(Join-Path $projectRoot 'build'),(Join-Path $projectRoot 'docs') | Out-Null
$gccRoot = Join-Path $env:PLATFORMIO_CORE_DIR 'packages/toolchain-gccmingw32/bin'
$env:PATH = $gccRoot + ';' + $env:PATH
Push-Location $projectRoot
try {
    $python = Join-Path $projectRoot '.venv/Scripts/python.exe'
    if (!(Test-Path (Join-Path $gccRoot 'g++.exe'))) {
        & $python -m platformio pkg install -g -t platformio/toolchain-gccmingw32@1.50100.0
        if ($LASTEXITCODE) { throw 'Project-local host compiler installation failed.' }
    }
    & (Join-Path $gccRoot 'g++.exe') -std=c++11 -Wall -Wextra -Werror -static -I tests/firmware -I upstream/glow_worm_luciferin/include tests/firmware/mask_test.cpp upstream/glow_worm_luciferin/src/PhysicalMask.cpp -o build/firmware-mask-tests.exe
    if ($LASTEXITCODE) { throw 'Firmware host tests did not compile.' }
    & ./build/firmware-mask-tests.exe | Tee-Object -FilePath docs/firmware-mask-tests.txt
    if ($LASTEXITCODE) { throw 'Firmware host tests failed.' }
} finally { Pop-Location }
