#include "PhysicalMaskCore.h"
#include <array>
#include <vector>
#include <cassert>
#include <iostream>
template<unsigned N> struct Color {
 std::array<unsigned char,N> bytes{};
 Color(unsigned v=0){bytes.fill(static_cast<unsigned char>(v));}
 bool operator==(const Color& other)const{return bytes==other.bytes;}
};
template<class C,bool Async> struct Bus {
 std::vector<C> editing,sending,wire;
 Bus(unsigned count):editing(count),sending(count){}
 unsigned PixelCount(){return unsigned(editing.size());}
 C GetPixelColor(unsigned i){return editing.at(i);}
 void SetPixelColor(unsigned i,C c){editing.at(i)=c;}
 void ClearTo(C c){for(auto& v:editing)v=c;}
 bool CanShow(){assert(false);return false;}
 void Show(bool maintain=true){assert(maintain);if(Async){sending=editing;editing.swap(sending);wire=sending;}else wire=editing;}
};
template<unsigned Channels,bool Async> void verify(unsigned count){
 using C=Color<Channels>;Bus<C,Async> bus(count);PhysicalMaskCore::State state;
 state.count=count;state.bits[0]|=1;state.bits[(count/2)/8]|=1<<((count/2)%8);state.bits[(count-1)/8]|=1<<((count-1)%8);
 for(unsigned frame=0;frame<8;frame++){
  for(unsigned i=0;i<count;i++)for(unsigned ch=0;ch<Channels;ch++)bus.editing[i].bytes[ch]=1+(i+ch+frame)%254;
  auto logical=bus.editing;
  PhysicalMaskCore::show<Bus<C,Async>,C>(&bus,state,[]{assert(false);});
  assert(bus.editing==logical);
  for(unsigned i=0;i<count;i++)assert(bus.wire[i]==(state.blocked(i,count)?C(0):logical[i]));
  if(Async)assert(bus.sending==bus.wire);
 }
 state.count=0;state.corrupt=false;state.bits[0]=0;
 PhysicalMaskCore::show<Bus<C,Async>,C>(&bus,state,[]{assert(false);});
 for(auto c:bus.wire)assert(c==C(0));
 state.count=count+1;
 PhysicalMaskCore::show<Bus<C,Async>,C>(&bus,state,[]{assert(false);});
 for(auto c:bus.wire)assert(c==C(0));
}
int main(){for(unsigned count:{1u,72u,300u}){verify<3,true>(count);verify<4,true>(count);verify<3,false>(count);}std::cout<<"PASS RGB/RGBW asynchronous distinct editing/sending buffers and synchronous DotStar model: all channels, first/middle/last gaps, restore, missing/count mismatch OFF, no polling\n";}
