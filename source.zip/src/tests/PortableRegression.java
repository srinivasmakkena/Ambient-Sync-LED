import org.dpsoftware.portable.*;
import org.dpsoftware.*;
import org.dpsoftware.config.*;
import org.dpsoftware.managers.*;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import java.awt.Color;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class PortableRegression {
    static int assertions;
    static void check(boolean test,String reason){assertions++;if(!test)throw new AssertionError(reason);}
    public static void main(String[] args)throws Exception {
        Path root=Path.of(args[0]).toAbsolutePath();Path temp=root.resolve("build/test-config");Files.createDirectories(temp);
        System.setProperty("firefly.config.dir",temp.toString());System.setProperty("user.home",root.resolve(".home").toString());System.setProperty("java.io.tmpdir",root.resolve(".tmp").toString());System.setProperty(Constants.LUCIFERIN_PLACEHOLDER,temp.toString());System.setProperty("firefly.portable.root",root.toString());
        MainSingleton.getInstance().bundle=ResourceBundle.getBundle(Constants.MSG_BUNDLE,Locale.ENGLISH);
        PortableLayout p=new PortableLayout();p.top=4;p.right=3;p.bottom=5;p.left=2;
        for(String corner:List.of("Top left","Top right","Bottom right","Bottom left"))for(String direction:List.of("Clockwise","Anticlockwise"))for(int offset:new int[]{-41,-1,0,1,41,Integer.MAX_VALUE,Integer.MIN_VALUE}) {
            p.corner=corner;p.direction=direction;p.offset=offset;p.validate();Set<Integer> used=new HashSet<>();for(int i=0;i<p.count();i++)used.add(p.slot(i));check(used.size()==p.count(),"Mapping must be a physical-position permutation");
            p.skipped="";var full=p.matrix(5120,1440,0,0);p.skipped="1, 4-6, 14";var masked=p.matrix(5120,1440,0,0);
            for(int i=1;i<=p.count();i++){var a=full.get(i);var b=masked.get(i);check(a.getX()==b.getX()&&a.getY()==b.getY()&&a.getWidth()==b.getWidth()&&a.getHeight()==b.getHeight(),"Gap shifted physical "+i);check(b.getX()>=0&&b.getY()>=0&&b.getWidth()>0&&b.getHeight()>0&&b.getX()+b.getWidth()<=5120&&b.getY()+b.getHeight()<=1440,"Coordinate bounds");check(b.isActive()!=p.gaps().get(i-1),"Inactive mask");}
        }
        p.top=72;p.right=0;p.bottom=0;p.left=0;p.offset=0;p.corner="Top left";p.direction="Clockwise";p.skipped="1,8,72";
        check(p.maskCommand().equals("GWPM1:72:810000000000000080:9C7EC4C6\n"),"Firmware CRC canonical vector");
        check(p.matrix(720,240,0,0).get(1).getX()==0,"Clockwise from TL starts at left of top");p.direction="Anticlockwise";check(p.matrix(720,240,0,0).get(1).getX()==710,"Anticlockwise top-only reverses");p.direction="Clockwise";
        for(int count:new int[]{1,72,250,251,300}){byte[] b=PositionTest.packet(count,count-1,32);check(b.length==27+count*3,"Frame length");check((b[10]&255)==255&&(b[25]&255)==255,"Position test must preserve GPIO and clock");check((b[6]&255)*256+(b[7]&255)+1+(b[8]&255)*250==count,"DPsoft count chunks");int crc=0x55;for(int i=6;i<26;i++)crc^=b[i]&255;check((b[26]&255)==crc,"DPsoft checksum");for(int i=0;i<count;i++)check((b[27+i*3]&255)==(i==count-1?64:0),"Only one pixel");}
        check(UpgradeManager.versionNumberToNumber("5.25.3-portable.1")==UpgradeManager.versionNumberToNumber("5.25.3"),"Portable version suffix compatibility");
        Configuration config=new YAMLMapper().readValue(root.resolve("profiles/portable-default.yaml").toFile(),Configuration.class);config.setToggleLed(true);p.save(PortableLayout.file());PortableLayout.loadAndApply(config);check(!config.isToggleLed()&&!config.isStartWithSystem()&&!config.isCheckForUpdates(),"Every startup is OFF and disables installer/autostart");
        MainSingleton.getInstance().config=config;FireflyLuciferin.setLedNumber(config.getDefaultLedMatrix());ManagerSingleton.getInstance().serialVersionOk=true;config.setBrightness(32);ByteArrayOutputStream output=new ByteArrayOutputStream();MainSingleton.getInstance().output=output;MainSingleton.getInstance().gpio=255;MainSingleton.getInstance().gpioClockPin=255;
        SerialManager serial=new SerialManager();PortableMask.reset();serial.sendColorsViaUSB(new Color[]{Color.WHITE});byte[] b=output.toByteArray();int start=b.length-(27+72*3);check((b[start+9]&255)==0&&(b[start+13]&255)==1,"No ACK means brightnesszero/effect1");for(int i=start+27;i<b.length;i++)check(b[i]==0,"No ACK means all channels zero");
        PortableMask.received(p.acknowledgement());
        output.reset();serial.sendColorsViaUSB(new Color[]{Color.WHITE});b=output.toByteArray();start=b.length-(27+72*3);check((b[start+9]&255)==0&&(b[start+13]&255)==1,"OFF gates stale capture frames even with mask ACK");for(int i=start+27;i<b.length;i++)check(b[i]==0,"OFF capture channels black");config.setToggleLed(true);
        for(Enums.Effect effect:Enums.Effect.values()) {output.reset();config.setEffect(effect.getBaseI18n());serial.sendColorsViaUSB(new Color[]{Color.WHITE});b=output.toByteArray();start=b.length-(27+72*3);check((b[start+9]&255)==32,"ACK releases desired brightness for "+effect);for(int i=0;i<72;i++)for(int c=0;c<3;c++)check((b[start+27+i*3+c]&255)==(p.gaps().get(i)?0:255),"Gap stays black in "+effect);}
        PortableMask.received("mask:NONE");output.reset();serial.sendColorsViaUSB(new Color[]{Color.WHITE});b=output.toByteArray();start=b.length-(27+72*3);check((b[start+9]&255)==0,"Reboot/missing mask resets authorization");
        p.top=Integer.MAX_VALUE;p.right=Integer.MAX_VALUE;p.bottom=3;boolean rejected=false;try{p.validate();}catch(IllegalArgumentException e){rejected=true;}check(rejected,"Reject overflow sidecounts");
        String result="PASS: "+assertions+" assertions; corners/direction/offset/gaps, all-effects packet masking, ACK failclosed, DPsoft header/pin preservation, version compatibility, startup OFF\nJAVA="+System.getProperty("java.home");Files.writeString(root.resolve("docs/portable-regression.txt"),result);System.out.println(result);System.exit(0);
    }
}
