import java.awt.Color;
import java.nio.file.*;
import java.util.*;
import org.dpsoftware.portable.*;
import org.dpsoftware.config.Configuration;
import org.dpsoftware.managers.UpgradeManager;

public class ReviewerPortableChecks {
  static long checks;
  static void check(boolean ok,String label) { checks++; if(!ok) throw new AssertionError(label); }
  public static void main(String[] args) throws Exception {
    System.setProperty("firefly.config.dir",Path.of(args[0]).toAbsolutePath().toString());
    Files.createDirectories(Path.of(args[0]));
    var p=new PortableLayout(); p.top=72;p.skipped="1,8,72";
    check(p.maskCommand().equals("GWPM1:72:810000000000000080:9C7EC4C6\n"),"firmware golden vector");
    check(p.acknowledgement().equals("mask:GWPM1:72:9C7EC4C6"),"exact ack");
    for(int n=1;n<=300;n++) {
      p.top=n/4;p.right=n/4;p.bottom=n/4;p.left=n-3*(n/4);
      p.skipped=n==1?"1":"1,"+n;
      for(String corner:List.of("Top left","Top right","Bottom right","Bottom left"))
        for(String direction:List.of("Clockwise","Anticlockwise"))
          for(int offset:new int[]{-301,-1,0,1,301}) {
            p.corner=corner;p.direction=direction;p.offset=offset;
            var matrix=p.matrix(1920,1080,0,0);
            check(matrix.size()==n,"physical count");
            var slots=new HashSet<Integer>();
            for(int i=0;i<n;i++) {
              slots.add(p.slot(i));var c=matrix.get(i+1);
              check(c.getX()>=0 && c.getY()>=0 && c.getX()+c.getWidth()<=1920 && c.getY()+c.getHeight()<=1080,"capture bounds");
              check(c.isActive()==!(i==0 || i==n-1),"gap physical index");
            }
            check(slots.size()==n,"corner/direction/offset permutation");
            var masked=p.mask(new Color[]{Color.WHITE});
            check(masked.length==n && masked[0].equals(Color.BLACK) && masked[n-1].equals(Color.BLACK),"solid gaps");
          }
      byte[] frame=PositionTest.packet(n,n-1,32);
      check(frame.length==27+n*3,"frame size");
      check((frame[10]&255)==255 && (frame[25]&255)==255,"unchanged GPIO pins");
      check((frame[7]&255)+250*(frame[8]&255)+1==n,"wire count");
      int crc=0x55;for(int i=6;i<26;i++)crc^=frame[i]&255;
      check((frame[26]&255)==crc,"frame checksum");
      for(int i=0;i<n;i++) check((frame[27+i*3]&255)==(i==n-1?64:0),"single pixel only");
    }
    check(UpgradeManager.versionNumberToNumber("5.25.3-portable.1")==UpgradeManager.versionNumberToNumber("5.25.3"),"firmware suffix compatibility");
    var cfg=new Configuration();cfg.setScreenResX(1920);cfg.setScreenResY(1080);cfg.setToggleLed(true);cfg.setCheckForUpdates(true);cfg.setStartWithSystem(true);
    PortableLayout.loadAndApply(cfg);
    check(!cfg.isToggleLed() && !cfg.isCheckForUpdates() && !cfg.isStartWithSystem(),"every-launch defaults off");
    String result="PASS: "+checks+" independent physical mapping, gap, DPsoft packet, version and startup checks\nJAVA="+System.getProperty("java.home");
    Files.writeString(Path.of(args[0],"reviewer-checks.txt"),result);
    System.out.println(result);
  }
}
