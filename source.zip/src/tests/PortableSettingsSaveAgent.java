import org.dpsoftware.*;
import org.dpsoftware.gui.*;
import org.dpsoftware.gui.controllers.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ComboBox;
import java.lang.instrument.Instrumentation;
import java.nio.file.*;
public class PortableSettingsSaveAgent {
 public static void agentmain(String arguments,Instrumentation instrumentation) {
  String[] parts=arguments.split("\\|",2);
  Platform.runLater(()->{
   try {
    var main=MainSingleton.getInstance();
    var loader=new FXMLLoader(GuiManager.class.getResource("settings.fxml"),main.bundle);
    javafx.scene.Parent root=loader.load();var stage=new javafx.stage.Stage();stage.setScene(new javafx.scene.Scene(root)); SettingsController controller=loader.getController();
    var mode=SettingsController.class.getDeclaredField("modeTabController");mode.setAccessible(true);Object tab=mode.get(controller);
    var field=tab.getClass().getDeclaredField("serialPort");field.setAccessible(true);((ComboBox<String>)field.get(tab)).setValue(parts[0]);((ComboBox<String>)field.get(tab)).getEditor().setText(parts[0]);
    main.config.setToggleLed(false);main.config.setBrightness(0);
    controller.save(null);
    Files.writeString(Path.of(parts[1]),"Saved via actual SettingsController.save(null): port="+main.config.getOutputDevice()+" version="+main.config.getConfigVersion()+" toggle="+main.config.isToggleLed()+" count="+main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix()).size()+" restart="+main.isRestartNeeded());
   } catch(Throwable error) {try(var writer=new java.io.PrintWriter(parts[1])){error.printStackTrace(writer);}catch(Exception ignored){}}
  });
 }
}


