import java.nio.file.*;
import org.dpsoftware.grabber.ImageProcessor;
import org.freedesktop.gstreamer.Gst;
public class ReviewerGStreamerPath {
 public static void main(String[] args) throws Exception {
  Path root=Path.of(args[0]).toAbsolutePath();
  System.setProperty("firefly.portable.root",root.toString());
  System.setProperty("firefly.config.dir",root.resolve("config").toString());
  System.setProperty("user.home",root.resolve(".home").toString());
  System.setProperty("java.io.tmpdir",root.resolve(".tmp").toString());
  ImageProcessor processor=new ImageProcessor(false);
  String path=processor.getInstallationPath();
  if(!Files.isDirectory(Path.of(path))) throw new AssertionError("Capture library directory does not exist: "+path);
  processor.initGStreamerLibraryPaths();
  Gst.init("ReviewerNativeLibraries");
  String result="PASS: GStreamer native libraries initialized from relocated path\nPATH="+path+"\nJAVA="+System.getProperty("java.home");
  Files.writeString(root.resolve("config/reviewer-gstreamer.txt"),result);
  Gst.deinit();
  System.out.println(result);
 }
}
