"""Read-only ZIP/JAR integrity, exclusion, firmware hash and retained-notice audit."""
from pathlib import Path, PurePosixPath
import hashlib, io, json, re, sys, zipfile

archive = Path(sys.argv[1])
with zipfile.ZipFile(archive) as outer:
    assert outer.testzip() is None, "outer archive CRC failure"
    names = outer.namelist()
    assert len(names)==len(set(names)), "duplicate outer archive entries"
    for name in names:
        parts = PurePosixPath(name).parts
        assert not name.startswith(("/", "\\")) and ".." not in parts and not re.match(r"^[A-Za-z]:", name), name
        assert not any(p.lower() in {".env", ".git", ".cache", ".tmp", ".home", ".venv", "__pycache__", "backups", "logs", "rebuild", "build"} for p in parts), name
        assert not name.lower().endswith(("secrets.env", ".pyc", ".pyo", ".log")), name
    def locate(suffix):
        found = [n for n in names if n.endswith(suffix)]
        if "/source/" not in suffix:
            found = [n for n in found if "/source/" not in n]
            if found:
                depth = min(len(PurePosixPath(n).parts) for n in found)
                found = [n for n in found if len(PurePosixPath(n).parts) == depth]
        assert len(found) == 1, (suffix, found)
        return found[0]
    for suffix in ["/source/NOTICE", "/source/BUILD.md", "/source/upstream/firefly_luciferin/LICENSE", "/source/upstream/glow_worm_luciferin/LICENSE", "/ESP32 Sync Lights.exe", "/README.md"]:
        assert outer.getinfo(locate(suffix)).file_size > 0, suffix
    assert not any(n.lower().endswith(".cmd") and "/source/" not in n for n in names), "runtime launcher scripts shipped"
    assert not any(n.endswith("/pc-selected.properties") or n.endswith("/portable-layout.json") for n in names), "prior user settings shipped"
    defaults=[]
    for name in names:
        if name.endswith((".yaml",".yml")):
            text=outer.read(name).decode("utf-8")
            if re.search(r"^(?:configVersion|toggleLed):",text,re.M):
                assert re.search(r"^brightness:\s*0\s*$",text,re.M), "nonzero shipped default: "+name
                assert re.search(r"^toggleLed:\s*false\s*$",text,re.M), "enabled shipped default: "+name
                chooser=re.search(r'^colorChooser:\s*["\']?([^"\'\n]+)',text,re.M)
                assert chooser and chooser.group(1).strip().split(",")[-1]=="0", "nonzero chooser alpha: "+name
                for field in ("mqttPwd","mqttUsername"):
                    assert re.search(r"^"+field+r":\s*[\"']{2}\s*$",text,re.M), "nonempty default credential: "+name
                defaults.append(name)
    assert len(defaults)>=2, ("missing runtime/source defaults",defaults)
    manifests = [n for n in names if n.endswith("/firmware/manifest.json")]
    assert manifests, "missing firmware manifest"
    for manifest in manifests:
        m=json.loads(outer.read(manifest)); parent=manifest.rsplit("/",1)[0]
        for filename,meta in m["files"].items():
            data=outer.read(parent+"/"+filename)
            assert len(data)==meta["bytes"] and hashlib.sha256(data).hexdigest()==meta["sha256"], filename
    jarname=locate("/app/FireflyLuciferin-jar-with-dependencies.jar")
    jarbytes=outer.read(jarname)
    with zipfile.ZipFile(io.BytesIO(jarbytes)) as jar:
        assert jar.testzip() is None, "bundled JAR CRC/header failure"
        assert len(jar.namelist())==len(set(jar.namelist())), "duplicate bundled JAR entries"
        assert not any(n.startswith(("PortableRegression", "Reviewer")) and n.endswith(".class") for n in jar.namelist()), "verification class shipped as runtime code"
        assert "PortableSettingsSaveAgent.class" not in jar.namelist(), "settings test agent shipped in runtime"
        metadata=jar.read("project.properties").decode("utf-8").replace("\r\n","\n")
        assert "${" not in metadata, "unfiltered runtime build metadata"
        assert re.search(r"^version=\d+\.\d+\.\d+(?:-.*)?$",metadata,re.M), "invalid runtime release version"
        leftovers=[]
        for name in jar.namelist():
            if name.endswith(".fxml"):
                text=jar.read(name).decode("utf-8")
                if re.search(r'(?:text|title)="[^"\n]*Luciferin',text): leftovers.append(name)
        print("FXML original-brand literal leftovers:",leftovers)
        assert not leftovers, "visible resource branding"
        generated=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[1]/"build/brand-resources"
        verified=0
        for name in jar.namelist():
            if "luciferin" in name.lower() and name.endswith(".png"):
                p=generated/name
                if p.exists():
                    assert jar.read(name)==p.read_bytes(), "original/duplicate UI icon: "+name
                    verified+=1
        assert verified>=25, ("neutral UI logo count",verified)
    result={"archive":str(archive),"bytes":archive.stat().st_size,"sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"entries":len(names),"jar_sha256":hashlib.sha256(jarbytes).hexdigest(),"neutral_ui_icons":verified,"zero_brightness_defaults":defaults,"result":"PASS: ZIP/JAR complete CRC/header reads, cache/private exclusions, firmware checksums, source licenses/notices, visible text/icon branding, zero-brightness/OFF defaults"}
    print(json.dumps(result,indent=2))
