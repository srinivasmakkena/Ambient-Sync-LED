import java.nio.*;
import java.awt.image.BufferedImage;
import java.util.*;
import org.dpsoftware.*;
import org.dpsoftware.config.*;
import org.dpsoftware.grabber.*;
public class ReviewerAspectChecks {
 static int checks;static final int W=480,H=270,N=Constants.REQUIRED_CONFIRMATIONS;
 static class Tracking extends Configuration {int writes;public void setDefaultLedMatrix(String value){writes++;super.setDefaultLedMatrix(value);}}
 static Tracking config=new Tracking();
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static void reset(Enums.AspectRatio ratio)throws Exception {config.setDefaultLedMatrix(ratio.getBaseI18n());config.writes=0;GStreamerGrabber.ledMatrix=config.getLedMatrixInUse(ratio.getBaseI18n());GrabberSingleton.getInstance().ledMatrix=GStreamerGrabber.ledMatrix;for(String field:List.of("pendingAspectRatio","consecutiveDetections")){var f=ImageProcessor.class.getDeclaredField(field);f.setAccessible(true);f.set(null,field.startsWith("pending")?null:0);}}
 static IntBuffer frame(String kind){IntBuffer pixels=IntBuffer.allocate(W*H);for(int y=0;y<H;y++)for(int x=0;x<W;x++){
  int color=switch(kind){case "letter"->y<8||y>=H-8?0:0xD08040;case "pillar"->x<130||x>=W-130?0:0x4060D0;case "black"->0;case "noise"->((x*17+y*11)%16)*0x010101;case "centerblack"->Math.abs(x-W/2)<4||Math.abs(y-H/2)<4?0:0x808080;default->0x807040;};pixels.put(y*W+x,color);}return pixels;}
 static void sample(IntBuffer pixels,boolean cpu){if(cpu){BufferedImage image=new BufferedImage(W,H,BufferedImage.TYPE_INT_RGB);image.setRGB(0,0,W,H,pixels.array(),0,W);GrabberSingleton.getInstance().screen=image;ImageProcessor.autodetectBlackBars(W,H,null);}else ImageProcessor.autodetectBlackBars(W,H,pixels);}
 static void same(Enums.AspectRatio ratio){check(config.getDefaultLedMatrix().equals(ratio.getBaseI18n()),"ratio expected "+ratio);check(GStreamerGrabber.ledMatrix==config.getLedMatrixInUse(ratio.getBaseI18n()),"GStreamer crop cache");check(GrabberSingleton.getInstance().ledMatrix==GStreamerGrabber.ledMatrix,"CPU crop cache");}
 static void transition(String kind,Enums.AspectRatio target,boolean cpu){String old=config.getDefaultLedMatrix();int before=config.writes;for(int i=1;i<N;i++){sample(frame(kind),cpu);check(config.getDefaultLedMatrix().equals(old)&&config.writes==before,"short transient must not mutate "+kind+" frame"+i);}sample(frame(kind),cpu);same(target);check(config.writes==before+1,"one commit exactly "+kind);for(int i=0;i<20;i++)sample(frame(kind),cpu);check(config.writes==before+1,"stable crop never transiently toggles "+kind);}
 static void suite(boolean cpu)throws Exception {
  reset(Enums.AspectRatio.FULLSCREEN);transition("pillar",Enums.AspectRatio.PILLARBOX,cpu);transition("letter",Enums.AspectRatio.LETTERBOX,cpu);transition("full",Enums.AspectRatio.FULLSCREEN,cpu);
  for(var ratio:Enums.AspectRatio.values()){if(!List.of(Enums.AspectRatio.FULLSCREEN,Enums.AspectRatio.LETTERBOX,Enums.AspectRatio.PILLARBOX).contains(ratio))continue;reset(ratio);for(String kind:List.of("black","noise","centerblack")){for(int i=0;i<20;i++)sample(frame(kind),cpu);same(ratio);check(config.writes==0,"uninformative "+kind+" holds "+ratio);}}
  reset(Enums.AspectRatio.FULLSCREEN);for(int i=0;i<100;i++)sample(frame(i%2==0?"pillar":"full"),cpu);same(Enums.AspectRatio.FULLSCREEN);check(config.writes==0,"alternating scenes never reach confirmation");
  reset(Enums.AspectRatio.FULLSCREEN);for(int i=0;i<N-1;i++)sample(frame("pillar"),cpu);sample(frame("black"),cpu);for(int i=0;i<N-1;i++)sample(frame("pillar"),cpu);check(config.writes==0,"dark scene clears pending evidence");sample(frame("pillar"),cpu);same(Enums.AspectRatio.PILLARBOX);check(config.writes==1,"new evidence commits once after dark reset");
 }
 public static void main(String[] args)throws Exception{
  config.setScreenResX(1920);config.setScreenResY(1080);config.setResamplingFactor(4);config.setMqttEnable(false);config.setLedMatrix(new LinkedHashMap<>());for(var ratio:List.of(Enums.AspectRatio.FULLSCREEN,Enums.AspectRatio.LETTERBOX,Enums.AspectRatio.PILLARBOX)){var map=new LinkedHashMap<Integer,LEDCoordinate>();map.put(1,new LEDCoordinate());config.getLedMatrix().put(ratio.getBaseI18n(),map);}MainSingleton.getInstance().config=config;
  suite(false);suite(true);System.out.println("PASS: "+checks+" independent black-bar checks: pure preconfirmation, both crops/change-back, stable frames, dark/noise/center-black hold, evidence reset; IntBuffer and BufferedImage paths; no hardware");
 }
}

