#pragma once
#include <deque>
#include <string>
#include <cstdio>
#include <cstdarg>
using byte = unsigned char;
extern unsigned long nowMillis;
inline unsigned long millis() { return nowMillis; }
struct FakeSerial {
  std::deque<char> rx;
  std::string tx;
  int peek() { return rx.empty() ? -1 : static_cast<unsigned char>(rx.front()); }
  int available() { return static_cast<int>(rx.size()); }
  int read() { int c = peek(); if (!rx.empty()) rx.pop_front(); return c; }
  void println(const char* s) { tx += std::string(s) + "\n"; }
  void printf(const char* format, ...) {
    char buffer[128]; va_list args; va_start(args, format); vsnprintf(buffer, sizeof(buffer), format, args); va_end(args); tx += buffer;
  }
  void feed(const std::string& s) { for (char c : s) rx.push_back(c); }
};
extern FakeSerial Serial;
