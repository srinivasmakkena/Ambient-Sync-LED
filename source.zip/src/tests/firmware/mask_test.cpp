// Tests the production C++ parser, output path and serial/NVS adapter. No LEDs connected.
#include "Arduino.h"
#include "PhysicalMask.h"
#include <cassert>
#include <vector>
#include <iostream>
#include <random>
#include <sstream>
#include <iomanip>
unsigned long nowMillis = 0;
FakeSerial Serial;
std::string nvs;
bool hasNvs = false, failStorage = false;
unsigned writes = 0;
using namespace PhysicalMaskCore;
std::string command(unsigned count, const std::vector<unsigned>& skipped) {
  unsigned char bits[MaskBytes] = {};
  for (unsigned i : skipped) bits[i / 8] |= 1 << (i % 8);
  std::ostringstream out; out << "GWPM1:" << count << ":";
  for (unsigned i=0; i<(count+7)/8; ++i) out << std::uppercase << std::hex << std::setw(2) << std::setfill('0') << unsigned(bits[i]);
  std::string canonical=out.str(); out << ":" << std::setw(8) << crc32(canonical.data(), canonical.size()); return out.str();
}
struct Color {
  uint32_t value;
  Color(uint32_t v=0): value(v) {}
};
struct Bus {
  std::vector<Color> logical, displayed;
  unsigned waits=0;
  bool inFlight=false;
  Bus(unsigned n): logical(n) { for (unsigned i=0;i<n;++i) logical[i]=Color(1000+i); }
  uint16_t PixelCount() { return logical.size(); }
  Color GetPixelColor(unsigned i) { assert(i<logical.size()); return logical[i]; }
  void SetPixelColor(unsigned i, Color c) { logical.at(i)=c; }
  void ClearTo(Color c) { for (auto& v:logical) v=c; }
  void Show(bool maintainBufferConsistency=true) { assert(maintainBufferConsistency); displayed=logical; inFlight=true; }
  bool CanShow() { if (++waits%2) return false; inFlight=false; return true; }
};
void feed(const std::string& s) { Serial.feed(s); assert(PhysicalMask::readSerial()); }
int main() {
  assert(crc32("123456789",9)==0xCBF43926);
  std::mt19937 random(1234);
  unsigned assertions=0;
  for (unsigned count=1;count<=MaxLeds;++count) {
    std::vector<unsigned> skipped;
    for (unsigned i=0;i<count;++i) if (random()%4==0) skipped.push_back(i);
    State s; auto packet=command(count,skipped); assert(parse(packet.data(),packet.size(),s));
    Bus bus(count); unsigned yields=0; show<Bus,Color>(&bus,s,[&]{++yields;});
    // The NeoPixelBus sending/editing buffers are separate; restoring editing pixels needs no polling.
    assert(yields==0 && bus.waits==0 && bus.inFlight);
    for (unsigned i=0;i<count;++i) {
      assert(bus.logical[i].value==1000+i);
      assert(bus.displayed[i].value==(s.blocked(i,count)?0:1000+i));
      assertions+=2;
    }
    {
      Bus mismatch(count==300?299:count+1); show<Bus,Color>(&mismatch,s,[]{});
      for (auto c:mismatch.displayed) assert(c.value==0);
      for (unsigned i=0;i<mismatch.logical.size();++i) assert(mismatch.logical[i].value==1000+i);
    }
    State previous=s;
    for (unsigned i=0;i<packet.size();++i) {
      auto bad=packet; bad[i]='!';
      assert(!parse(bad.data(),bad.size(),s));
      assert(s.count==previous.count && s.crc==previous.crc && !memcmp(s.bits,previous.bits,MaskBytes));
    }
  }
  State out;
#ifdef PORTABLE_PHYSICAL_MASK
  Bus unset(197); show<Bus,Color>(&unset,out,[]{}); for (auto c:unset.displayed) assert(c.value==0);
  assert(out.blocked(0,197));
#endif
  auto emptyMask=command(72,{}); assert(parse(emptyMask.data(),emptyMask.size(),out));
  assert(out.blocked(0,73)); Bus emptyMismatch(73); show<Bus,Color>(&emptyMismatch,out,[]{}); for (auto c:emptyMismatch.displayed) assert(c.value==0);
  Bus tooLarge(301); show<Bus,Color>(&tooLarge,out,[]{}); for (auto c:tooLarge.displayed) assert(c.value==0);
  for (auto invalid:{"GWPM1:0:00:00000000", "GWPM1:301:00:00000000", "GWPM1:0001:00:00000000", "GWPM1:-1:00:00000000"}) assert(!parse(invalid,strlen(invalid),out));
  auto padding=command(8,{7}); padding.replace(6,1,"1"); auto canonical=padding.substr(0,padding.size()-9); char crc[9]; snprintf(crc,sizeof(crc),"%08X",crc32(canonical.data(),canonical.size())); padding.replace(padding.size()-8,8,crc); assert(!parse(padding.data(),padding.size(),out));
  out.corrupt=true; Bus failClosed(300); show<Bus,Color>(&failClosed,out,[]{}); for (auto c:failClosed.displayed) assert(c.value==0);
  PhysicalMask::begin(); feed("GWPM1?\n"); assert(Serial.tx=="mask:NONE\n"); Serial.tx.clear();
  auto packet=command(72,{0,7,71});
  feed(packet.substr(0,9)); assert(PhysicalMask::state.count==0 && writes==0);
  feed(packet.substr(9)+"\n"); assert(PhysicalMask::state.count==72 && writes==1 && nvs==packet && Serial.tx.find("mask:GWPM1:72:")==0);
  Serial.tx.clear(); feed(packet+"\n"); assert(writes==1 && Serial.tx.find("mask:GWPM1:72:")==0);
  auto bad=packet; bad.back()='Z'; feed(bad+"\n"); assert(writes==1 && PhysicalMask::state.count==72);
  PhysicalMask::state=State(); PhysicalMask::begin(); assert(PhysicalMask::state.count==72 && PhysicalMask::state.blocked(71,72));
  nvs.back()='Z'; PhysicalMask::state=State(); PhysicalMask::begin(); assert(PhysicalMask::state.corrupt);
  feed(packet+"\n"); assert(!PhysicalMask::state.corrupt && writes==2);
  failStorage=true; feed(command(72,{1})+"\n"); assert(PhysicalMask::state.corrupt); failStorage=false;
  feed(packet+"\n"); assert(!PhysicalMask::state.corrupt);
  Serial.tx.clear(); feed(std::string(200,'G')+"\n"); assert(Serial.tx=="mask:ERROR:TOO_LONG\n");
  feed("GWPM1:72:"); nowMillis+=251; assert(PhysicalMask::readSerial()); assert(Serial.tx.find("mask:ERROR:TIMEOUT")!=std::string::npos);
  Serial.feed("DPsoft"); assert(!PhysicalMask::readSerial() && Serial.rx.size()==6); Serial.rx.clear();
  feed(command(72,{})+"\n"); assert(!PhysicalMask::state.any());
  std::cout << "PASS: counts 1..300, " << assertions << " output/state checks, mutation rejection, padding, CRC, fragmented serial, DMA restore, count mismatch, NVS recovery/idempotence/failure, timeout/overflow, DPsoft compatibility\n";
}
