#pragma once
#include <string>
#include <cstring>
extern std::string nvs;
extern bool hasNvs, failStorage;
extern unsigned writes;
struct Preferences {
  bool begin(const char*, bool) { return !failStorage; }
  bool isKey(const char*) { return hasNvs; }
  size_t getBytesLength(const char*) { return nvs.size(); }
  size_t getBytes(const char*, void* destination, size_t capacity) {
    if (failStorage || capacity < nvs.size()) return 0;
    memcpy(destination, nvs.data(), nvs.size()); return nvs.size();
  }
  size_t putBytes(const char*, const void* value, size_t length) {
    ++writes;
    if (failStorage) return 0;
    hasNvs = true; nvs.assign(static_cast<const char*>(value), length); return length;
  }
};
