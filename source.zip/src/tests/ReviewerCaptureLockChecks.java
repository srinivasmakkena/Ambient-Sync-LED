import java.nio.*;
import java.util.*;
import java.util.concurrent.locks.*;
import java.lang.reflect.*;
import org.dpsoftware.*;
import org.dpsoftware.config.*;
import org.dpsoftware.grabber.*;
public class ReviewerCaptureLockChecks {
 static int checks;static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 public static void main(String[] args)throws Exception{
  MainSingleton main=MainSingleton.getInstance();Configuration c=new Configuration();c.setScreenResX(1920);c.setScreenResY(1080);c.setResamplingFactor(4);c.setAutoDetectBlackBars(true);c.setDefaultLedMatrix(Enums.AspectRatio.FULLSCREEN.getBaseI18n());main.config=c;main.exitTriggered=true;var species=MainSingleton.class.getDeclaredField("SPECIES");species.setAccessible(true);species.set(main,null);
  var maps=new LinkedHashMap<Integer,LEDCoordinate>();var coord=new LEDCoordinate(0,0,4,4,false,"top");coord.setActive(false);maps.put(1,coord);c.setLedMatrix(new LinkedHashMap<>());for(var ratio:List.of(Enums.AspectRatio.FULLSCREEN,Enums.AspectRatio.LETTERBOX,Enums.AspectRatio.PILLARBOX))c.getLedMatrix().put(ratio.getBaseI18n(),maps);GStreamerGrabber.ledMatrix=maps;c.setAlgo(Enums.Algo.AVG_COLOR.getBaseI18n());
  var uf=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");uf.setAccessible(true);sun.misc.Unsafe unsafe=(sun.misc.Unsafe)uf.get(null);Object owner=unsafe.allocateInstance(GStreamerGrabber.class);var lock=new ReentrantLock();var lockField=GStreamerGrabber.class.getDeclaredField("bufferLock");lockField.setAccessible(true);lockField.set(owner,lock);
  var cls=Class.forName("org.dpsoftware.grabber.GStreamerGrabber$AppSinkListener");var ctor=cls.getDeclaredConstructor(GStreamerGrabber.class);ctor.setAccessible(true);Object sink=ctor.newInstance(owner);var rgb=cls.getDeclaredMethod("rgbFrame",int.class,int.class,IntBuffer.class);rgb.setAccessible(true);
  GrabberSingleton.getInstance().CHECK_ASPECT_RATIO=true;boolean failed=false;try{rgb.invoke(sink,480,270,IntBuffer.allocate(0));}catch(InvocationTargetException expected){failed=true;check(expected.getCause() instanceof IndexOutOfBoundsException,"injected short buffer reaches detector");}check(failed,"short buffer produces expected exception");check(!lock.isLocked(),"detector failure releases capture lock");
  Thread next=new Thread(()->{try{GrabberSingleton.getInstance().CHECK_ASPECT_RATIO=true;IntBuffer valid=IntBuffer.allocate(480*270);for(int i=0;i<valid.capacity();i++)valid.put(i,0x808080);rgb.invoke(sink,480,270,valid);}catch(Throwable error){throw new RuntimeException(error);}},"reviewer-valid-next-frame");var error=new Throwable[1];next.setUncaughtExceptionHandler((thread,problem)->error[0]=problem);next.start();next.join(3000);check(!next.isAlive()&&error[0]==null,"next producer thread accepts valid frame");check(!GrabberSingleton.getInstance().CHECK_ASPECT_RATIO,"next valid frame actually ran detector");check(!lock.isLocked(),"normal frame releases lock");check(main.output==null&&main.serial==null,"no hardware or output transport");
  System.out.println("PASS: "+checks+" synthetic malformed-buffer/next-frame lock checks; actual private rgbFrame method, no native capture initialized and no hardware");
 }
}
