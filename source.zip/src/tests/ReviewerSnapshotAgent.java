import java.lang.instrument.Instrumentation;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import javafx.application.Platform;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;
import javax.imageio.ImageIO;
import org.dpsoftware.NativeExecutor;
public class ReviewerSnapshotAgent {
 public static void agentmain(String path,Instrumentation ignored){Platform.runLater(()->{org.dpsoftware.MainSingleton.getInstance().guiManager.showSettingsDialog(false);Platform.runLater(()->capture(path));});}
 static void capture(String path){try{
  Stage stage=null;TabPane tabs=null;
  for(Window window:Window.getWindows())if(window instanceof Stage&&window.getScene()!=null){var node=window.getScene().lookup("#mainTabPane");if(node instanceof TabPane){stage=(Stage)window;tabs=(TabPane)node;break;}}
  if(stage==null)throw new AssertionError("No regular settings window");
  for(Tab tab:tabs.getTabs())if(tab.getText().toLowerCase().contains("led")){tabs.getSelectionModel().select(tab);break;}
  Stage selected=stage;Platform.runLater(()->{try{
   Parent root=selected.getScene().getRoot();root.applyCss();root.layout();
   var image=root.snapshot(new SnapshotParameters(),null);int width=(int)image.getWidth(),height=(int)image.getHeight();int[] pixels=new int[width*height];image.getPixelReader().getPixels(0,0,width,height,javafx.scene.image.PixelFormat.getIntArgbInstance(),pixels,0,width);BufferedImage result=new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);result.setRGB(0,0,width,height,pixels,0,width);ImageIO.write(result,"png",Path.of(path).toFile());
   var report=new StringBuilder("Actual native settings Scene="+selected.getScene().getWidth()+"x"+selected.getScene().getHeight()+"; selected LED tab; stage="+selected.getWidth()+"x"+selected.getHeight()+"\n");
   for(Node node:root.lookupAll(".button"))if(node instanceof Button b&&b.isVisible()){var bound=b.localToScene(b.getBoundsInLocal());report.append(b.getText()).append(" bounds=").append(bound).append('\n');}
   Files.writeString(Path.of(path+".txt"),report);
  }catch(Throwable error){writeError(path,error);}finally{NativeExecutor.exit();}});
 }catch(Throwable error){writeError(path,error);NativeExecutor.exit();}}
 static void writeError(String path,Throwable error){try{Files.writeString(Path.of(path+".txt"),error.toString());}catch(Exception ignored){}}
}
