import java.nio.file.*;
import java.io.*;
public class ReviewerNativeAspectMain {
 public static void main(String[] args)throws Exception {
  Path root=Path.of(ReviewerNativeAspectMain.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParent().getParent();
  System.setProperty("firefly.config.dir",root.resolve("config").toString());Files.createDirectories(root.resolve("config"));
  try(var out=new PrintStream(Files.newOutputStream(Path.of("E:/SSM/projects/odyssey-ambient/docs/independent-video-native-checks.txt")))){System.setOut(out);System.setErr(out);try{ReviewerAspectChecks.main(args);ReviewerCaptureLockChecks.main(args);ReviewerMaskPauseChecks.main(args);out.println("JAVA="+System.getProperty("java.home")+"\nROOT="+root+"\nProduction JAR SHA256=fd264c0e8b45a40a3e4c64e55de4735644d1476dff35f3b9d05f042c7d5235d9\nNo hardware/capture initialized, serial output=memory only");}catch(Throwable error){error.printStackTrace(out);System.exit(1);}}
 }
}


