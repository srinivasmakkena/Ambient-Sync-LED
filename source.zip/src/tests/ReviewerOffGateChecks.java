import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.nio.file.*;
import java.util.*;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import org.dpsoftware.*;
import org.dpsoftware.config.*;
import org.dpsoftware.managers.*;
import org.dpsoftware.portable.*;

/** Serial output is a memory buffer only. No hardware port is opened. */
public class ReviewerOffGateChecks {
 static int checks;
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[0]).toAbsolutePath();
  System.setProperty("firefly.portable.root",root.toString());
  System.setProperty("firefly.config.dir",root.resolve("config").toString());
  MainSingleton main=MainSingleton.getInstance();main.bundle=ResourceBundle.getBundle(Constants.MSG_BUNDLE,Locale.ENGLISH);
  Configuration c=new YAMLMapper().readValue(root.resolve("profiles/portable-default.yaml").toFile(),Configuration.class);
  main.config=c;PortableLayout.loadAndApply(c);PortableLayout p=PortableLayout.current();
  check(p!=null&&p.count()==14,"isolated synthetic layout");
  FireflyLuciferin.setLedNumber(c.getDefaultLedMatrix());ManagerSingleton.getInstance().serialVersionOk=true;
  main.gpio=255;main.gpioClockPin=255;c.setBrightness(200);
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();main.output=bytes;
  SerialManager serial=new SerialManager();
  Color[] solid={Color.WHITE};Color[] stream=new Color[p.count()];Arrays.fill(stream,Color.WHITE);
  for(Enums.Effect effect:Enums.Effect.values())for(Color[] input:List.of(solid,stream)) {
   c.setEffect(effect.getBaseI18n());c.setToggleLed(false);
   PortableMask.received(p.acknowledgement());bytes.reset();serial.sendColorsViaUSB(input);
   byte[] packet=bytes.toByteArray();int begin=packet.length-(27+3*p.count());
   check(begin>=0&&(packet[begin+9]&255)==0&&(packet[begin+13]&255)==1,"OFF forces brightnesszero/effect1 despite valid ACK");
   for(int i=begin+27;i<packet.length;i++)check(packet[i]==0,"OFF forces every channelblack");
   check(!c.isToggleLed(),"stale input cannot re-enable OFF");
   c.setToggleLed(true);PortableMask.received(p.acknowledgement());bytes.reset();serial.sendColorsViaUSB(input);
   packet=bytes.toByteArray();begin=packet.length-(27+3*p.count());
   check((packet[begin+9]&255)>0,"explicit ON releases requested brightness");
   for(int i=0;i<p.count();i++)for(int color=0;color<3;color++)check((packet[begin+27+3*i+color]&255)==(p.gaps().get(i)?0:255),"ON retains physical gaps");
  }
  // With layout disabled/no active mask, OFF must still override single-color state inference.
  p.enabled=false;c.setToggleLed(false);bytes.reset();serial.sendColorsViaUSB(solid);
  byte[] packet=bytes.toByteArray();int begin=packet.length-(27+3*p.count());
  check((packet[begin+9]&255)==0&&(packet[begin+13]&255)==1&&!c.isToggleLed(),"OFF without active mask stays OFF");
  for(int i=begin+27;i<packet.length;i++)check(packet[i]==0,"mask-independent OFF output black");
  String result="PASS: "+checks+" stale solid/stream OFF frames, explicit ON and physical gap checks; serial=memory only\nJAVA="+System.getProperty("java.home");
  Files.writeString(root.resolve("config/reviewer-off-gate-checks.txt"),result);System.out.println(result);
 }
}
