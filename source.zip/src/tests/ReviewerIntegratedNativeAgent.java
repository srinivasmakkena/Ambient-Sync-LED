import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.instrument.Instrumentation;
import java.nio.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import org.dpsoftware.*;
import org.dpsoftware.config.*;
import org.dpsoftware.grabber.*;
import org.dpsoftware.gui.*;
import org.dpsoftware.gui.controllers.*;
import org.dpsoftware.managers.*;
import org.dpsoftware.portable.*;

/** Runs only in an isolated native app with an absent COM selection. */
public class ReviewerIntegratedNativeAgent {
 static int checks;static Path report,snapshot;static StringBuilder evidence=new StringBuilder();
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static Object field(Object object,String name)throws Exception{var f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
 public static void agentmain(String argument,Instrumentation ignored){
  String[] paths=argument.split("\\|",2);report=Path.of(paths[0]);snapshot=Path.of(paths[1]);
  Platform.runLater(()->{try{runUi();new Thread(()->{try{runMock();finish(null);}catch(Throwable t){finish(t);}},"reviewer-mock-test").start();}catch(Throwable t){finish(t);}});
 }
 static void finish(Throwable failure){try{if(failure==null)Files.writeString(report,"PASS: "+checks+" integrated UI, capture pixels, local paths and mock selected-test checks\n"+evidence);else try(var writer=new PrintWriter(report.toFile())){failure.printStackTrace(writer);}}catch(Exception e){e.printStackTrace();}Platform.runLater(()->NativeExecutor.exit());}
 static void runUi()throws Exception{
  var main=MainSingleton.getInstance();Path root=PortableStarter.root;
  check(main.serial==null&&main.output==null,"isolated absent COM has no hardware output");
  check(Path.of(System.getProperty("firefly.config.dir")).equals(root.resolve("config")),"local config");
  check(Path.of(System.getProperty("java.io.tmpdir")).equals(root.resolve(".tmp")),"local Java temp");
  check(Path.of(System.getProperty("jna.tmpdir")).startsWith(root),"local JNA cache");
  check(Path.of(System.getProperty("javafx.cachedir")).startsWith(root),"local JavaFX cache");
  check(new ImageProcessor(false).getInstallationPath().equals(root.resolve("app/classes").toString()),"root EXE native path");
  var kernel=com.sun.jna.NativeLibrary.getInstance("kernel32");
  for(String key:List.of("TEMP","TMP","APPDATA","LOCALAPPDATA","GST_REGISTRY")){char[] value=new char[32768];int size=kernel.getFunction("GetEnvironmentVariableW").invokeInt(new Object[]{new com.sun.jna.WString(key),value,value.length});String actual=new String(value,0,size);check(Path.of(actual).startsWith(root),"local native environment "+key);evidence.append(key).append('=').append(actual).append('\n');}
  var loader=new FXMLLoader(GuiManager.class.getResource("settings.fxml"),main.bundle);Parent node=loader.load();SettingsController controller=loader.getController();
  var leds=(LedsConfigTabController)field(controller,"ledsConfigTabController");PortableLayoutPane pane=leds.portablePane;check(pane!=null,"integrated editor in regular LED tab");
  Stage stage=new Stage();stage.setScene(new Scene(node));TabPane tabs=(TabPane)field(controller,"mainTabPane");for(Tab tab:tabs.getTabs())if(tab.getText().toLowerCase().contains("led")){tabs.getSelectionModel().select(tab);break;}node.applyCss();node.layout();
  var rendered=node.snapshot(new SnapshotParameters(),null);int sw=(int)rendered.getWidth(),sh=(int)rendered.getHeight();BufferedImage picture=new BufferedImage(sw,sh,BufferedImage.TYPE_INT_ARGB);int[] pixels=new int[sw*sh];rendered.getPixelReader().getPixels(0,0,sw,sh,javafx.scene.image.PixelFormat.getIntArgbInstance(),pixels,0,sw);picture.setRGB(0,0,sw,sh,pixels,0,sw);ImageIO.write(picture,"png",snapshot.toFile());
  pane.top.setText("4");pane.right.setText("3");pane.bottom.setText("5");pane.left.setText("2");pane.gapTopLeft.setText("1");pane.gapTopRight.setText("2");pane.gapBottomRight.setText("3");pane.gapBottomLeft.setText("4");pane.corner.setValue("Bottom right");pane.direction.setValue("Anticlockwise");pane.offset.setText("1");pane.skipped.setText("7-8");pane.depth.setText("10");pane.name.setText("Reviewer synthetic ring");
  var mode=(ModeTabController)field(controller,"modeTabController");mode.screenWidth.setText("960");mode.screenHeight.setText("540");mode.scaling.setValue("100%");
  // A previous valid ACK must not authorize the newly saved ring.
  PortableMask.received(PortableLayout.current().acknowledgement());controller.save(null);
  var p=PortableLayout.current();check(p.top==4&&p.right==3&&p.bottom==5&&p.left==2&&p.count()==24,"actual save takes side and four gap counts");
  check(p.corner.equals("Bottom right")&&p.direction.equals("Anticlockwise")&&p.offset==1,"actual save takes start/direction/offset");
  check(p.gapTopLeft==1&&p.gapTopRight==2&&p.gapBottomRight==3&&p.gapBottomLeft==4,"four independent corner gaps saved");
  var persisted=new com.fasterxml.jackson.databind.ObjectMapper().readValue(PortableLayout.file().toFile(),PortableLayout.class);check(persisted.maskBody().equals(p.maskBody())&&persisted.offset==1,"JSON matches saved UI");
  check(!PortableMask.ready(),"new layout revokes old ACK");check(!main.config.isToggleLed(),"layout save stays OFF");
  var matrix=main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix());check(matrix.size()==24&&main.ledNumber==24,"new physical count drives runtime");
  check(GrabberSingleton.getInstance().ledMatrix==matrix&&GStreamerGrabber.ledMatrix==matrix,"singlemonitor both capture caches replaced");
  int[] ring={0,1,1,1,1,0,0,2,2,2,0,0,0,3,3,3,3,3,0,0,0,0,4,4};
  for(int i=0;i<24;i++){int canonical=Math.floorMod(11-i,24);boolean gap=ring[canonical]==0||i==6||i==7;check(p.gaps().get(i)==gap,"independent rotated physical gaps");}
  main.config.setGamma(1.0);main.config.setResamplingFactor(4);main.config.setLuminosityThreshold(0);main.config.setBrightnessLimiter(1.0f);var species=MainSingleton.class.getDeclaredField("SPECIES");species.setAccessible(true);species.set(main,null);
  // Four exact side bands; overlap corners retain the dominant side channel.
  int w=240,h=135;IntBuffer frame=IntBuffer.allocate(w*h);
  for(int y=0;y<h;y++)for(int x=0;x<w;x++){int rgb=y<14?0xFF0000:y>=121?0x0000FF:x>=216?0x00FF00:x<24?0xFF00FF:0x101010;frame.put(y*w+x,rgb);}
  var sink=Class.forName("org.dpsoftware.grabber.GStreamerGrabber$AppSinkListener");var process=sink.getDeclaredMethod("processBufferUsingCpu",int.class,int.class,IntBuffer.class);process.setAccessible(true);
  Color[] colors=(Color[])process.invoke(null,w,h,frame);check(colors.length==24,"real synthetic color pipeline count");
  int active=0;
  for(int i=0;i<24;i++){Color c=colors[i];int side=ring[Math.floorMod(11-i,24)];if(p.gaps().get(i)){check(c.equals(Color.BLACK),"real pipeline gap black");continue;}active++;switch(side){case 1->check(c.getRed()>c.getGreen()&&c.getRed()>c.getBlue(),"top samples red");case 2->check(c.getGreen()>c.getRed()&&c.getGreen()>c.getBlue(),"right samples green");case 3->check(c.getBlue()>c.getRed()&&c.getBlue()>c.getGreen(),"bottom samples blue");case 4->check(c.getRed()>c.getGreen()&&c.getBlue()>c.getGreen(),"left samples magenta");default->throw new AssertionError("unexpected active corner");}}
  check(active>0,"known frame has active regions");evidence.append("Synthetic RGB frame: 240x135 ->24 physical positions; all active side colors and corner/middle gaps matched independent canonical ring\n");
  // Verify newly integrated corner ROIs and narrow active ROIs cannot divide by zero.
  var narrow=new PortableLayout();narrow.top=300;narrow.right=0;narrow.bottom=0;narrow.left=0;narrow.cornerMode=true;main.config.setScreenResX(1024);main.config.setScreenResY(768);narrow.apply(main.config);GStreamerGrabber.ledMatrix=main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix());IntBuffer white=IntBuffer.allocate(256*192);for(int i=0;i<white.capacity();i++)white.put(i,0xFFFFFF);Color[] small=(Color[])process.invoke(null,256,192,white);check(small.length==300&&Arrays.stream(small).allMatch(c->c!=null&&!c.equals(Color.BLACK)),"300 narrow top ROIs process without zero samples");
  main.config.setScreenResX(960);main.config.setScreenResY(540);p.apply(main.config);PipelineManager.refreshCaptureLedState();stage.close();main.exitTriggered=true;
  evidence.append("ROOT=").append(root).append("\nJAVA=").append(System.getProperty("java.home")).append("\nSnapshot=").append(snapshot).append('\n');
 }
 static void runMock()throws Exception{
  var main=MainSingleton.getInstance();var p=PortableLayout.current();int selected=p.gaps().nextClearBit(0);AtomicBoolean active=new AtomicBoolean(true);ArrayList<byte[]> frames=new ArrayList<>();
  main.output=new OutputStream(){public void write(int b){}public void write(byte[] b){if(b.length>=6&&new String(b,0,6,java.nio.charset.StandardCharsets.US_ASCII).equals("DPsoft")){frames.add(b.clone());if((b[9]&255)>0)active.set(false);}else PortableMask.received(p.acknowledgement());}};
  PortableMask.reset();PositionTest.testConnected(selected+1,p,active);check(!PositionTest.running&&!main.config.isToggleLed(),"selected test restores inactive/OFF state");boolean found=false;
  for(byte[] f:frames)if((f[9]&255)>0){found=true;check((f[9]&255)<=32,"bounded test brightness");for(int i=0;i<p.count();i++)for(int ch=0;ch<3;ch++)check((f[27+3*i+ch]&255)==(i==selected?64:0),"only selected physical LED test bytes nonzero");}
  check(found,"mock ACK permits explicit one-LED test");byte[] last=frames.get(frames.size()-1);check(last[9]==0,"test stop emits final OFF");
  main.output=new OutputStream(){public void write(int b)throws IOException{throw new IOException("reviewer injected disconnect");}public void write(byte[] b)throws IOException{throw new IOException("reviewer injected disconnect");}};
  boolean failed=false;try{PositionTest.testConnected(selected+1,p,new AtomicBoolean(true));}catch(IOException expected){failed=true;}check(failed&&!PositionTest.running,"failed OFF write still clears exclusive test state");main.output=null;
  evidence.append("Selected-position test transport=memory only; ACK/selected pixel/stop/OFF/disconnect restoration passed; no hardware opened\n");
 }
}

