import java.lang.instrument.Instrumentation;
import java.nio.file.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import org.dpsoftware.*;
import org.dpsoftware.gui.*;
import org.dpsoftware.gui.controllers.*;
import org.dpsoftware.managers.*;
import org.dpsoftware.portable.*;
public class ReviewerFirstSaveAgent {
 static Path report=Path.of("E:/SSM/projects/odyssey-ambient/docs/independent-first-save-checks.txt");
 static int checks;static void check(boolean condition,String why){checks++;if(!condition)throw new AssertionError(why);}
 static Object field(Object o,String name)throws Exception{var f=o.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(o);}
 public static void premain(String arg,Instrumentation ignored){new Thread(()->{try{for(int i=0;i<200;i++){Thread.sleep(200);var m=MainSingleton.getInstance();if(m.config!=null&&m.bundle!=null&&m.guiManager!=null){Thread.sleep(2000);Platform.runLater(()->run());return;}}throw new AssertionError("startup timeout");}catch(Throwable t){finish(t);}},"reviewer-first-save").start();}
 static void run(){try{
  var main=MainSingleton.getInstance();Path root=PortableStarter.root;
  check(main.config.getOutputDevice().equals("COM59999"),"isolated unavailable port");check(main.serial==null&&main.output==null&&!main.serialConnected,"no hardware opened");
  check(!Files.exists(root.resolve("config/pc-selected.properties")),"first launch has no selection marker");
  var retry=SerialManager.class.getDeclaredField("scheduledFuture");retry.setAccessible(true);check(retry.get(null)==null,"before Save no attach retry");
  var loader=new FXMLLoader(GuiManager.class.getResource("settings.fxml"),main.bundle);Parent node=loader.load();SettingsController settings=loader.getController();var stage=new javafx.stage.Stage();stage.setScene(new javafx.scene.Scene(node));node.applyCss();node.layout();
  Object mode=field(settings,"modeTabController");ComboBox<?> port=(ComboBox<?>)field(mode,"serialPort");check(port.getValue().equals("COM59999"),"regular settings keeps unchanged port");
  check(!port.isDisabled()&&port.isEditable(),"port chooser usable");port.getEditor().setText("COM59999");main.config.setToggleLed(false);main.config.setBrightness(0);settings.save(null);
  check(Files.exists(root.resolve("config/pc-selected.properties")),"actual Save records selection");check(!main.exitTriggered,"same port Save keeps app alive");
  new Thread(()->{try{Thread.sleep(1500);check(retry.get(null)!=null,"actual Save schedules absent port reconnect");check(main.serial==null&&main.output==null&&!main.serialConnected,"absent port remains safe");check(!main.config.isToggleLed()&&main.config.getBrightness()==0,"Save preserves OFF");finish(null);}catch(Throwable t){finish(t);}},"reviewer-save-result").start();
 }catch(Throwable t){finish(t);}}
 static void finish(Throwable failure){try{if(failure==null)Files.writeString(report,"PASS "+checks+" native first launch -> actual FXMLLoader SettingsController.save(null), unchanged absent COM59999, no initial selection marker; immediate bounded retry, no restart, OFF\nROOT="+PortableStarter.root+"\nJAVA="+System.getProperty("java.home"));else try(var out=new java.io.PrintWriter(report.toFile())){failure.printStackTrace(out);}}catch(Exception ignored){}System.exit(failure==null?0:1);}
}
