import java.lang.instrument.Instrumentation;
import java.nio.file.*;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.dpsoftware.*;
import org.dpsoftware.gui.*;
import org.dpsoftware.gui.controllers.*;
import org.dpsoftware.portable.*;
public class ReviewerScreenTestAgent {
 static int checks;static String json;static java.util.LinkedHashMap<Integer,LEDCoordinate> matrix;
 static void check(boolean condition,String why){checks++;if(!condition)throw new AssertionError(why);}
 static Object field(Object object,String name)throws Exception{var f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
 public static void premain(String args,Instrumentation ignored){new Thread(()->{try{for(int i=0;i<200;i++){Thread.sleep(200);if(MainSingleton.getInstance().guiManager!=null&&MainSingleton.getInstance().bundle!=null){Thread.sleep(2000);Platform.runLater(()->open());return;}}throw new AssertionError("startup timeout");}catch(Throwable t){finish(t);}},"reviewer-screen-test").start();}
 static void open(){try{
  var main=MainSingleton.getInstance();check(main.serial==null&&main.output==null,"no hardware output");
  var loader=new FXMLLoader(GuiManager.class.getResource("settings.fxml"),main.bundle);Parent node=loader.load();SettingsController settings=loader.getController();Stage stage=new Stage();stage.setScene(new Scene(node));stage.setWidth(700);stage.setHeight(760);stage.show();
  Object mode=field(settings,"modeTabController");((ComboBox<?>)field(mode,"serialPort")).getEditor().setText("COM59999");
  var leds=(LedsConfigTabController)field(settings,"ledsConfigTabController");var p=leds.portablePane;
  p.top.setText("4");p.right.setText("3");p.bottom.setText("5");p.left.setText("2");p.gapTopLeft.setText("1");p.gapTopRight.setText("2");p.gapBottomRight.setText("3");p.gapBottomLeft.setText("4");p.corner.setValue("Bottom right");p.direction.setValue("Anticlockwise");p.offset.setText("1");p.skipped.setText("7-8");
  main.config.setToggleLed(false);main.config.setBrightness(0);p.screenTest.fire();check(!main.exitTriggered,"screen test save avoids restart");
  json=Files.readString(PortableLayout.file());matrix=main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix());check(matrix.size()==24,"screen test saves authoritative ring");
  new Thread(()->{try{Thread.sleep(1500);Platform.runLater(()->inspect());}catch(Throwable t){finish(t);}},"reviewer-screen-inspect").start();
 }catch(Throwable t){finish(t);}}
 static void inspect(){try{
  var main=MainSingleton.getInstance();var dialog=GuiSingleton.getInstance().getColorDialog();check(dialog!=null&&dialog.isShowing(),"legacy color calibration dialog visible");
  var control=(ColorCorrectionDialogController)dialog.getProperties().values().stream().filter(v->v instanceof ColorCorrectionDialogController).findFirst().orElseThrow();var tc=(TestCanvas)field(control,"testCanvas");
  var canvas=tc.getCanvas();check(canvas.getScene().getWindow().isShowing(),"screen test canvas visible");check(canvas.getWidth()==main.config.getScreenResX()*100.0/main.config.getOsScaling(),"selected display canvas size");
  for(int i=1;i<=24;i++){check(tc.drawNumLabel(main.config,i).equals("#"+i),"direct physical numbering");check(matrix.get(i).isActive()!=PortableLayout.current().gaps().get(i-1),"saved physical gaps match preview");}
  check(canvas.getOnMouseDragged()==null&&canvas.getOnMousePressed()==null,"manual geometry read only");
  control.resetLedMatrix();check(Files.readString(PortableLayout.file()).equals(json),"calibration reset keeps layout JSON");var after=main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix());
  for(int i=1;i<=24;i++)check(after.get(i).getX()==matrix.get(i).getX()&&after.get(i).getY()==matrix.get(i).getY()&&after.get(i).isActive()==matrix.get(i).isActive(),"calibration reset retains exact coordinates and gaps");
  var rendered=canvas.snapshot(new SnapshotParameters(),null);int w=(int)rendered.getWidth(),h=(int)rendered.getHeight();int[] pixels=new int[w*h];rendered.getPixelReader().getPixels(0,0,w,h,javafx.scene.image.PixelFormat.getIntArgbInstance(),pixels,0,w);var picture=new java.awt.image.BufferedImage(w,h,java.awt.image.BufferedImage.TYPE_INT_ARGB);picture.setRGB(0,0,w,h,pixels,0,w);javax.imageio.ImageIO.write(picture,"png",Path.of("E:/SSM/projects/odyssey-ambient/.build-1.0.4/reviewer/screen-test.png").toFile());
  control.close(new javafx.scene.input.KeyEvent(dialog.getScene().getRoot(),dialog.getScene().getRoot(),javafx.scene.input.KeyEvent.KEY_PRESSED,"","",javafx.scene.input.KeyCode.ESCAPE,false,false,false,false));
  Platform.runLater(()->{try{check(!canvas.getScene().getWindow().isShowing(),"close hides canvas");check(javafx.stage.Window.getWindows().stream().anyMatch(window->window.isShowing()&&window instanceof Stage s&&s.getTitle()!=null&&s.getTitle().contains("ESP32")),"close returns settings");check(!main.config.isToggleLed()&&main.config.getBrightness()==0&&main.output==null,"screen test never enables LED output");check(Files.readString(PortableLayout.file()).equals(json),"close keeps saved JSON");finish(null);}catch(Throwable t){finish(t);}});
 }catch(Throwable t){finish(t);}}
 static void finish(Throwable failure){try{Path report=Path.of("E:/SSM/projects/odyssey-ambient/docs/independent-screen-test-checks.txt");if(failure==null)Files.writeString(report,"PASS "+checks+" native regular LED button -> legacy screen/color calibration canvas, physical numbering and rotated corner/middle gaps; reset/drag safety, selected display size, close -> settings, output OFF.\nROOT="+PortableStarter.root+"\nJAVA="+System.getProperty("java.home"));else try(var out=new java.io.PrintWriter(report.toFile())){failure.printStackTrace(out);}}catch(Exception ignored){}System.exit(failure==null?0:1);}
}


