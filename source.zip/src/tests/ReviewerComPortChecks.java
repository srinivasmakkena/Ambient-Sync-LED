import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import java.awt.Color;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import org.dpsoftware.MainSingleton;
import org.dpsoftware.config.*;
import org.dpsoftware.managers.*;
import org.dpsoftware.portable.*;
import org.dpsoftware.utilities.PropertiesLoader;

/** Independent regression fixtures only; never opens a real COM port. */
public class ReviewerComPortChecks {
  static int checks;
  static void check(boolean ok,String reason) {checks++;if(!ok)throw new AssertionError(reason);}
  public static void main(String[] args) throws Exception {
    Path root=Path.of(args[0]).toAbsolutePath();
    Path config=root.resolve("config");Files.createDirectories(config);
    System.setProperty("firefly.config.dir",config.toString());
    System.setProperty("firefly.portable.root",root.toString());
    System.setProperty(Constants.LUCIFERIN_PLACEHOLDER,config.toString());
    MainSingleton main=MainSingleton.getInstance();main.whoAmI=1;
    main.bundle=ResourceBundle.getBundle(Constants.MSG_BUNDLE,Locale.ENGLISH);
    main.version=new PropertiesLoader().retrieveProperties(Constants.PROP_VERSION);
    check(main.version.matches("[0-9]+\\.[0-9]+\\.[0-9]+(?:-.*)?"),"filtered numeric release resource");
    YAMLMapper yaml=new YAMLMapper();
    Configuration c=yaml.readValue(root.resolve("profiles/portable-default.yaml").toFile(),Configuration.class);
    // Synthetic asymmetric mounting, edge and middle gaps; never user mounting values.
    PortableLayout p=new PortableLayout();p.top=4;p.right=3;p.bottom=5;p.left=2;
    p.corner="Bottom right";p.direction="Anticlockwise";p.offset=-3;p.skipped="1-2,7-9,14";
    p.name="Reviewer synthetic fixture";p.topDepth=11;p.rightDepth=12;p.bottomDepth=13;p.leftDepth=14;
    p.save(PortableLayout.file());byte[] layout=Files.readAllBytes(PortableLayout.file());
    p.apply(c);c.setOutputDevice("COM59999");c.setConfigVersion("${project.version}");
    c.setBrightness(0);c.setToggleLed(false);c.setColorChooser("0,0,0,0");
    main.config=c;
    yaml.writeValue(config.resolve(Constants.CONFIG_FILENAME).toFile(),c);
    yaml.writeValue(config.resolve("1_Reviewer profile.yaml").toFile(),c);
    StorageManager storage=new StorageManager();c=storage.readMainConfig();main.config=c;
    check(c.getConfigVersion().equals(main.version),"main read normalizes known placeholder before upgrader");
    storage.updateConfigFile(c);
    check(c.getConfigVersion().equals(main.version),"placeholder migrated to filtered release version");
    Configuration linked=storage.readProfileConfig("Reviewer profile");
    check(linked.getConfigVersion().equals(main.version),"linked profile placeholder migration");
    check(c.getOutputDevice().equals("COM59999"),"port survives migration");
    check(Arrays.equals(layout,Files.readAllBytes(PortableLayout.file())),"migration leaves mounting JSON byte-identical");
    for(String port:List.of("COM59998","COM59999")) {
      c.setOutputDevice(port);c.setConfigVersion(main.version);
      storage.writeConfig(c,null);c=storage.readMainConfig();main.config=c;
      PortableLayout.loadAndApply(c);
      check(c.getOutputDevice().equals(port),"saved new port survives reload");
      check(!c.isToggleLed()&&c.getBrightness()==0,"reload remains OFF");
      PortableLayout restored=PortableLayout.current();
      check(restored.corner.equals(p.corner)&&restored.direction.equals(p.direction)&&restored.offset==p.offset,"start/corner/direction preserved");
      check(restored.count()==14&&restored.skipped.equals(p.skipped)&&restored.leftDepth==14,"range and depth preserved");
      Color[] colors=restored.mask(new Color[]{Color.WHITE});
      for(int i=0;i<14;i++) {
        check(colors[i].equals(p.gaps().get(i)?Color.BLACK:Color.WHITE),"range mask physical identity");
        check(c.getLedMatrix().get(Enums.AspectRatio.FULLSCREEN.getBaseI18n()).get(i+1).isActive()!=p.gaps().get(i),"matrix gap identity");
      }
      check(Arrays.equals(layout,Files.readAllBytes(PortableLayout.file())),"port change keeps layout JSON exact");
    }
    // Many callers and absent-port retries share one daemon worker and one retry task.
    main.exitTriggered=false;
    var schedulerField=SerialManager.class.getDeclaredField("serialAttachScheduler");schedulerField.setAccessible(true);
    var taskField=SerialManager.class.getDeclaredField("scheduledFuture");taskField.setAccessible(true);
    for(int i=0;i<120;i++) new SerialManager().initSerial();
    ScheduledExecutorService scheduler=(ScheduledExecutorService)schedulerField.get(null);
    scheduler.submit(()->{}).get(30,TimeUnit.SECONDS);
    Object retry=taskField.get(null);
    check(retry!=null,"missing selected port installs retry");
    check(main.serial==null&&main.output==null&&!main.serialConnected&&main.communicationError,"absent selected port is safe disconnected state");
    for(int i=0;i<2;i++) {
      Thread.sleep(5500);scheduler.submit(()->{}).get(30,TimeUnit.SECONDS);
      check(taskField.get(null)==retry,"retry task does not multiply across disconnects");
      long workers=Thread.getAllStackTraces().keySet().stream().filter(t->t.isAlive()&&t.getName().equals("serial-connection")).count();
      check(workers==1,"one connection worker across repeated requests");
      check(Thread.getAllStackTraces().keySet().stream().filter(t->t.getName().equals("serial-connection")).allMatch(Thread::isDaemon),"connection worker cannot retain closed JVM");
      check(main.serial==null&&main.output==null&&!c.isToggleLed(),"absent retry never produces output or enables LEDs");
    }
    main.exitTriggered=true;Thread.sleep(5500);scheduler.submit(()->{}).get(30,TimeUnit.SECONDS);
    check(taskField.get(null)==null,"exit cancels pending reconnect");
    String result="PASS: "+checks+" version migration, linked profile, port save/reload, physical ranges and bounded missing-port retry checks\nVERSION="+main.version+"\nJAVA="+System.getProperty("java.home");
    Files.writeString(config.resolve("reviewer-com-checks.txt"),result);System.out.println(result);
  }
}
