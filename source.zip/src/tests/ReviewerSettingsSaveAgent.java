import org.dpsoftware.*;
import org.dpsoftware.gui.*;
import org.dpsoftware.gui.controllers.*;
import org.dpsoftware.portable.PortableLayout;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import java.lang.instrument.Instrumentation;
import java.nio.file.*;

/** Attaches only to an isolated reviewer process configured for absent COM ports. */
public class ReviewerSettingsSaveAgent {
 public static void agentmain(String argument,Instrumentation instrumentation) {
  String[] parts=argument.split("\\|",2);
  Platform.runLater(()->{
   try {
    var main=MainSingleton.getInstance();
    if(parts[0].equals("EXIT")) {NativeExecutor.exit();return;}
    String layoutBefore=Files.readString(PortableLayout.file());
    var loader=new FXMLLoader(GuiManager.class.getResource("settings.fxml"),main.bundle);
    Parent node=loader.load();SettingsController controller=loader.getController();
    Stage hidden=new Stage();hidden.setScene(new Scene(node));
    var mode=SettingsController.class.getDeclaredField("modeTabController");mode.setAccessible(true);
    Object tab=mode.get(controller);
    var field=tab.getClass().getDeclaredField("serialPort");field.setAccessible(true);
    @SuppressWarnings("unchecked") ComboBox<String> ports=(ComboBox<String>)field.get(tab);
    if(ports.isDisabled()||!ports.isEditable())throw new AssertionError("port chooser is disabled or cannot accept a new port");
    ports.setValue(parts[0]);ports.getEditor().setText(parts[0]);
    main.config.setToggleLed(false);main.config.setBrightness(0);
    controller.save(null);
    if(!main.config.getOutputDevice().equals(parts[0]))throw new AssertionError("saved port differs");
    if(!main.config.getConfigVersion().equals("2.28.4"))throw new AssertionError("version remains placeholder");
    if(main.config.isToggleLed()||main.config.getBrightness()!=0)throw new AssertionError("save enabled output");
    if(!layoutBefore.equals(Files.readString(PortableLayout.file())))throw new AssertionError("save modified physical JSON");
    var p=PortableLayout.current();var matrix=main.config.getLedMatrixInUse(main.config.getDefaultLedMatrix());
    if(matrix.size()!=p.count())throw new AssertionError("matrix count differs");
    for(int i=0;i<p.count();i++)if(matrix.get(i+1).isActive()==p.gaps().get(i))throw new AssertionError("save lost physical gap");
    Files.writeString(Path.of(parts[1]),"PASS actual SettingsController.save(null): port="+parts[0]+" version="+main.config.getConfigVersion()+" toggle=false brightness=0 count="+matrix.size()+" restart="+main.isRestartNeeded()+" JSON=unchanged physical gaps=preserved port chooser=enabled/editable\nJAVA="+System.getProperty("java.home"));
   } catch(Throwable error) {try(var writer=new java.io.PrintWriter(parts[1])){error.printStackTrace(writer);}catch(Exception ignored){}}
  });
 }
}
