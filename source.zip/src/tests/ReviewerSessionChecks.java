import org.dpsoftware.*;
import org.dpsoftware.portable.*;
import org.dpsoftware.managers.*;
import org.dpsoftware.config.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public class ReviewerSessionChecks {
 static int checks;static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
 static java.lang.reflect.Field field(Class<?> type,String name)throws Exception{var f=type.getDeclaredField(name);f.setAccessible(true);return f;}
 public static void main(String[] args)throws Exception{
  var main=MainSingleton.getInstance();main.config=new Configuration();main.config.setToggleLed(false);main.config.setBrightness(0);
  var layout=new PortableLayout();layout.top=72;layout.right=layout.bottom=layout.left=0;layout.skipped="1,36,72";field(PortableLayout.class,"current").set(null,layout);
  var output=new ByteArrayOutputStream();main.output=output;PortableMask.reset();check(!PortableMask.ready(),"initial pending");check(output.toString().equals(layout.maskCommand()),"canonical request");
  PortableMask.received(layout.acknowledgement());check(PortableMask.ready(),"exact ACK authorizes");
  field(PortableMask.class,"lastAck").setLong(null,System.currentTimeMillis()-86400000);field(PortableMask.class,"sentAt").setLong(null,0);output.reset();
  check(PortableMask.ready(),"prolonged ACK pause retains session");check(output.size()==0,"authorized session sends no repeated mask");
  PortableMask.received("baudrate:3");check(PortableMask.ready(),"normal telemetry retains authorization");
  for(String invalid:List.of("mask:NONE","mask:ERROR:INVALID","mask:GWPM1:71:00000000","BAUDRATE IN USE=500000")){
   PortableMask.received(invalid);check(!PortableMask.ready(),"explicit revocation "+invalid);PortableMask.received(layout.acknowledgement());check(PortableMask.ready(),"fresh exact ACK recovers");
  }
  var newLayout=new PortableLayout();newLayout.top=71;newLayout.right=newLayout.bottom=newLayout.left=0;field(PortableLayout.class,"current").set(null,newLayout);check(!PortableMask.ready(),"changed count rejects old ACK");field(PortableLayout.class,"current").set(null,layout);PortableMask.reset();
  var decoder=SerialManager.class.getDeclaredMethod("decodeSerialRead",byte[].class,int.class);decoder.setAccessible(true);
  String packet=layout.acknowledgement()+"\n";StringBuilder assembled=new StringBuilder();
  for(int start=0;start<packet.length();start+=3){int count=Math.min(3,packet.length()-start);byte[] oversized=new byte[count+9];System.arraycopy(packet.getBytes(StandardCharsets.US_ASCII),start,oversized,0,count);assembled.append((String)decoder.invoke(null,oversized,count));}
  check(assembled.toString().equals(packet)&&assembled.indexOf("\0")==-1,"fragmented short reads exclude NUL padding");PortableMask.received(assembled.toString().trim());check(PortableMask.ready(),"assembled ACK accepted");
  var manager=new SerialManager();var start=SerialManager.class.getDeclaredMethod("startMaskHandshake");start.setAccessible(true);main.serialConnected=true;PortableMask.reset();output.reset();
  start.invoke(manager);Object future=field(SerialManager.class,"maskHandshakeFuture").get(null);start.invoke(manager);check(future==field(SerialManager.class,"maskHandshakeFuture").get(null),"one pending worker");
  Thread.sleep(2800);String writes=output.toString();check(writes.equals(layout.maskCommand().repeat(3)),"pending retries independently of capture at bounded rate");
  synchronized(PortableMask.class){PortableMask.received(layout.acknowledgement());output.reset();}Thread.sleep(1300);check(output.size()==0,"ACK stops pending writes");
  manager.closeSerial();check(field(SerialManager.class,"maskHandshakeFuture").get(null)==null,"close cancels heartbeat");check(!PortableMask.ready(),"close revokes session");check(main.serial==null&&!main.serialConnected,"no hardware opened");
  System.out.println("PASS "+checks+" independent session latch/revocation, short-read and bounded retry checks; memory output only");
 }
}
