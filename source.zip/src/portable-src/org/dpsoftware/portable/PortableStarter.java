package org.dpsoftware.portable;

import java.nio.file.*;
import java.util.*;

/** Native jpackage entry, resolving every mutable path beside the extracted package. GPL-3.0-or-later. */
public final class PortableStarter {
    public static Path root;
    public static void main(String[] args) throws Exception {
        Path jar=Path.of(PortableStarter.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        root=System.getProperty("firefly.portable.root")!=null?Path.of(System.getProperty("firefly.portable.root")):jar.getParent().getParent();
        root=root.toAbsolutePath().normalize();
        System.setProperty("firefly.portable.root",root.toString());
        for(String dir:List.of("config","config/logs",".home",".tmp",".cache/jna",".cache/javafx")) Files.createDirectories(root.resolve(dir));
        System.setProperty("firefly.config.dir",root.resolve("config").toString());
        System.setProperty("luciferin.folder",root.resolve("config").toString());
        System.setProperty("user.home",root.resolve(".home").toString()); System.setProperty("java.io.tmpdir",root.resolve(".tmp").toString());
        System.setProperty("jna.tmpdir",root.resolve(".cache/jna").toString()); System.setProperty("javafx.cachedir",root.resolve(".cache/javafx").toString());
        if(com.sun.jna.Platform.isWindows()) {
            var kernel=com.sun.jna.NativeLibrary.getInstance("kernel32");
            Map<String,String> local=Map.of("TEMP",root.resolve(".tmp").toString(),"TMP",root.resolve(".tmp").toString(),"APPDATA",root.resolve(".home/AppData/Roaming").toString(),"LOCALAPPDATA",root.resolve(".home/AppData/Local").toString(),"XDG_CACHE_HOME",root.resolve(".cache").toString(),"GST_REGISTRY",root.resolve(".cache/gstreamer-registry.bin").toString());
            for(var entry:local.entrySet()) {Files.createDirectories(Path.of(entry.getValue()).getParent());kernel.getFunction("SetEnvironmentVariableW").invokeInt(new Object[]{new com.sun.jna.WString(entry.getKey()),new com.sun.jna.WString(entry.getValue())});}
        }
        if(Arrays.asList(args).contains("--probe")) {String result="ROOT="+root+"\nCONFIG="+System.getProperty("firefly.config.dir")+"\nHOME="+System.getProperty("user.home")+"\nTEMP="+System.getProperty("java.io.tmpdir")+"\nJAVA="+System.getProperty("java.home")+"\nCAPTURE="+System.getProperty("firefly.windows.captureApi");Files.writeString(root.resolve("config/startup-probe.txt"),result);System.out.println(result); return; }
        if(Arrays.asList(args).contains("--verify")) {Class.forName("PortableRegression").getMethod("main",String[].class).invoke(null,(Object)new String[]{args[1]});return;}
        args=Arrays.stream(args).filter(arg->!arg.equals("--setup")).toArray(String[]::new);
        try {
            var main=org.dpsoftware.JavaFXStarter.class.getDeclaredMethod("main",String[].class); main.setAccessible(true); main.invoke(null,(Object)args);
        } catch(Throwable failure) {
            try(var writer=new java.io.PrintWriter(root.resolve("config/logs/startup-error.txt").toFile())) { failure.printStackTrace(writer); }
            // JavaFX launch failure must not leave invisible scheduler threads owning this process.
            System.exit(1);
        }
    }
}
