package org.dpsoftware.portable;

import com.fazecast.jSerialComm.SerialPort;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

/** Bounded one-pixel USB test. No GPIO change, no full-chain bright frame. GPL-3.0-or-later. */
public final class PositionTest implements AutoCloseable {
    public static volatile boolean running;
    public static void testConnected(int oneBased,PortableLayout layout,AtomicBoolean active)throws Exception {
        layout.validate();if(oneBased<1||oneBased>layout.count()||layout.gaps().get(oneBased-1))throw new IllegalArgumentException("Choose an active physical LED.");
        var main=org.dpsoftware.MainSingleton.getInstance();
        if(PortableLayout.current()==null||!layout.maskBody().equals(PortableLayout.current().maskBody()))throw new IllegalStateException("Save the layout before testing.");
        running=true;main.config.setToggleLed(false);
        try {
            long deadline=System.currentTimeMillis()+4000;boolean ready=false;
            while(active.get()&&System.currentTimeMillis()<deadline){synchronized(PortableMask.class){if(main.output==null)throw new IllegalStateException("USB disconnected; test stopped.");main.output.write(packet(layout.count(),-1,0));ready=PortableMask.ready();}if(ready)break;Thread.sleep(50);}
            if(!ready)throw new IllegalStateException("Firmware did not acknowledge the saved layout; output remains OFF.");
            deadline=System.currentTimeMillis()+2000;
            while(active.get()&&System.currentTimeMillis()<deadline){synchronized(PortableMask.class){if(main.output==null||!PortableMask.ready())throw new IllegalStateException("USB or layout acknowledgement lost; test stopped.");main.output.write(packet(layout.count(),oneBased-1,32));}Thread.sleep(33);}
        } finally {synchronized(PortableMask.class){try{if(main.output!=null)main.output.write(packet(layout.count(),-1,0));}finally{running=false;}}}
    }
    private final SerialPort serial;
    private final PortableLayout layout;
    public PositionTest(String port,PortableLayout p) throws Exception {
        layout=p;serial=SerialPort.getCommPort(port);serial.setComPortParameters(500000,8,1,SerialPort.NO_PARITY);serial.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING,100,1000);serial.setDTRandRTS(false,false);
        if(!serial.openPort())throw new IllegalStateException("USB port could not be opened.");
    }
    public static byte[] packet(int count,int pixel,int brightness) {
        if(count<1||count>300||pixel<-1||pixel>=count||brightness<0||brightness>32)throw new IllegalArgumentException("Invalid bounded LED test packet.");
        byte[] result=new byte[27+count*3];byte[] prefix="DPsoft".getBytes(StandardCharsets.US_ASCII);System.arraycopy(prefix,0,result,0,6);
        int multiplier=(count-1)/250,n=(count-1)%250;result[6]=(byte)(n>>8);result[7]=(byte)n;result[8]=(byte)multiplier;result[9]=(byte)brightness;result[10]=(byte)255;result[11]=0;result[12]=65;result[13]=1;result[14]=2;result[15]=2;result[18]=1;result[19]=1;result[20]=0;result[25]=(byte)255;
        int crc=0x55;for(int i=6;i<26;i++)crc^=result[i]&255;result[26]=(byte)crc;
        if(pixel>=0) {result[27+pixel*3]=64;result[28+pixel*3]=64;result[29+pixel*3]=64;} return result;
    }
    private void write(byte[] bytes) throws Exception {if(serial.writeBytes(bytes,bytes.length)!=bytes.length)throw new IllegalStateException("Incomplete USB write");}
    public void start(int oneBased,AtomicBoolean active) throws Exception {
        write(packet(layout.count(),-1,0));StringBuilder response=new StringBuilder();long deadline=System.currentTimeMillis()+4000,last=0;boolean ack=false;
        while(System.currentTimeMillis()<deadline && active.get()) {
            if(System.currentTimeMillis()-last>500){write(layout.maskCommand().getBytes(StandardCharsets.US_ASCII));last=System.currentTimeMillis();}
            byte[] buffer=new byte[512];int n=serial.readBytes(buffer,buffer.length);if(n>0){response.append(new String(buffer,0,n,StandardCharsets.US_ASCII));if(response.toString().contains(layout.acknowledgement())){ack=true;break;}}
        }
        if(!ack)throw new IllegalStateException("Matching portable firmware did not acknowledge this layout; output remains off.");
        deadline=System.currentTimeMillis()+2000;
        while(active.get() && System.currentTimeMillis()<deadline) {write(packet(layout.count(),oneBased-1,32));Thread.sleep(33);}
    }
    @Override public void close() throws Exception {try {for(int i=0;i<3;i++){write(packet(layout.count(),-1,0));Thread.sleep(33);}}finally{serial.closePort();}}
}
