package org.dpsoftware.portable;

import org.dpsoftware.MainSingleton;
import java.nio.charset.StandardCharsets;
import java.awt.Color;
import java.io.IOException;

/** Firmware handshake gates both stream colors and internal animations. GPL-3.0-or-later. */
public final class PortableMask {
    private static final org.slf4j.Logger log=org.slf4j.LoggerFactory.getLogger(PortableMask.class);
    private static volatile String reportedState="";
    private static volatile boolean acknowledged;
    private static volatile String authorizedMask;
    private static volatile long sentAt;
    private static volatile long lastAck;
    public static void reset() { acknowledged=false; authorizedMask=null; sentAt=0; lastAck=0; }
    public static synchronized void received(String line) {
        if(!PortableLayout.active()) return;
        if(line.equals(PortableLayout.current().acknowledgement())) { acknowledged=true; authorizedMask=line; lastAck=System.currentTimeMillis(); }
        else if(line.startsWith("mask:") || line.startsWith("BAUDRATE IN USE=")) {
            log.info("Physical-layout authorization revoked: {}",line);
            reset();
        }
    }
    public static boolean ready() throws IOException {
        if(!PortableLayout.active()) return true;
        long now=System.currentTimeMillis();
        boolean ready=acknowledged && PortableLayout.current().acknowledgement().equals(authorizedMask);
        if(!ready && now-sentAt>1000 && MainSingleton.getInstance().output!=null) {
            MainSingleton.getInstance().output.write(PortableLayout.current().maskCommand().getBytes(StandardCharsets.US_ASCII)); sentAt=now;
        }
        // Firmware persists and applies this exact mask on every effect. Its ACK authorizes
        // this connection/layout session until an explicit reset, error or different mask.
        String state=ready?"ready":"waiting";
        if(!state.equals(reportedState)) {
            reportedState=state;
            log.info("Physical-layout output gate: {} (ACK age {} ms)",state,lastAck==0?-1:now-lastAck);
        }
        return ready;
    }
    public static Color[] mask(Color[] leds) { return PortableLayout.active()?PortableLayout.current().mask(leds):leds; }
}
