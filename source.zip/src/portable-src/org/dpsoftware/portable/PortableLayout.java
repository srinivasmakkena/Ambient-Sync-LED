package org.dpsoftware.portable;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.dpsoftware.LEDCoordinate;
import org.dpsoftware.config.Configuration;
import org.dpsoftware.config.Enums;
import org.dpsoftware.config.InstanceConfigurer;
import java.awt.Color;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;

/** Physical indices are stable: a gap consumes its place on the chain and screen. GPL-3.0-or-later. */
public final class PortableLayout {
    public int top=72, right=0, bottom=0, left=0, offset=0;
    public String corner="Top left", direction="Clockwise", skipped="", name="Top edge 72";
    public boolean enabled=true;
    public int topDepth=10, rightDepth=10, bottomDepth=10, leftDepth=10;
    public boolean cornerMode=false;
    public int gapTopLeft=0, gapTopRight=0, gapBottomRight=0, gapBottomLeft=0;
    private static volatile PortableLayout current;
    public int count() { return top+right+bottom+left+(cornerMode?gapTopLeft+gapTopRight+gapBottomRight+gapBottomLeft:0); }
    private int[] segments() { return new int[]{gapTopLeft,top,gapTopRight,right,gapBottomRight,bottom,gapBottomLeft,left}; }
    private boolean cornerSlot(int slot) { int[] segments=segments();for(int i=0;i<8;i++){if(slot<segments[i])return i%2==0;slot-=segments[i];}return false; }
    public void validate() {
        for(int side:new int[]{top,right,bottom,left}) if(side<0 || side>300) throw new IllegalArgumentException("Each side must have 0–300 physical LEDs.");
        for(int gap:new int[]{gapTopLeft,gapTopRight,gapBottomRight,gapBottomLeft}) if(gap<0 || gap>300) throw new IllegalArgumentException("Each corner gap must be 0–300 LEDs.");
        if(count()<1 || count()>300) throw new IllegalArgumentException("Use 1–300 physical LEDs in total; counts include skipped LEDs.");
        if(!List.of("Top left","Top right","Bottom right","Bottom left").contains(corner)) throw new IllegalArgumentException("Unknown start corner");
        if(!List.of("Clockwise","Anticlockwise").contains(direction)) throw new IllegalArgumentException("Unknown direction");
        for(int depth:new int[]{topDepth,rightDepth,bottomDepth,leftDepth}) if(depth<1 || depth>50) throw new IllegalArgumentException("Sampling depth must be 1–50%.");
        gaps();
    }
    public BitSet gaps() {
        BitSet result=new BitSet(count());
        if(cornerMode) for(int i=0;i<count();i++) if(cornerSlot(slot(i))) result.set(i);
        if(skipped.isBlank()) return result;
        for(String part:skipped.split(",",-1)) {
            if(!part.trim().matches("[0-9]+(?:\\s*-\\s*[0-9]+)?")) throw new IllegalArgumentException("Skipped LEDs: use physical indices, for example 1-3, 72, 144-146.");
            String[] range=part.trim().split("\\s*-\\s*");
            int start=Integer.parseInt(range[0]), end=range.length==1?start:Integer.parseInt(range[1]);
            if(start<1 || end<start || end>count()) throw new IllegalArgumentException("Skipped range is outside physical LED count: "+part);
            result.set(start-1,end);
        }
        return result;
    }
    public int slot(int physical) {
        int start=switch(corner) {case "Top right" -> top; case "Bottom right" -> top+right; case "Bottom left" -> top+right+bottom; default -> 0;};
        int cornerGap=0;
        if(cornerMode) {
            start=switch(corner) {case "Top right" -> gapTopLeft+top;case "Bottom right" -> gapTopLeft+top+gapTopRight+right;case "Bottom left" -> gapTopLeft+top+gapTopRight+right+gapBottomRight+bottom;default -> 0;};
            cornerGap=switch(corner) {case "Top right" -> gapTopRight;case "Bottom right" -> gapBottomRight;case "Bottom left" -> gapBottomLeft;default -> gapTopLeft;};
        }
        // For an anticlockwise path the first LED sits on the side preceding the corner.
        int sign=direction.equals("Clockwise")?1:-1;
        if(sign<0) start+=cornerMode&&cornerGap>0?cornerGap-1:-1;
        return (int)Math.floorMod((long)start+(long)sign*((long)physical+offset),(long)count());
    }
    public LinkedHashMap<Integer,LEDCoordinate> matrix(int width,int height,int borderX,int borderY) {
        validate();
        LinkedHashMap<Integer,LEDCoordinate> result=new LinkedHashMap<>();
        BitSet gaps=gaps(); int w=width-2*borderX,h=height-2*borderY;
        if(w<1 || h<1) throw new IllegalArgumentException("Capture bounds are empty");
        if(cornerMode) return cornerMatrix(width,height,borderX,borderY,gaps);
        for(int i=0;i<count();i++) {
            int s=slot(i),x,y,tw,th; String zone;
            if(s<top) { x=borderX+s*w/top; y=borderY; tw=Math.max(1,(s+1)*w/top-s*w/top); th=Math.max(1,h*topDepth/100); zone=Enums.PossibleZones.TOP.getBaseI18n(); }
            else if((s-=top)<right) { x=borderX+w-Math.max(1,w*rightDepth/100); y=borderY+s*h/right; tw=Math.max(1,w*rightDepth/100); th=Math.max(1,(s+1)*h/right-s*h/right); zone=Enums.PossibleZones.RIGHT.getBaseI18n(); }
            else if((s-=right)<bottom) { int j=bottom-1-s; x=borderX+j*w/bottom; y=borderY+h-Math.max(1,h*bottomDepth/100); tw=Math.max(1,(j+1)*w/bottom-j*w/bottom); th=Math.max(1,h*bottomDepth/100); zone=Enums.PossibleZones.BOTTOM.getBaseI18n(); }
            else { s-=bottom; int j=left-1-s; x=borderX; y=borderY+j*h/left; tw=Math.max(1,w*leftDepth/100); th=Math.max(1,(j+1)*h/left-j*h/left); zone=Enums.PossibleZones.LEFT.getBaseI18n(); }
            LEDCoordinate c=new LEDCoordinate(x,y,Math.min(tw,width-x),Math.min(th,height-y),false,zone); c.setActive(!gaps.get(i)); result.put(i+1,c);
        }
        return result;
    }
    private LinkedHashMap<Integer,LEDCoordinate> cornerMatrix(int width,int height,int bx,int by,BitSet gaps) {
        var result=new LinkedHashMap<Integer,LEDCoordinate>();int w=width-2*bx,h=height-2*by;
        for(int physical=0;physical<count();physical++) {
            int slot=slot(physical),segment=0;int[] sizes=segments();while(slot>=sizes[segment]){slot-=sizes[segment];segment++;}
            int x=bx,y=by,tw=1,th=1;String zone=Enums.PossibleZones.TOP.getBaseI18n();
            switch(segment) {
                case 0 -> {}
                case 2 -> x=bx+w-1;
                case 4 -> {x=bx+w-1;y=by+h-1;}
                case 6 -> y=by+h-1;
                case 1 -> {x=bx+slot*w/top;tw=Math.max(1,(slot+1)*w/top-slot*w/top);th=Math.max(1,h*topDepth/100);}
                case 3 -> {x=bx+w-Math.max(1,w*rightDepth/100);y=by+slot*h/right;tw=Math.max(1,w*rightDepth/100);th=Math.max(1,(slot+1)*h/right-slot*h/right);zone=Enums.PossibleZones.RIGHT.getBaseI18n();}
                case 5 -> {int j=bottom-1-slot;x=bx+j*w/bottom;y=by+h-Math.max(1,h*bottomDepth/100);tw=Math.max(1,(j+1)*w/bottom-j*w/bottom);th=Math.max(1,h*bottomDepth/100);zone=Enums.PossibleZones.BOTTOM.getBaseI18n();}
                case 7 -> {int j=left-1-slot;y=by+j*h/left;tw=Math.max(1,w*leftDepth/100);th=Math.max(1,(j+1)*h/left-j*h/left);zone=Enums.PossibleZones.LEFT.getBaseI18n();}
            }
            var coordinate=new LEDCoordinate(x,y,Math.min(tw,width-x),Math.min(th,height-y),false,zone);coordinate.setActive(!gaps.get(physical));result.put(physical+1,coordinate);
        }
        return result;
    }
    public void apply(Configuration config) {
        if(!enabled) return;
        config.setTopLed(top); config.setRightLed(right); config.setBottomRowLed(bottom); config.setLeftLed(left);
        config.setBottomLeftLed(0); config.setBottomRightLed(0); config.setSplitBottomMargin("0%"); config.setSplitBottomRow(false); config.setGroupBy(1);
        config.setLedStartOffset(0); config.setOrientation(Enums.Orientation.ANTICLOCKWISE.getBaseI18n());
        for(Enums.AspectRatio a:Enums.AspectRatio.values()) {
            int bx=a==Enums.AspectRatio.PILLARBOX?Math.min(config.getScreenResX()/4, Math.max(0,(config.getScreenResX()-config.getScreenResY()*4/3)/2)):0;
            int by=a==Enums.AspectRatio.LETTERBOX?config.getScreenResY()/org.dpsoftware.config.Constants.LETTERBOX_RATIO:0;
            config.getLedMatrix().put(a.getBaseI18n(),matrix(config.getScreenResX(),config.getScreenResY(),bx,by));
        }
    }
    public String maskBody() {
        byte[] data=new byte[(count()+7)/8]; BitSet bits=gaps();
        for(int i=bits.nextSetBit(0);i>=0;i=bits.nextSetBit(i+1)) data[i/8]|=(byte)(1<<(i%8));
        return "GWPM1:"+count()+":"+HexFormat.of().withUpperCase().formatHex(data);
    }
    public String crc() { CRC32 crc=new CRC32(); crc.update(maskBody().getBytes(java.nio.charset.StandardCharsets.US_ASCII)); return String.format(Locale.ROOT,"%08X",crc.getValue()); }
    public String maskCommand() { return maskBody()+":"+crc()+"\n"; }
    public String acknowledgement() { return "mask:GWPM1:"+count()+":"+crc(); }
    public Color[] mask(Color[] input) {
        Color[] result=new Color[count()]; BitSet bits=gaps();
        for(int i=0;i<count();i++) result[i]=bits.get(i)?Color.BLACK:input.length==1?input[0]:i<input.length?input[i]:Color.BLACK;
        return result;
    }
    public static Path file() { return Path.of(InstanceConfigurer.getConfigPath(),"portable-layout.json"); }
    public static PortableLayout current() { return current; }
    public static boolean active() { return current!=null && current.enabled; }
    public static PortableLayout fromConfiguration(Configuration config) {
        var p=new PortableLayout();p.top=config.getTopLed();p.right=config.getRightLed();p.bottom=config.getBottomRowLed()+config.getBottomLeftLed()+config.getBottomRightLed();p.left=config.getLeftLed();p.cornerMode=true;p.name="Monitor layout";return p;
    }
    public static void activate(PortableLayout layout,Configuration config) {
        synchronized(PortableMask.class) {layout.validate();PortableMask.reset();current=layout;layout.apply(config);}
    }
    public static void loadAndApply(Configuration config) {
        // Version 1.0.0's javac build accidentally shipped the Maven template.
        // Recover that known value before the upstream config upgrader parses it.
        if ("${project.version}".equals(config.getConfigVersion())) config.setConfigVersion("2.28.4");
        config.setCheckForUpdates(false); config.setStartWithSystem(false); config.setToggleLed(false);
        if(System.getProperty("firefly.portable.root")!=null && !Files.exists(Path.of(InstanceConfigurer.getConfigPath(),"pc-selected.properties"))) {
            var display=new org.dpsoftware.managers.DisplayManager().getDisplayList().getFirst();var physical=display.getDisplayInfoAwt();config.setScreenResX((int)physical.getWidth());config.setScreenResY((int)physical.getHeight());config.setOsScaling((int)Math.round(display.getScaleX()*100));config.setMonitorNumber(0);
        }
        if(!Files.exists(file())) { current=fromConfiguration(config);current.apply(config);return; }
        try { current=new ObjectMapper().readValue(file().toFile(),PortableLayout.class); current.validate(); current.apply(config); }
        catch(Exception e) { throw new IllegalStateException("Invalid saved portable layout. Open Configure layout to repair it.",e); }
    }
    public void save(Path destination) throws Exception {
        validate(); Files.createDirectories(destination.toAbsolutePath().getParent()); Path tmp=destination.resolveSibling(destination.getFileName()+".tmp");
        new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(tmp.toFile(),this); Files.move(tmp,destination,StandardCopyOption.REPLACE_EXISTING);
    }
}

