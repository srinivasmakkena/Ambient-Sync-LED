package org.dpsoftware.portable;

import javafx.application.Platform;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Insets;
import javafx.scene.paint.Color;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.dpsoftware.MainSingleton;
import org.dpsoftware.config.Configuration;

/** Integrated physical-layout editor for the main LED settings tab. GPL-3.0-or-later. */
public final class PortableLayoutPane extends BorderPane {
    public final TextField top=new TextField(),right=new TextField(),bottom=new TextField(),left=new TextField();
    public final TextField gapTopLeft=new TextField(),gapTopRight=new TextField(),gapBottomRight=new TextField(),gapBottomLeft=new TextField();
    public final ComboBox<String> corner=new ComboBox<>(),direction=new ComboBox<>();
    public final TextField offset=new TextField(),skipped=new TextField(),depth=new TextField(),name=new TextField(),testIndex=new TextField("1");
    public final Label status=new Label(),total=new Label(),offIndices=new Label();
    public final Button screenTest=new Button("Screen color test");
    private java.util.function.Consumer<javafx.scene.input.InputEvent> screenTestHandler;
    private final Canvas preview=new Canvas(380,180);
    private final AtomicBoolean testing=new AtomicBoolean();
    private PortableLayout original;
    public PortableLayoutPane(Configuration config,Runnable save) {
        setPadding(new Insets(8));corner.getItems().addAll("Top left","Top right","Bottom right","Bottom left");direction.getItems().addAll("Clockwise","Anticlockwise");
        GridPane counts=new GridPane();counts.setHgap(8);counts.setVgap(6);
        row(counts,0,"Top LEDs",top,"Top-left gap",gapTopLeft);row(counts,1,"Right LEDs",right,"Top-right gap",gapTopRight);row(counts,2,"Bottom LEDs",bottom,"Bottom-right gap",gapBottomRight);row(counts,3,"Left LEDs",left,"Bottom-left gap",gapBottomLeft);
        corner.setPrefWidth(155);direction.setPrefWidth(165);
        Label semantics=new Label("View from FRONT. Side counts exclude corner-gap LEDs. Each corner gap is a separate dark group on the same continuous strip.");semantics.setWrapText(true);semantics.setMaxWidth(375);
        Label startHelp=new Label("LED 1 begins at the chosen corner gap, then follows the selected direction. A zero gap begins on the next side.");startHelp.setWrapText(true);startHelp.setMaxWidth(375);
        VBox body=new VBox(7,semantics,counts,total,new HBox(8,new Label("LED 1 starts at"),corner),new HBox(8,new Label("Direction"),direction),startHelp,preview,offIndices);
        GridPane advanced=new GridPane();advanced.setHgap(8);advanced.setVgap(7);int row=0;
        advanced.add(new Label("Physical offset"),0,row);advanced.add(offset,1,row++);advanced.add(new Label("Extra OFF ranges"),0,row);advanced.add(skipped,1,row++);advanced.add(new Label("Sampling depth %"),0,row);advanced.add(depth,1,row++);advanced.add(new Label("Layout name"),0,row);advanced.add(name,1,row++);
        skipped.setPromptText("Optional: 12-14, 90, 150-153");Label extra=new Label("Offset and extra ranges count all physical LED positions, including gaps. Extra ranges darken existing side positions without removing or renumbering them.");extra.setWrapText(true);extra.setMaxWidth(350);advanced.add(extra,0,row++,2,1);
        ComboBox<String> saved=new ComboBox<>();saved.setPrefWidth(220);Button load=new Button("Load");load.setOnAction(e->{try{if(saved.getValue()==null)throw new IllegalArgumentException("Choose a saved layout.");fill(new ObjectMapper().readValue(PortableStarter.root.resolve("config/layouts").resolve(saved.getValue()).toFile(),PortableLayout.class));draw();}catch(Exception ex){status.setText(ex.getMessage());}});
        try{Path folder=PortableStarter.root.resolve("config/layouts");if(Files.exists(folder))try(var files=Files.list(folder)){files.filter(f->f.toString().endsWith(".json")).map(f->f.getFileName().toString()).sorted().forEach(saved.getItems()::add);}}catch(Exception ignored){}
        advanced.add(new HBox(8,saved,load),0,row,2,1);TitledPane advancedPane=new TitledPane("Advanced / saved layouts",advanced);advancedPane.setExpanded(false);body.getChildren().add(advancedPane);
        Button test=new Button("Test one LED (2s)");Button stop=new Button("Stop test");testIndex.setPrefColumnCount(3);test.setOnAction(e->test());stop.setOnAction(e->testing.set(false));body.getChildren().add(new HBox(6,new Label("LED #"),testIndex,test,stop));
        screenTest.setOnAction(e->{try{read();save.run();if(MainSingleton.getInstance().exitTriggered||MainSingleton.getInstance().isRestartNeeded()) {status.setText("Reopen the screen test after the settings restart.");return;}if(screenTestHandler!=null)screenTestHandler.accept(new javafx.scene.input.KeyEvent(screenTest,screenTest,javafx.scene.input.KeyEvent.KEY_PRESSED,"","",javafx.scene.input.KeyCode.ENTER,false,false,false,false));}catch(Exception ex){status.setText(ex.getMessage());}});body.getChildren().add(screenTest);
        offIndices.setWrapText(true);offIndices.setMaxWidth(375);ScrollPane scroll=new ScrollPane(body);scroll.setFitToWidth(true);setCenter(scroll);
        Button saveButton=new Button("Save layout & settings");saveButton.setOnAction(e->{try{read();save.run();}catch(Exception ex){status.setText(ex.getMessage());}});status.setWrapText(true);status.setMaxWidth(370);setBottom(new VBox(5,status,saveButton));
        fill(PortableLayout.current()!=null?PortableLayout.current():PortableLayout.fromConfiguration(config));
        for(TextField field:List.of(top,right,bottom,left,gapTopLeft,gapTopRight,gapBottomRight,gapBottomLeft,offset,skipped,depth,testIndex))field.textProperty().addListener((a,b,c)->draw());corner.valueProperty().addListener((a,b,c)->draw());direction.valueProperty().addListener((a,b,c)->draw());
        preview.setOnMouseClicked(e->{try{var matrix=read().matrix(330,125,0,0);int closest=1;double distance=Double.MAX_VALUE;for(var entry:matrix.entrySet()){var c=entry.getValue();double d=Math.hypot(25+c.getX()+c.getWidth()/2.-e.getX(),20+c.getY()+c.getHeight()/2.-e.getY());if(d<distance){distance=d;closest=entry.getKey();}}testIndex.setText(""+closest);}catch(Exception ignored){}});draw();
    }
    private static void row(GridPane grid,int row,String a,TextField x,String b,TextField y){x.setPrefColumnCount(3);y.setPrefColumnCount(3);grid.add(new Label(a),0,row);grid.add(x,1,row);grid.add(new Label(b),2,row);grid.add(y,3,row);}
    public void setScreenTestHandler(java.util.function.Consumer<javafx.scene.input.InputEvent> handler){screenTestHandler=handler;}
    public void fill(PortableLayout p){original=p;top.setText(""+p.top);right.setText(""+p.right);bottom.setText(""+p.bottom);left.setText(""+p.left);gapTopLeft.setText(""+p.gapTopLeft);gapTopRight.setText(""+p.gapTopRight);gapBottomRight.setText(""+p.gapBottomRight);gapBottomLeft.setText(""+p.gapBottomLeft);corner.setValue(p.corner);direction.setValue(p.direction);offset.setText(""+p.offset);skipped.setText(p.skipped);depth.setText(""+p.topDepth);name.setText(p.name);}
    public PortableLayout read(){var p=new PortableLayout();p.cornerMode=true;p.top=integer(top);p.right=integer(right);p.bottom=integer(bottom);p.left=integer(left);p.gapTopLeft=integer(gapTopLeft);p.gapTopRight=integer(gapTopRight);p.gapBottomRight=integer(gapBottomRight);p.gapBottomLeft=integer(gapBottomLeft);p.corner=corner.getValue();p.direction=direction.getValue();p.offset=integer(offset);p.skipped=skipped.getText().trim();p.name=name.getText().trim();int d=integer(depth);p.topDepth=d;p.rightDepth=original!=null&&d==original.topDepth?original.rightDepth:d;p.bottomDepth=original!=null&&d==original.topDepth?original.bottomDepth:d;p.leftDepth=original!=null&&d==original.topDepth?original.leftDepth:d;p.validate();return p;}
    private static int integer(TextField field){try{return Integer.parseInt(field.getText().trim());}catch(Exception ex){throw new IllegalArgumentException("LED counts, gaps, offset and depth must be whole numbers.");}}
    public void commit(PortableLayout p,Configuration config)throws Exception{if(testing.get())throw new IllegalArgumentException("Stop the LED test before saving.");synchronized(PortableMask.class){p.save(PortableLayout.file());PortableLayout.activate(p,config);String safe=p.name.replaceAll("[^a-zA-Z0-9 _-]","_");if(safe.isBlank())safe="Monitor layout";p.save(PortableStarter.root.resolve("config/layouts/"+safe+".json"));}status.setText("Saved. Physical layout now drives screen colors and every effect.");}
    private void draw(){var g=preview.getGraphicsContext2D();g.setFill(Color.web("#152332"));g.fillRect(0,0,380,180);g.setStroke(Color.GRAY);g.strokeRect(25,20,330,125);try{var p=read();int selected=integer(testIndex);var matrix=p.matrix(330,125,0,0);g.setFont(javafx.scene.text.Font.font(9));for(var entry:matrix.entrySet()){var c=entry.getValue();double x=25+c.getX()+c.getWidth()/2.,y=20+c.getY()+c.getHeight()/2.;g.setFill(!c.isActive()?Color.GRAY:entry.getKey()==selected?Color.GOLD:Color.CYAN);g.fillOval(x-2,y-2,4,4);if(p.count()<110||entry.getKey()%5==1||entry.getKey()==selected)g.fillText(""+entry.getKey(),x+3,y+3);}var first=matrix.get(1);g.setFill(Color.GOLD);g.fillText("LED 1 / DIN",25+first.getX(),Math.min(169,35+first.getY()));total.setText("Total physical LEDs: "+p.count()+"  ·  OFF: "+p.gaps().cardinality());offIndices.setText("OFF physical LED numbers: "+ranges(p.gaps()));}catch(Exception ex){total.setText("Enter valid counts (1–300 total physical LEDs).");offIndices.setText(ex.getMessage());}}
    private static String ranges(BitSet bits){var values=new ArrayList<String>();for(int i=bits.nextSetBit(0);i>=0;){int end=bits.nextClearBit(i)-1;values.add(i==end?""+(i+1):(i+1)+"–"+(end+1));i=bits.nextSetBit(end+1);}return values.isEmpty()?"none":String.join(", ",values);}
    private void test(){try{if(testing.get())return;var p=read();int index=integer(testIndex);if(index<1||index>p.count()||p.gaps().get(index-1))throw new IllegalArgumentException("Select an active physical LED from the preview.");if(PortableLayout.current()==null||!p.maskBody().equals(PortableLayout.current().maskBody()))throw new IllegalArgumentException("Save this layout before testing.");var main=MainSingleton.getInstance();if(!main.serialConnected||main.output==null)throw new IllegalArgumentException("Select the USB port in Mode and save before testing.");main.config.setToggleLed(false);if(main.RUNNING)main.guiManager.stopCapturingThreads(false);testing.set(true);status.setText("Testing physical LED "+index+" at low brightness…");Thread thread=new Thread(()->{try{PositionTest.testConnected(index,p,testing);Platform.runLater(()->status.setText("Test finished; output is OFF."));}catch(Exception ex){Platform.runLater(()->status.setText(ex.getMessage()));}finally{testing.set(false);}},"position-test");thread.setDaemon(true);thread.start();}catch(Exception ex){status.setText(ex.getMessage());}}
}
