package org.dpsoftware.portable;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLMapper;
import com.fazecast.jSerialComm.SerialPort;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.dpsoftware.config.Configuration;
import org.dpsoftware.config.Constants;
import org.dpsoftware.config.Enums;
import org.dpsoftware.LEDCoordinate;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Small native setup companion using Firefly's bundled JavaFX and serial libraries. GPL-3.0-or-later. */
public final class PortableSetup extends Application {
    private final ComboBox<String> corner=new ComboBox<>(),direction=new ComboBox<>(),ports=new ComboBox<>(),screens=new ComboBox<>(),saved=new ComboBox<>();
    private final TextField top=new TextField(),right=new TextField(),bottom=new TextField(),left=new TextField(),offset=new TextField(),gaps=new TextField(),name=new TextField();
    private final TextField td=new TextField(),rd=new TextField(),bd=new TextField(),ld=new TextField(),testIndex=new TextField("1");
    private final Canvas preview=new Canvas(780,305);
    private final Label status=new Label("Choose this PC's display and USB port. LEDs remain off when saving.");
    private Configuration config;
    private PortableLayout layout;
    private Stage stage;
    private final AtomicBoolean testing=new AtomicBoolean();
    private java.util.List<org.dpsoftware.gui.elements.DisplayInfo> displays;
    @Override public void start(Stage s) throws Exception {
        stage=s;
        var mapper=new YAMLMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,false);
        config=mapper.readValue(PortableStarter.root.resolve("config/FireflyLuciferin.yaml").toFile(),Configuration.class);
        layout=Files.exists(PortableLayout.file())?new ObjectMapper().readValue(PortableLayout.file().toFile(),PortableLayout.class):new PortableLayout();
        if(!Files.exists(PortableLayout.file())) { layout.top=config.getTopLed(); layout.right=config.getRightLed(); layout.bottom=config.getBottomRowLed()+config.getBottomLeftLed()+config.getBottomRightLed(); layout.left=config.getLeftLed(); layout.name="Current physical layout"; }
        corner.getItems().addAll("Top left","Top right","Bottom right","Bottom left"); direction.getItems().addAll("Clockwise","Anticlockwise");
        displays=new org.dpsoftware.managers.DisplayManager().getDisplayList();
        for(int i=0;i<displays.size();i++) { var display=displays.get(i);var physical=display.getDisplayInfoAwt();screens.getItems().add("Display "+(i+1)+" — "+(int)physical.getWidth()+" × "+(int)physical.getHeight()+" ("+(display.getMonitorName()==null?"screen":display.getMonitorName().trim())+")"); }
        refreshPorts();
        if(Files.exists(PortableStarter.root.resolve("config/pc-selected.properties"))) { if(config.getMonitorNumber()<screens.getItems().size()) screens.getSelectionModel().select(config.getMonitorNumber()); if(ports.getItems().contains(config.getOutputDevice())) ports.setValue(config.getOutputDevice()); }
        fill(layout);
        GridPane grid=new GridPane(); grid.setHgap(12); grid.setVgap(9); int row=0;
        grid.add(new Label("Capture screen"),0,row); grid.add(screens,1,row,3,1); row++;
        grid.add(new Label("USB port"),0,row); grid.add(ports,1,row); Button refresh=new Button("Refresh USB ports"); refresh.setOnAction(e->refreshPorts()); grid.add(refresh,2,row,2,1); row++;
        grid.add(new Label("LEDs per side"),0,row); grid.add(new HBox(8,new Label("Top"),top,new Label("Right"),right,new Label("Bottom"),bottom,new Label("Left"),left),1,row,3,1); row++;
        grid.add(new Label("Physical start"),0,row); grid.add(corner,1,row); grid.add(direction,2,row); row++;
        grid.add(new Label("Initial offset"),0,row); grid.add(offset,1,row); grid.add(new Label("Positions along the selected direction; wraps around"),2,row,2,1); row++;
        grid.add(new Label("Skipped LEDs"),0,row); grid.add(gaps,1,row,3,1); row++;
        grid.add(new Label("Sampling depth %"),0,row); grid.add(new HBox(8,new Label("Top"),td,new Label("Right"),rd,new Label("Bottom"),bd,new Label("Left"),ld),1,row,3,1); row++;
        grid.add(new Label("Layout name"),0,row); grid.add(name,1,row,3,1); row++;
        Button save=new Button("Save layout"),start=new Button("Save & start lights"),load=new Button("Load saved layout"),test=new Button("Test one LED (2 seconds)"),off=new Button("Stop test");
        save.setOnAction(e->save(false)); start.setOnAction(e->save(true)); load.setOnAction(e->loadSaved()); test.setOnAction(e->test()); off.setOnAction(e->testing.set(false));
        for(TextField f:List.of(top,right,bottom,left,offset,td,rd,bd,ld)) f.setPrefColumnCount(3);
        gaps.setPromptText("Physical LED numbers: 1-3, 72, 144-146 (counts above include these LEDs)");
        for(TextField f:List.of(top,right,bottom,left,offset,gaps,td,rd,bd,ld)) f.textProperty().addListener((a,b,c)->draw()); corner.valueProperty().addListener((a,b,c)->draw()); direction.valueProperty().addListener((a,b,c)->draw());
        preview.setOnMouseClicked(e->{ try { var p=read(); var m=p.matrix(700,240,0,0); int nearest=1; double best=Double.MAX_VALUE; for(var item:m.entrySet()) {var c=item.getValue(); double d=Math.hypot(40+c.getX()+c.getWidth()/2.-e.getX(),28+c.getY()+c.getHeight()/2.-e.getY()); if(d<best){best=d;nearest=item.getKey();}} testIndex.setText(Integer.toString(nearest)); draw(); } catch(Exception ignored){} });
        testIndex.setPrefColumnCount(3); testIndex.textProperty().addListener((a,b,c)->draw());
        status.setWrapText(true); status.setMaxWidth(790);
        var note=new Label("View from FRONT of monitor. One continuous strip may fold at every corner. LED 1 is DIN. Offset counts physical positions including gaps. Gray positions stay off in every effect. Click a position to test it. Saving stops output; turn LEDs on after checking the layout."); note.setWrapText(true); note.setMaxWidth(790);
        VBox root=new VBox(11,new Label("ESP32 Sync Lights — display & physical layout"),grid,preview,note,new HBox(10,saved,load),new HBox(10,new Label("Physical LED"),testIndex,test,off),new HBox(10,save,start),status); root.setPadding(new Insets(20));
        root.setStyle("-fx-font-size: 13px; -fx-background-color: #eef3f7;");
        ScrollPane scroll=new ScrollPane(root); scroll.setFitToWidth(true);var bounds=javafx.stage.Screen.getPrimary().getVisualBounds();
        Scene scene=new Scene(scroll,Math.min(850,bounds.getWidth()-40),Math.min(850,bounds.getHeight()-80)); s.setScene(scene); s.setTitle("ESP32 Sync Lights — Configure layout"); s.setOnCloseRequest(e->testing.set(false)); s.show(); refreshSaved(); draw();
        if(Arrays.asList(getParameters().getRaw().toArray()).contains("--ui-probe")) Platform.runLater(()->{String result="PASS: ESP32 Sync Lights setup constructed with "+screens.getItems().size()+" display(s), "+ports.getItems().size()+" serial port(s), numbered preview and saved layout controls";System.out.println(result);try{Files.writeString(PortableStarter.root.resolve("config/ui-probe.txt"),result);}catch(Exception ignored){}s.close();Platform.exit();});
    }
    private void refreshPorts() { String previous=ports.getValue(); ports.getItems().clear(); for(SerialPort p:SerialPort.getCommPorts()) ports.getItems().add(p.getSystemPortName()); if(ports.getItems().contains(previous)) ports.setValue(previous); }
    private void fill(PortableLayout p) { top.setText(""+p.top);right.setText(""+p.right);bottom.setText(""+p.bottom);left.setText(""+p.left);offset.setText(""+p.offset);gaps.setText(p.skipped);name.setText(p.name);corner.setValue(p.corner);direction.setValue(p.direction);td.setText(""+p.topDepth);rd.setText(""+p.rightDepth);bd.setText(""+p.bottomDepth);ld.setText(""+p.leftDepth); }
    private PortableLayout read() { PortableLayout p=new PortableLayout(); p.top=Integer.parseInt(top.getText().trim()); p.right=Integer.parseInt(right.getText().trim()); p.bottom=Integer.parseInt(bottom.getText().trim()); p.left=Integer.parseInt(left.getText().trim()); p.offset=Integer.parseInt(offset.getText().trim()); p.skipped=gaps.getText(); p.name=name.getText().trim(); p.corner=corner.getValue(); p.direction=direction.getValue(); p.topDepth=Integer.parseInt(td.getText().trim()); p.rightDepth=Integer.parseInt(rd.getText().trim()); p.bottomDepth=Integer.parseInt(bd.getText().trim()); p.leftDepth=Integer.parseInt(ld.getText().trim()); p.validate(); return p; }
    private void draw() {
        var g=preview.getGraphicsContext2D(); g.setFill(Color.web("#152332"));g.fillRect(0,0,780,305);g.setStroke(Color.web("#5d7488"));g.strokeRect(40,28,700,240);
        try { var p=read(); var m=p.matrix(700,240,0,0); int selected=Integer.parseInt(testIndex.getText().trim()); g.setFont(javafx.scene.text.Font.font(Math.max(8, Math.min(12,700./Math.max(30,p.top)))));
            for(var item:m.entrySet()) {var c=item.getValue(); double x=40+c.getX()+c.getWidth()/2.,y=28+c.getY()+c.getHeight()/2.;g.setFill(!c.isActive()?Color.web("#66717a"):item.getKey()==selected?Color.GOLD:Color.CYAN);g.fillOval(x-3,y-3,6,6); if(p.count()<=160 || item.getKey()%5==1 || item.getKey()==selected) g.fillText(""+item.getKey(),x+4,y+4);}
            g.setFill(Color.WHITE);g.fillText(p.count()+" physical LEDs · "+p.gaps().cardinality()+" skipped · LED "+selected+" selected",50,292);
        } catch(Exception ex) {g.setFill(Color.SALMON);g.fillText("Enter valid counts, ranges and sampling depths to preview.",60,155);}
    }
    private void refreshSaved() { saved.getItems().clear(); try {Path dir=PortableStarter.root.resolve("config/layouts");Files.createDirectories(dir);try(var files=Files.list(dir)){files.filter(f->f.toString().endsWith(".json")).map(f->f.getFileName().toString()).sorted().forEach(saved.getItems()::add);}}catch(Exception ex){status.setText(ex.getMessage());} }
    private void loadSaved() {try {if(saved.getValue()==null)throw new IllegalArgumentException("Select a saved layout."); fill(new ObjectMapper().readValue(PortableStarter.root.resolve("config/layouts").resolve(saved.getValue()).toFile(),PortableLayout.class));draw();status.setText("Loaded layout. Choose this PC's display and port, then save to apply.");}catch(Exception ex){status.setText(ex.getMessage());}}
    private void save(boolean launch) {
        try {
            if(testing.get())throw new IllegalArgumentException("Stop the position test before saving.");
            PortableLayout p=read(); if(screens.getSelectionModel().getSelectedIndex()<0 || ports.getValue()==null) throw new IllegalArgumentException("Choose this PC's display and USB port.");
            int monitor=screens.getSelectionModel().getSelectedIndex();var display=displays.get(monitor);var physical=display.getDisplayInfoAwt();
            config.setScreenResX((int)physical.getWidth());config.setScreenResY((int)physical.getHeight());config.setOsScaling((int)Math.round(display.getScaleX()*100));config.setMonitorNumber(monitor);config.setMultiMonitor(1);config.setMultiScreenSingleDevice(false);
            config.setOutputDevice(ports.getValue()); config.setBrightness(0);config.setToggleLed(false);config.setColorChooser("0,0,0,0");config.setEffect(Enums.Effect.SOLID.getBaseI18n());config.setCheckForUpdates(false);config.setStartWithSystem(false);config.setCaptureMethod(Configuration.CaptureMethod.DDUPL_DX12.name());config.setDesiredFramerate("30");config.setWirelessStream(false);config.setFullFirmware(false);config.setMqttEnable(false);p.apply(config);
            Path cfg=PortableStarter.root.resolve("config/FireflyLuciferin.yaml");Files.copy(cfg,cfg.resolveSibling("before-layout.yaml"),StandardCopyOption.REPLACE_EXISTING);
            Path tmp=cfg.resolveSibling("FireflyLuciferin.yaml.tmp");new YAMLMapper().writeValue(tmp.toFile(),config);Files.move(tmp,cfg,StandardCopyOption.REPLACE_EXISTING);
            p.save(PortableLayout.file());String safe=p.name.replaceAll("[^a-zA-Z0-9 _-]","_");if(safe.isBlank())safe="Layout";p.save(PortableStarter.root.resolve("config/layouts/"+safe+".json"));
            Files.writeString(PortableStarter.root.resolve("config/pc-selected.properties"),"display="+monitor+"\nport="+ports.getValue()+"\n");refreshSaved();status.setText("Saved. Output is off. Use ESP32 Sync Lights's effect and brightness controls when ready.");
            if(launch) {new ProcessBuilder(PortableStarter.root.resolve("runtime/ESP32 Sync Lights.exe").toString()).directory(PortableStarter.root.resolve("runtime").toFile()).start();stage.close();Platform.exit();}
        } catch(Exception ex) {status.setText(ex.getMessage());}
    }
    private void test() {
        try {
            if(testing.get()) return; PortableLayout p=read();int index=Integer.parseInt(testIndex.getText());if(index<1 || index>p.count())throw new IllegalArgumentException("Test index is outside this physical chain.");if(ports.getValue()==null)throw new IllegalArgumentException("Select a USB port.");if(p.gaps().get(index-1))throw new IllegalArgumentException("Selected LED is skipped and must stay off. Select an active LED.");
            String port=ports.getValue();testing.set(true);status.setText("Testing physical LED "+index+" at low brightness for two seconds…");
            Thread worker=new Thread(()->{
                try(var output=new PositionTest(port,p)) {output.start(index,testing);Platform.runLater(()->status.setText("Position test ended; all LEDs sent off. Confirm the selected physical LED visually."));}
                catch(Exception ex) {Platform.runLater(()->status.setText("Position test: "+ex.getMessage()+" Close ESP32 Sync Lights from its tray before testing."));}
                finally {testing.set(false);}
            },"portable-position-test");worker.setDaemon(true);worker.start();
        }catch(Exception ex){status.setText(ex.getMessage());}
    }
}
